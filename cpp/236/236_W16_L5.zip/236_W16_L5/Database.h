/*
 * dataBase.h
 *
 *  Created on: Oct 22, 2015
 *      Author: heypono
 */

#ifndef DATABASE_H_
#define DATABASE_H_

#include "Rule.h"
#include "Relation.h"
#include "Node.h"

#include <map>
#include <vector>

#include <fstream>

#include <algorithm>

using namespace std;

class Database
	{
		private:
			map <string, Relation> relationContainer;
			
			//Map to store Relations generated from Rules to identify when generation should stop
			map <string, Relation> relationContainerRules;
			unsigned int ruleRelationCountAtStart;
			unsigned int totalRelationTuplesCountAtStart;
			
			unsigned int ruleRelationLoopCount;
			
			
			//Submitted data containers
			vector <Predicate> schemePredicateContainer;
			vector <Predicate> factPredicateContainer;
			vector <Predicate> queryPredicateContainer;
			vector <Rule> rulePredicateContainer;
			
			
			//Set to hold the potential Tuple matches for each Query
			set <Tuple> relationTuplesCopy;
			
			
			//Map to hold the locations of IDs in the Query body
			map <string, vector <int>> queryVariableIndexContainer;
			//vector <int> currentVariableIndexContainer;
			
			
			//Set to hold the Relations associated with the current Rule Body Predicates;
			set <Relation> currentRuleBodyRelations;
			
			//Output File
			char* outputFile;
		
			ofstream outputFileStream;
			
			
			map <int, vector <int>> queryTotalVariableIndexContainer;
			map <string, vector <int>> queryTotalVariableContainer;
			//vector <int> queryTotalVariableIndexValues;
			
			
			
			
			
			
			//Map of Nodes for Lab 5
			map <int, Node> forwardGraph;
			map <int, Node> reverseGraph;
			
			//int postOrderNumber = 0;
			
			vector <int> postOrderContainer;
			set <int> currentSCC;
			
			vector <set <int>> sccContainer;
			
			
			
			
			
			//Vector to hold indices of where Schemes of Relations to be Joined match
			vector <int> joinSchemesMatchIndices;
			
			//stringstream outputStringStream;
			
			//Old Code Material
			/*
			map <string, Relation> relationContainer;
			
			//map <string, vector <int>> queryVariableIndexContainer;
			
			vector <Predicate> schemePredicateContainer;
			vector <Predicate> factPredicateContainer;
			vector <Predicate> queryPredicateContainer;
			
			std::set <Predicate> factPredicateSet;
			
			vector <vector <string>> factPredicateStringContainer;
			
			
			//Output file for displaying the analysis results
			char* outputFile;
			*/
	
		public:
			
			Database (vector <Predicate> schemePredicateContainerSubmit, vector <Predicate> factPredicateContainerSubmit, vector <Predicate> queryPredicateContainerSubmit, vector<Rule> rulePredicateContainerSubmit, char* argv2)
				{
					outputFile = argv2;
					
					schemePredicateContainer = schemePredicateContainerSubmit;
					
					factPredicateContainer = factPredicateContainerSubmit;
					
					queryPredicateContainer = queryPredicateContainerSubmit;
					
					rulePredicateContainer = rulePredicateContainerSubmit;
					
				};
				
			Database ()
				{
				};
				
			~Database ()
				{
				};
				
				
				
			//These functions are used for Labs 3, 4, and 5
			void databaseRun ();	
				
			void createRelations ();
				
			void addRelationValues ();
			
			void displayMatchSchemesAndFacts (char* outputFile);
			
			void matchQueries ();
			
			void answerQuery (Relation relationCopy, /*set <Tuple> relationTuplesCopy,*/ Predicate currentQuerySubmit);
			
			void answerQueryStringTest (/*set <Tuple> relationTuplesCopy,*/ Predicate currentQuery, int i);
			vector <int> answerQueryIDTest (Predicate currentQuery, unsigned int i);
			
			void displaySelectProjectRename (Relation currentOutputRelation, Predicate currentQuery);
			
			
			
			
			
			
			
			
			//These functions are used for Labs 4 AND 5
			
			//This version of answerRules was for Lab 4
			//void answerRules ();
			//This version of answerRules is for answering each group of Strong Connected Components, for Lab 5
			void answerRules (set <int> &sccCurrentGroup);
			void displayRuleEvaluationFollow (unsigned int ruleRelationLoopCount);
			
			void convertRuleBodyToRelations (Rule currentRuleSubmit);
			
			Relation convertCurrentRulePredicateToRelation (Relation relationCopy, Predicate currentRuleBodyPredicates);
			
			//answerRulePredicateIDTest (Predicate currentRulePredicate, 
			//Check whether the Tuple Values were put into the Relation after converting Rule BODY Predicates to Relations
			void checkRuleBodyRelations (map <string, Relation> relationsToJoinSubmit);
			
			//I may need to return a Relation from "joinRuleBodyRelations"
			Relation joinRuleBodyRelations (Rule currentRuleSubmit, Relation r0Submit, Relation r1Submit);//map <string, Relation> relationsToJoinSubmit);
			//This function JOINS the current pair of Schemes and returns the result
			Scheme joinRuleBodyRelationSchemes (Scheme s0Submit, Scheme s1Submit, vector <pair <int, int>> &currentSchemeMatchIndices);//set <Scheme> currentRuleBodySchemesToJoinSubmit);
			//Tuple joinRuleBodyRelationTuples (Relation currentRuleBodyRelationSubmit);
			set <Tuple> joinRuleBodyRelationTuples (Rule currentRuleSubmit, Scheme s0Submit, Scheme s1Submit, set <Tuple> t0Submit, set <Tuple> t1Submit, vector <pair <int, int>> &currentSchemeMatchIndices);
			//If the current pair of Tuples from the corresponding pair of Schemes are able to Join, this function JOINS them and returns the result
			Tuple joinCurrentTuples (Rule currentRuleSubmit, Scheme s0Submit, Scheme s1Submit, Tuple tupleSubmit0, Tuple tupleSubmit1, vector <pair <int, int>> &currentSchemeMatchIndices);
			//This function checks whether the current pair of Tuples from the corresponding pair of Schemes are able to Join
			bool checkJoinTuples ( Tuple tupleSubmit0, Tuple tupleSubmit1, vector <pair <int, int>> &currentSchemeMatchIndices);
			//This function matches each of the Relations that results from JOINing to the Rule Head Predicate and creates a corresponding Relation
			void convertJoinedRuleBodyRelationsToHeadPredicateRelations ();
			
			void convertCurrentRuleHeadPredicateToRelation(Rule currentRule);//Predicate currentRuleHeadPredicate);
			
			unsigned int getTotalRelationTuplesCount ();
				
			//void displayRulesAndTupleValues (Rule currentRule);
			void displayRulesAndTupleValues (Rule &currentRuleSubmit);//Relation& currentRuleRelationConstructSubmit);
			
			
			
			
			
			//These functions are used for Lab 5
			void generateGraphs ();
			
			void setGraphAdjacencies (int indexSubmit, Rule &currentRuleSubmit);
			
			void displayGraphs ();
			
			void dfsForestReverseGraph ();
			
			void dfsForestReverseNode (int currentGraphInt, Node &currentGraphNode);
			
			void displayPostOrderNumbers ();
			
			void displaySCCOrder ();
			
			void dfsForestForwardGraph ();
			
			void dfsForestReversePostOrder (Node &currentPostOrderNode);
			
			void displaySCC ();
			
			void answerSCC ();
			
			bool isSimpleSCC (set <int> &sccCurrentGroup);
			
			
			
			
			
			
			
			
			void displayResults (/*map <string, vector <int>> queryVariableIndexContainer,*/ /*set <Tuple> relationTuplesCopy,*/ Predicate currentQuery);
			
			void displayResultsStrings (char* outputFile, Predicate currentQuery);
			
			void displayResultsProject (char* outputFileName, Predicate currentQuery);
			
			vector <int> getUniqueVariableIndexValues (vector <int> currentQueryVariableIndexValues, vector <Parameter> currentQueryBody);
			
			
			
			
			
			
			//Old Code Material
			/*
			Database (vector <Predicate> schemePredicateContainerSubmit, vector <Predicate> factPredicateContainerSubmit, vector< vector<string>> factPredicateStringContainerSubmit, vector <Predicate> queryPredicateContainerSubmit, char* argv2) //: schemePredicateContainer (schemePredicateContainerSubmit), factPredicateContainer (factPredicateContainerSubmit), factPredicateStringContainer (factPredicateStringContainerSubmit), queryPredicateContainer (queryPredicateContainerSubmit)
				{
					outputFile = argv2;
					
					schemePredicateContainer = schemePredicateContainerSubmit;
					factPredicateContainer = factPredicateContainerSubmit;
					factPredicateStringContainer = factPredicateStringContainerSubmit;
					queryPredicateContainer = queryPredicateContainerSubmit;
				};
			
			~Database ()
				{
					
				};
				
				
			void databaseRun ();
			
			void createRelations ();
			
			void addRelationValues ();
			
			void displayMatchSchemesAndFacts (char* outputFile);
			
			void matchQueries ();
			void answerQuery (set <vector <string>> relationValuesCopy, Predicate currentQuery);
			
			
			
			
			
			bool answerQuerySelect (set <vector <string>> currentQueryRelationTest, Predicate currentQuery);
			bool answerQueryRename (set <vector <string>> currentQueryRelationTest, Predicate currentQuery);
			bool answerQueryProject (set <vector <string>> currentQueryRelationTest, Predicate currentQuery);
			
			
			void displayResults (map <string, vector <int>> queryVariableIndexContainer, set <vector <string>> relationValuesCopy, Predicate currentQuery);
			*/
	};




#endif /* DATABASE_H_ */
