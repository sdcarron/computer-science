/*
 * dataBase.cpp
 *
 *  Created on: Oct 22, 2015
 *      Author: heypono
 */


#include "Database.h"

//Create a Relation for each Scheme Predicate and ADD the Relation to the MAP
void Database::createRelations ()
	{
		//cout << "Entered createRelations which is in Database" << endl << endl;
		//cout << "Creating Relations" << endl << endl;
	
		//Look at each Scheme Predicate
		for (unsigned int i = 0; i < schemePredicateContainer.size(); i++)
			{
				
				vector <string> currentSchemeStrings;
				
				for (unsigned int j = 0; j < schemePredicateContainer[i].getBodyComponents().size(); j++)
					{
						currentSchemeStrings.push_back (schemePredicateContainer[i].getBodyComponents()[j].getTokenValue());
					}
					
				Scheme currentSchemeColumnNames (currentSchemeStrings);
					
				//Create a Relation for the CURRENT Scheme Predicate
				Relation relationCreate (schemePredicateContainer[i].toStringName(), currentSchemeColumnNames);
				
				//Add the NEW Relation into the MAP
				//For a KEY to the NEW Relation, use the CURRENT Scheme Predicate's NAME
				relationContainer [schemePredicateContainer[i].toStringName()] = relationCreate;
			}
		
		//cout << "Finished Creating Relations... Now Inserting Relation Table Values (Fact Predicate Strings)" << endl << endl;
		
		//Add Table Values for each Relation that MATCHES a Fact Predicate's NAME
		addRelationValues();
	}






//This is the MAIN Funtion for the Database
void Database::databaseRun ()
	{
		createRelations();
	}






//Add the String Elements from each Fact Predicate into the Relation Table that MATCHES the Fact Predicate's NAME 
void Database::addRelationValues ()
	{
		//cout << "Entered addRelationValues which is in Database" << endl << endl;
		
		//cout << "Inserting Fact Predicate String Elements into PROPER Relation Tables" << endl << endl;
		
		//Look at each Fact Predicate
		for (unsigned int i = 0; i < factPredicateContainer.size(); i++)
			{
				//factPredicateSet.insert (factPredicateContainer[i]);
				
				//Find the proper Relation that MATCHES the CURRENT Fact Predicate's NAME
				map<string, Relation>::iterator relationNamesIterator = relationContainer.find(factPredicateContainer[i].toStringName());
				
				Relation properRelation;
						
				//If the CURRENT Fact Predicate's NAME is found inside the MAP then add the String Elements from the CURRENT Fact Predicate BODY into the Relation
				if (relationNamesIterator != relationContainer.end())
					{					
						vector <string> currentFactStrings;
						
						//cout << "Adding tuple values for the [" << factPredicateContainer[i].toStringName() << "] Relation" << endl << endl;
						//cout << "Tuple values being added are: " << factPredicateContainer [i].toStringBody() << endl << endl;
						
						for (unsigned int j = 0; j < factPredicateContainer[i].getBodyComponents().size(); j++)
							{
								currentFactStrings.push_back (factPredicateContainer[i].getBodyComponents()[j].getTokenValue());
							}
						
						Tuple tupleCreate (currentFactStrings);
						
						//cout << tupleCreate.toStringTupleValues();
						
						//Add the CURRENT Fact Predicate's String Elements as Tuple Values into the proper Relation Table
						relationNamesIterator->second.insertTuples (tupleCreate);
					}
			}
		
		
		//cout << "Now Checking if the Tuple Values were ACTUALLY SAVED in the Relation Tables" << endl << endl;

		/*
		for (std::map <string, Relation>::iterator it = relationContainer.begin(); it != relationContainer.end(); it++)
			{
				cout << "The number of Tuples in the current Relation, " << it->first << ", is" << it->second.getTupleCount() << endl << endl;
				
				it->second.displayTuples();
			}
		*/
		
		//cout << "Now Will Attempt to Match Queries" << endl << endl;
		
		
		stringstream outputStringStream;
	
		outputFileStream.open (outputFile);
	
		outputFileStream << "Scheme Evaluation" << endl << endl;
	
		outputFileStream << "Fact Evaluation" << endl << endl;
		
		//Match the Schemes and Facts information using each relation's tuple values
		displayMatchSchemesAndFacts(outputFile);
		
		outputStringStream << "Rule Evaluation" << endl << endl;
		
		outputFileStream << outputStringStream.str ();
		
		
		//Construct database information based upon the Rules submitted
		generateGraphs ();
		
		displayGraphs ();
		
		dfsForestReverseGraph ();
		
		displayPostOrderNumbers ();
		
		displaySCCOrder ();
		
		dfsForestForwardGraph ();
		
		displaySCC ();
		answerSCC ();
		
		//answerRules();
		outputFileStream << "Rule Evaluation Complete" << endl << endl;
		
		displayMatchSchemesAndFacts	(outputFile);
		matchQueries ();
	}
	
	
	
	
	
	
	
	
	
	
	
void Database::displayMatchSchemesAndFacts (char* outputFileName)
{
	
	stringstream outputStringStream;
	
	//outputFileStream.open (outputFileName);
	
	//outputFileStream << "Scheme Evaluation" << endl << endl;
	
	//outputFileStream << "Fact Evaluation" << endl << endl;
	
	for (std::map <string, Relation>::iterator it = relationContainer.begin(); it != relationContainer.end(); it++)
		{
			//outputFileStream << it->first << endl;
			outputStringStream << it->first << endl;
			
			vector <string> currentRelationTupleNames = it->second.getTupleNames();
			
			set <Tuple> currentRelationTuples = it->second.getTuples();
			
			for (std::set <Tuple>::iterator relationTupleIterator = currentRelationTuples.begin(); relationTupleIterator != currentRelationTuples.end(); relationTupleIterator++)
				{
					vector <string> currentTuple;
					
					currentTuple = *relationTupleIterator;
					
					for (unsigned int i = 0; i < currentTuple.size(); i++)
						{
							if (i == 0)
								{
									//outputFileStream << "  " << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
									outputStringStream << "  " << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
								}
							else if (i < currentTuple.size())
								{
									//outputFileStream << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
									outputStringStream << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
								}
							else
								{
									//outputFileStream << currentRelationTupleNames[i] << "=" << currentTuple[i];
									outputStringStream << currentRelationTupleNames[i] << "=" << currentTuple[i];
								}
						}
						
					//outputFileStream << endl;
					outputStringStream << endl;
					
					
				}
				
				outputStringStream << endl;
		}
		
		
				
		outputFileStream << outputStringStream.str();
		
		//Match Query Predicates with the proper Relation Table
		//matchQueries();
		//answerRules();
}








void Database::answerRules(set <int> &sccCurrentGroup)
	{
		
		//cout << "Entered answerRules which is in Database" << endl << endl;
		
		//cout << endl << endl << endl << "Entered Answer Rules function" << endl << endl << endl;
		stringstream outputStringStream;
		
		//Convert each Rule Body into a set of Relations in order to construct new Relations by JOINING the Relations made from the RULE BODY
		
		//relationContainerRules = relationContainer;
		
		//ruleRelationLoopCount = 0;
		if (isSimpleSCC (sccCurrentGroup) == true)
			{
				std::set <int>::iterator sccCurrentGroupIterator = sccCurrentGroup.begin ();
				
				int currentCC = *sccCurrentGroupIterator;
				
				outputStringStream << "SCC: R" << currentCC << endl;
				outputFileStream << outputStringStream.str ();
				
				convertRuleBodyToRelations (rulePredicateContainer [currentCC]);
			}
			
			
		else
			{
				outputStringStream << "SCC: ";
				for (std::set <int>::iterator sccCurrentGroupIterator = sccCurrentGroup.begin (); sccCurrentGroupIterator != sccCurrentGroup.end (); sccCurrentGroupIterator++)
				{
					int currentCC = *sccCurrentGroupIterator;
					
					 outputStringStream << "R" << currentCC << " ";
				}
				
				outputStringStream << endl;
				outputFileStream << outputStringStream.str ();
					//std::map <int, Node>::iterator forwardGraphIterator = forwardGraph.find (sccCurrentGroup [i]);
					
					/*
					if ((forwardGraphIterator -> second).dependsOn (sccCurrentGroup[i]) != true)
						{
							convertRuleBodyToRelations (rulePredicateContainer [sccCurrentGroup [i]]);
						}
					*/
					//else
						//{
							do
							{
								totalRelationTuplesCountAtStart = getTotalRelationTuplesCount ();//relationContainer.size();
								//ruleRelationCountAtStart = relationContainerRules.size();
								
								//cout << "Rule Relation Count At Start" << ruleRelationCountAtStart << endl << endl << endl;
								//cout << "Rule Relation Container Size At Start: " << relationContainerRules.size() << endl << endl << endl;
								
								/*
								for (unsigned int i = 0; i < rulePredicateContainer.size(); i++)
									{
										//outputStringStream << rulePredicateContainer[i].toStringHead() << " :- " << rulePredicateContainer[i].toStringBody() << endl;
										convertRuleBodyToRelations (rulePredicateContainer[i]);
									}
								*/
								
								
								for (std::set <int>::iterator sccCurrentGroupIterator = sccCurrentGroup.begin (); sccCurrentGroupIterator != sccCurrentGroup.end (); sccCurrentGroupIterator++)
									{
										//outputStringStream << "SCC: R" << sccCurrentGroup [i] << endl;
										//outputFileStream << outputStringStream.str ();
										int currentRuleIndex = *sccCurrentGroupIterator;
										
										convertRuleBodyToRelations (rulePredicateContainer [currentRuleIndex]);
									}
								
								//outputFileStream << outputStringStream.str ();
									
								//cout << "RELATION Container Size at End: " << getTotalRelationTuplesCount () << endl << endl << endl;
									
								//ruleRelationLoopCount++;
								
								//displayRulesAndTupleValues ();
								//relationContainerRules.clear ();
								
							} while (getTotalRelationTuplesCount () != totalRelationTuplesCountAtStart);//relationContainerRules.size() > ruleRelationCountAtStart); //&& relationContainer.size() > totalRelationCountAtStart);
						//}
			}
			
			outputFileStream << endl;
		//}
		
		//cout << "Rule Relation Container Size AFTER Generating all of the Relations from RULES: " << getTotalRelationTuplesCount () << endl << endl;
		
		/*
		cout << "The Relations that were generated AND the corresponding tuple values are: " << endl << endl << endl << endl;
		
		for (std::map <string, Relation>::iterator relationIterator = relationContainer.begin(); relationIterator != relationContainer.end(); relationIterator++)
			{
				string currentRelationName = relationIterator -> first;
				
				Relation currentRelation = relationIterator -> second;
				
				cout << "Current TOTAL Relation: " << endl << endl;
				cout << currentRelationName << endl << endl;
				
				//cout << "Current TOTAL RElation TUPLE VALUES:" << endl << endl;
				//currentRelation.displayTuples();
			}
		*/
		
		//I displayed this information here in Lab 4	
		//outputStringStream << endl << endl << "Converged after " << ruleRelationLoopCount << " passes through the Rules." << endl << endl;
		//outputFileStream << outputStringStream.str ();
		
		//outputStringStream << "Query Evaluation" << endl << endl;
		
		//outputFileStream << outputStringStream.str();
		
		//matchQueries();
		
		//for (unsigned int i = 0; i < rulePredicateContainer.size(); i++)
			//{
				//outputStringStream << rulePredicateContainer[i].toStringHead() << " :- " << rulePredicateContainer[i].toStringBody() << endl;
			//}
		
		//cout << "Converged after" << ruleRelationLoopCount << " times through the rules" << endl << endl;
		//outputStringStream << "Converged after " << ruleRelationLoopCount << " passes through the Rules." << endl << endl;
		//outputFileStream << outputStringStream.str ();
		//displayRuleEvaluationFollow (ruleRelationLoopCount);
		
		
		//cout << "Calling Function to Match Rule JOINED Body Relations to Head Predicates" << endl << endl;
		
		//convertJoinedRuleBodyRelationsToHeadPredicateRelations ();
		
		//I called  these here in Lab 4
		//displayMatchSchemesAndFacts (outputFile);
		//matchQueries();
	}
	
	
	
	
	
void Database::displayRuleEvaluationFollow (unsigned int ruleRelationLoopCount)
	{
		stringstream outputStringStream;
		
		for (unsigned int i = 0; i < rulePredicateContainer.size(); i++)
			{
				outputStringStream << rulePredicateContainer[i].toStringHead() << " :- " << rulePredicateContainer[i].toStringBody() << endl;
			}
		
		//cout << "Converged after" << ruleRelationLoopCount << " times through the rules" << endl << endl;
		outputStringStream << endl << endl << "Converged after " << ruleRelationLoopCount << " passes through the Rules." << endl << endl << endl;
		outputFileStream << outputStringStream.str ();
	}
	
	
	
	

//
//With the Current Rule, extract the BODY Predicats and Convert each to an associated Relation
void Database::convertRuleBodyToRelations (Rule currentRuleSubmit)
	{
		//cout << "Entered convertRuleBodyToRelations which is in Database" << endl << endl << endl;
		
		/*
		cout << "Current Rule to be Converted is: " << currentRuleSubmit.getHeadPredicate ().toStringName () << endl << endl;
		
		cout << "Relation associated with Current Rule, which is" << relationContainer [currentRuleSubmit.getHeadPredicate ().toStringName ()].getRelationName () << endl;
		cout << " has Tuple Values of: " << endl << endl;
		        
		        relationContainer [currentRuleSubmit.getHeadPredicate ().toStringName ()].displayTuples ();
		*/
		vector <Predicate> currentRuleBodyPredicates = currentRuleSubmit.getRuleBodyPredicates();
		
		vector <string> relationNames;
		
		set <Tuple> currentIterationTuples;
		//map <string, Relation> relationsToJoin;
		
		//Scheme tempScheme;
		
		//int predicateIndex;
		Relation r0;
		
		std::map<string, Relation>::iterator relationNamesIterator = relationContainer.find (currentRuleBodyPredicates[0].toStringName());
		
		if (relationNamesIterator != relationContainer.end())
			{
				r0 = relationNamesIterator->second;
				
				r0 = convertCurrentRulePredicateToRelation (r0, currentRuleBodyPredicates[0]);
			}
			
		//If there is only ONE Predicate in the Body of the current Rule, then the Relation Generated from the Predicate is the ONLY Relation for that Rule Body
		if (currentRuleBodyPredicates.size() == 1)//relationNamesIterator == relationContainer.end())
			{
				//r0.setRelationName (currentRuleSubmit.getHeadPredicate().toStringName());
				//cout << 
				
				r0 = r0.projectRuleHeadPredicate (currentRuleSubmit.getHeadPredicate ());
				
				//r0.convertColumnNames (currentRuleSubmit.getHeadPredicate ());
				
				
				
				currentIterationTuples = relationContainer [currentRuleSubmit.getHeadPredicate().toStringName()].insertTuplesSet (r0.getTuples ());
				
				r0.replaceTuples (currentIterationTuples);
				r0.setScheme (relationContainer [currentRuleSubmit.getHeadPredicate ().toStringName ()].getTupleNames ());
				
				
				relationContainerRules [currentRuleSubmit.getHeadPredicate().toStringName()] = r0;
			}
		
		
		else
		{
				//Extract each Predicate from the RULE BODY separately
				for (unsigned int i = 1; i < currentRuleBodyPredicates.size(); i++)
					{
						//predicateIndex = i;
						Relation r1;
						
						std::map<string, Relation>::iterator relationNamesIterator = relationContainer.find (currentRuleBodyPredicates[i].toStringName());
						
						if (relationNamesIterator != relationContainer.end())
							{
								r1 = relationNamesIterator->second;
								
								r1 = convertCurrentRulePredicateToRelation (r1, currentRuleBodyPredicates[i]);
							}
						/* Original Lab 4 Code
						//Find the Relation that Matches the current RULE BODY Predicate (if it exists)
						map<string, Relation>::iterator relationNamesIterator = relationContainer.find(currentRuleBodyPredicates[i].toStringName());
						
						
						//Convert the Current RULE BODY Predicate into a Relation
						if (relationNamesIterator != relationContainer.end())
							{
								Relation relationCopy = relationNamesIterator->second;
								
								relationCopy = convertCurrentRulePredicateToRelation (relationCopy, currentRuleBodyPredicates[i]);
								
								//Now that the Relation Matching the Current RULE BODY Predicate has been modified,
								//retain the Relation's name in its correct order in the RULE BODY (by inserting the name into the relationNames vector
								//And add the MODIFIED Relation into the Map
								relationNames.push_back (relationCopy.getRelationName());
								
								relationsToJoin [relationCopy.getRelationName()] = relationCopy;
							}
						*/	
						//checkRuleBodyRelations (relationsToJoin);
						
						r0 = joinRuleBodyRelations (currentRuleSubmit, r0, r1);//relationsToJoin);
						
						
						//r0 = r0.projectRuleHeadPredicate (currentRuleSubmit.getHeadPredicate ());
						
					}
			
					/*
					cout << endl << endl << endl << "Finished Joining Rule Body Relations for RULE " << currentRuleSubmit.getHeadPredicate ().toStringName () << endl << endl << endl;
					
					if (currentRuleSubmit.getHeadPredicate ().toStringName () == "f")
						{
							cout << "Tuples after JOINING for Rule f are: " << endl << endl;
							r0.displayTuples ();
						}
					*/
			
			
					r0 = r0.projectRuleHeadPredicate (currentRuleSubmit.getHeadPredicate ());
					
					//tempScheme = r0.getTupleNames ();
					
					/*
					if (currentRuleSubmit.getHeadPredicate ().toStringName () == "f")
						{
							cout << "Tuples after Projecting to f\'s Head Predicate are: " << endl << endl;
							r0.displayTuples ();
						}
						
						//r0.convertColumnNames (currentRuleSubmit.getHeadPredicate ());
						
						if (currentRuleSubmit.getHeadPredicate ().toStringName () == "r")
							{
								cout << "Displaying PROJECTED JOINED TuplE........................................" << endl << endl;
								r0.displayTuples();
							}
							
							
						if (currentRuleSubmit.getHeadPredicate ().toStringName () == "f")
							{
								cout << "Tuples Right BEFORE inserting SET of TUPLES into f are: " << endl << endl;
								
								relationContainer [currentRuleSubmit.getHeadPredicate ().toStringName ()].displayTuples ();
							}
						*/
						
						
					currentIterationTuples = relationContainer [currentRuleSubmit.getHeadPredicate ().toStringName ()].insertTuplesSet (r0.getTuples ());
						
						/*
						if (currentRuleSubmit.getHeadPredicate ().toStringName () == "f")
							{
								cout << "Tuples after Inserting SET of Tuples into f are: " << endl << endl;
								//r0.displayTuples ();
								relationContainer [currentRuleSubmit.getHeadPredicate ().toStringName ()].displayTuples ();
								
							}
						*/
						
						r0.replaceTuples (currentIterationTuples);
				r0.setScheme (relationContainer [currentRuleSubmit.getHeadPredicate ().toStringName ()].getTupleNames ());
				
				relationContainerRules [currentRuleSubmit.getHeadPredicate ().toStringName ()] = r0;
						
			}	
				//r0.setRelationName (currentRuleSubmit.getHeadPredicate().toStringName());
				//r0 = r0.projectRuleHeadPredicate (currentRuleSubmit.getHeadPredicate ());
				//r0.setScheme (tempScheme);
				
				//relationContainer [r0.getRelationName()] = r0;
				
				displayRulesAndTupleValues (currentRuleSubmit);
				
				//ruleRelationsCreated++;
		/*	
		if (currentRuleSubmit.getHeadPredicate ().toStringName () == "r")
			{
				cout << endl << endl << endl << endl << endl;	
				cout << "Displaying the resulting Relation" << endl;
				
				cout << "Joined Relation's Original NAME: " << r0.getRelationName() << endl << endl;
				
				cout << "Joined Relation's SCHEMA: " << r0.getTupleNames().toStringSchemeValues() << endl << endl;
				
				cout << "Now Dislpaying Joined TUPLE Values: " << endl;
				r0.displayTuples();
			}
		*/
		
		//cout << "Current Relation Receiving New Tuples: " << relationContainer [currentRuleSubmit.getHeadPredicate ().toStringName ()].getRelationName () << endl << endl << endl;
		//relationContainer [currentRuleSubmit.getHeadPredicate ().toStringName ()].displayTuples ();
		
		//cout << endl << endl << endl << endl;
		
		//displayRulesAndTupleValues ();//relationContainer [currentRuleSubmit.getHeadPredicate ().toStringName ()]);
		//Now that the Current RULE BODY Predicates have all been converted into Relations, I will attempt to JOIN those Relations
		//This is where I left off at 5:46 PM on 3-12-2016
		
		//checkRuleBodyRelations (relationsToJoin);
				
		//joinRuleBodyRelations (relationsToJoin);
	}
	
	
	
	
	
//Modify the Relation that matches the Current RULE BODY Predicate	
Relation Database::convertCurrentRulePredicateToRelation (Relation relationCopy, Predicate currentRulePredicate)
	{
		//cout << "Entered convertCurrentRulePredicateToRelation which is in Database" << endl << endl;
		
		//cout << "Current Relation is " << relationCopy.getRelationName() << endl << endl;
		
		//cout << "Original Column Names Are: " << relationCopy.getTupleNames().toStringSchemeValues() << endl << endl;
		
		//cout << "Original Tuple Values are: " << endl;
		//relationCopy.displayTuples();
		
		vector <Parameter> currentRulePredicateBody = currentRulePredicate.getBodyComponents();
		
		//For each item in the Current RULE BODY Predicate, identify whether the element is a STRING or ID, and modify the Current RELATION appropriately
		for (unsigned int i = 0; i < currentRulePredicateBody.size(); i++)
			{
				if (currentRulePredicateBody[i].getTokenType() == "STRING")
					{
						relationCopy = relationCopy.selectOnString (i, currentRulePredicateBody[i].getTokenValue());
					}
					
				else if (currentRulePredicateBody[i].getTokenType() == "ID")
					{
						//This may affect the locations stored for all identified Variables, so I may need to copy the function answerQueryIDTest and
						//create a new function and call that NEW function here
						vector <int> currentRuleVariableIndexContainer = answerQueryIDTest (currentRulePredicate, i);
						
						string currentRulePredicateVariable = currentRulePredicateBody[i].getTokenValue();
						
						relationCopy = relationCopy.selectOnID (currentRuleVariableIndexContainer, currentRulePredicateVariable);
					}
					
				else
					{
					}
			}
		
		//Show the Modifications that have been achieved to the current Relation
		
		
		//cout << "After converting the current Rule BODY Predicate to a Relation" << endl << endl << endl;
		
		//cout << "Relation " << relationCopy.getRelationName () << endl << endl;
		//cout << "Now has Column Names" << relationCopy.getTupleNames ().toStringSchemeValues () << endl << endl;
		
		//cout << "Tuple Values NOW Are: " << endl << endl;
		//relationCopy.displayTuples ();
		
		
		//I think this is causing problems... segmentation fault, but i don't know why 12:29 3-14-16
		relationCopy = relationCopy.project (currentRulePredicate);
		
		//relationCopy = relationCopy.project (currentRulePredicate);
		
		relationCopy.convertColumnNames (currentRulePredicate);
		
		//cout << "Just Converted the RULE Predicate to a Relation" << endl << endl;
		
		//cout << "The Relation is " << relationCopy.getRelationName() << endl;
		//cout << "The Column Names NOW are" << relationCopy.getTupleNames().toStringSchemeValues() << endl << endl;
		//cout << "The Tuple Values are: " << endl;
		//relationCopy.displayTuples();
		
		return relationCopy;
	}






//Match Query Predicates with the proper Relation Table 
void Database::matchQueries()
	{	
		
		//cout << "Entered match Queries" << endl << endl;
		stringstream outputStringStream;
		
		outputStringStream << "Query Evaluation" << endl << endl;
		outputFileStream << outputStringStream.str ();
		
		//Look at each Query Predicate
		for (unsigned int i = 0; i < queryPredicateContainer.size(); i++)
			{
				
				//Find the proper Relation that MATCHES the CURRENT Query Predicate's NAME
				map <string, Relation>::iterator mapIterator = relationContainer.find (queryPredicateContainer[i].toStringName());
				
				Relation relationCopy = mapIterator->second;
				
				//If the CURRENT Query Predicate's NAME is found in the MAP, copy the Tuple Values from that Relation in order to TRY answering the Query
				if (mapIterator != relationContainer.end())
					{
						//Copy the Tuple Values from the proper Relation in the MAP in order to TRY answering the Query
						relationTuplesCopy =  mapIterator->second.getTuples();
						
						
						//If the CURRENT Query Predicate's NAME is in the MAP, AND the Tuple Values from that Relation Table in the MAP were successfully copied,
						//then submit those Tuple Values to check whether they can answer the CURRENT Query
						if (relationTuplesCopy.size() >= 0)
							{
								
								//cout << "About to go to the Answer Query Function. The Query attempting to answer is: " << queryPredicateContainer[i].toStringBody() << endl;
								
								//cout << "The Tuple Values being tested for whether they can answer this Query are: " << endl;
								//mapIterator->second.displayTuples();
								
								Predicate currentQuerySubmit = queryPredicateContainer[i];
								
								answerQuery (relationCopy, /*relationTuplesCopy,*/ currentQuerySubmit);
							}
					}
			}
	}










//Check whether the submitted Tuple Values can answer the submitted Query
void Database::answerQuery (Relation relationCopy, /*set <Tuple> relationTuplesCopy,*/ Predicate currentQuery)
	{
		//cout << "Entered the Answer Query Function" << endl << endl;
		
		//cout << endl << endl << endl << "Attempting to Answer Query: " << currentQuery.toStringName () << currentQuery.toStringBody ()<< endl << endl << endl;
	
		//Vector to hold the Parameter Values from the CURRENT Query Predicate Body
		vector <Parameter> currentQueryBody = currentQuery.getBodyComponents();
		
		//MAP to hold Vectors of (Potentially MULTIPLE Different Variables) Variable locations within the CURRENT Query Predicate Body
		map <string, vector <int>> queryVariableIndexContainer;
		
		//cout << "Attempting to answer Query: " << endl;
		//cout << currentQuery.toStringBody() << endl << endl;
		
		vector <int> queryVariableIndexes;
	
		//Look at each Element in the CURRENT Query Predicate Body
		for (unsigned int i = 0; i < currentQueryBody.size(); i++)
			{
				//cout << "Iterating through the CURRENT Query Predicate Body" << endl;
				//cout << "At element [" << i << "] which is: " << currentQueryBody[i].getTokenValue() << endl << endl;
			
				//If the CURRENT Element is a String, check whether that String Value is matched by RELATION Table Values
				if (currentQueryBody[i].getTokenType() == "STRING")
					{
						//cout << "Calling the Answer Query STRINGS function" << endl;
	
						relationCopy = relationCopy.selectOnString (i, currentQueryBody[i].getTokenValue());
						
					}
				
				
				
				//This is the portion I'm currently working on (note left 10:00 PM 2/26/2016)
				//If the CURRENT Element in the Query Predicate is NOT a String, then it MUST be a ID/Variable
				//else if (queryVariableIndexContainer[currentQueryBody[i].getTokenValue()].size() == 0)
				else if (currentQueryBody[i].getTokenType() == "ID")
					{
						
						//cout << "Calling the Answer Query ID function" << endl;
						//cout << "Calling the selectOnID function in Relation.h" << endl;
						
						vector <int> currentVariableIndexContainer = answerQueryIDTest (currentQuery, i);
						
						string currentVariable = currentQueryBody[i].getTokenValue();
						
						relationCopy = relationCopy.selectOnID (currentVariableIndexContainer, currentVariable);
					}
				
				
				else
					{
	
					}
			}
		
		displaySelectProjectRename (relationCopy, currentQuery);
	}
	
	
	
	
	
	
	
//Output the results from the Current Relation	
void Database::displaySelectProjectRename (Relation currentOutputRelation, Predicate currentQuery)
	{
		//cout << "Entered the Closing Function, which is displaySelectProjectRename " << endl << endl;
		
		stringstream outputStringStream;
		
		//outputStringStream << "Currently outputting Relation: " << currentOutputRelation.getRelationName() << "\t which has " << currentOutputRelation.getTupleCount() << " Tuples" << endl << endl;
		
		if (currentOutputRelation.getTupleCount() > 0)
			{
				//cout << currentQuery.toStringName() << currentQuery.toStringBody() << "? Yes(" << currentOutputRelation.getTupleCount() << ")" << endl;
				outputStringStream << currentQuery.toStringName() << currentQuery.toStringBody() << "? Yes(" << currentOutputRelation.getTupleCount() << ")" << endl;
				//outputFileStream << outputStringStream.str();
				
				//cout << "select" << endl;
				//cout << currentOutputRelation.displayTuplesSelect();
				outputStringStream << "select" << endl;
				outputStringStream << currentOutputRelation.displayTuplesSelect();
				//outputFileStream << outputStringStream.str();
				
				//cout << "project" << endl;
				//cout << currentOutputRelation.displayTuplesProjectRename (queryTotalVariableIndexContainer, currentOutputRelation.getTupleNames());
				outputStringStream << "project" << endl;
				currentOutputRelation = currentOutputRelation.project (currentQuery);
				outputStringStream << currentOutputRelation.displayTuplesProject ();
				//cout << "Calling Display TUPLES" << endl << endl;
				//currentOutputRelation.displayTuples ();
				//cout << currentOutputRelation.displayTuplesProject () << endl;
				//cout << "Called Display TUPlES" << endl << endl;
				//outputStringStream << "project" << endl;
				//outputStringStream << currentOutputRelation.displayTuplesProjectRename (queryTotalVariableIndexContainer, currentOutputRelation.getTupleNames());
				//outputFileStream << outputStringStream.str();
				
				//cout << "rename" << endl;
				outputStringStream << "rename" << endl;
				currentOutputRelation.convertColumnNames (currentQuery);
				outputStringStream << currentOutputRelation.displayTuplesProject () << endl;
				//cout << currentOutputRelation.displayTuplesProject () << endl;
				//cout << outputStringStream << currentOutputRelation.displayTuplesProjectRename (queryTotalVariableIndexContainer, currentOutputRelation.getTupleNames()) << endl;
				//currentOutputRelation = currentOutputRelation.project (currentQuery);
				//currentOutputRelation.displayTuples();
				//outputStringStream << "rename" << endl;
				//outputStringStream << currentOutputRelation.displayTuplesProjectRename (queryTotalVariableIndexContainer, currentOutputRelation.getTupleNames()) << endl;
				outputFileStream << outputStringStream.str();
			}
			
		else
			{
				//cout << currentQuery.toStringName() << currentQuery.toStringBody() << "? No" << endl << endl;
				//stringstream outputStringStream;
				outputStringStream << currentQuery.toStringName() << currentQuery.toStringBody() << "? No" << endl << endl;
				
				outputFileStream << outputStringStream.str();
			}
			
		//queryTotalVariableIndexContainer.clear();
		//queryTotalVariableContainer.clear();
	}
	
	
	
	
	
	
	
	
vector <int> Database::answerQueryIDTest (Predicate currentQuery, unsigned int i)
	{
		//cout << "Entered Answer Query ID Test" << endl << endl;
		
		set <Tuple> temporaryRelationTuplesCopyReplace;
		
		vector <Parameter> currentQueryBody = currentQuery.getBodyComponents();
		
		//cout << "Found a Variable in the CURRENT Query Predicate" << endl << endl;
		//cout << "The Variable Value is: " << currentQueryBody[i].getTokenValue() << endl << endl;
		
		//Add the CURRENT Index to the Vector of ID/Variable Index locations within the CURRENT Query Predicate Body
		vector <int> currentVariableIndexContainer;
		currentVariableIndexContainer.push_back (i);
		
		vector <int> currentVariableIndexes = queryTotalVariableContainer[currentQueryBody[i].getTokenValue()];
		
		if (currentVariableIndexes.size() == 0)
		{
			queryTotalVariableContainer[currentQueryBody[i].getTokenValue()].push_back (i);
			
			queryTotalVariableIndexContainer[i].push_back (i);
		}
		
		//cout << "Creating a New Entry in the Variable INDEX MAP for Variable " << currentQueryBody[i].getTokenValue() << endl << endl;
		
		//Add the Vector of Variable locations to the MAP with the KEY of the ID/Variable Value
		queryVariableIndexContainer[currentQueryBody[i].getTokenValue()] = currentVariableIndexContainer;
	
		
		//Store the INDEX for each occurrence of the CURRENT Variable
		for (unsigned int l = i; l < currentQueryBody.size(); l++)
			{
				//If the SAME ID/Variable Value is found AGAIN in the CURRENT Query Predicate Body, store the new location to the Vector
				if (currentQueryBody[l].getTokenValue() == currentQueryBody[i].getTokenValue() && l != i)
					{
						
						currentVariableIndexContainer.push_back (l);
						
						queryTotalVariableIndexContainer[i].push_back (l);
						
					}
			}
			
			return currentVariableIndexContainer;
	}
	
	
	
	
	
	
void Database::checkRuleBodyRelations (map <string, Relation> relationsToJoinSubmit)
	{
		for (std::map <string, Relation>::iterator ruleConvertedRelationsIterator = relationsToJoinSubmit.begin(); ruleConvertedRelationsIterator != relationsToJoinSubmit.end(); ruleConvertedRelationsIterator++)
			{
				Relation currentRelation = ruleConvertedRelationsIterator -> second;
				
				//cout << "Current Relation that was CONVERTED from Rule BODY Predicates: " << currentRelation.getRelationName() << endl << endl;
				
				//cout << "Displaying the current TUPLES: " << endl << endl;
				
				//currentRelation.displayTuples();
			}
	}
	
	
	
	
//This is where I left off at 9:46 PM on 3-19-2016
Relation Database::joinRuleBodyRelations (Rule currentRuleSubmit, Relation r0Submit, Relation r1Submit)//map <string, Relation> relationsToJoinSubmit)
	{
		
		//cout << "Entered joinRuleBodyRelations function in Database" << endl;
		//cout << "This is the step of trying to Join Relations generated from Rule BODY Predicates" << endl << endl;
		/*
		 Join

			Join must be able to join two relations that have no common attribute names.

			Join must be able to join two relations that have multiple common attribute names.

			The following pseudo-code describes one way to compute the join of relations r1 and r2.

				make the scheme s for the result relation
					(combine r1's scheme with r2's scheme)

				make a new empty relation r using scheme s

				for each tuple t1 in r1
					for each tuple t2 in r2

					if t1 and t2 can join
						join t1 and t2 to make tuple t
						add tuple t to relation r
					end if

					end for
				end for

			Note that the following operations used in the join should be decomposed into separate routines.

				combining r1's scheme with r2's scheme
				testing t1 and t2 to see if they can join
				joining t1 and t2 
		*/
		
		set <Scheme> currentRuleBodySchemesToJoin;
		
		set <set <Tuple>> currentRuleBodyTuplesToJoin;
		
		currentRuleBodySchemesToJoin.insert (r0Submit.getTupleNames());
		currentRuleBodySchemesToJoin.insert (r1Submit.getTupleNames());
		
		currentRuleBodyTuplesToJoin.insert (r0Submit.getTuples());
		currentRuleBodyTuplesToJoin.insert (r1Submit.getTuples());
		
		/* Original Lab 4 Code from when I was attempting to construct the JOINED Relation from a Map of Relations
		for (map <string, Relation>::iterator ruleBodyRelationsIterator = relationsToJoinSubmit.begin(); ruleBodyRelationsIterator != relationsToJoinSubmit.end(); ruleBodyRelationsIterator++)
			{
				Relation currentRuleBodyRelation = ruleBodyRelationsIterator -> second;
				
				currentRuleBodySchemesToJoin.insert (currentRuleBodyRelation.getTupleNames());
				
				currentRuleBodyTuplesToJoin.insert (currentRuleBodyRelation.getTuples());
			}
			
		
		cout << "These are the Schemes of the Relations I am trying to join: " << endl << endl;
		
		string schemesToJoinDisplay;
		
		for (std::set <Scheme>::iterator currentSchemesToJoinIterator = currentRuleBodySchemesToJoin.begin(); currentSchemesToJoinIterator != currentRuleBodySchemesToJoin.end(); currentSchemesToJoinIterator++)
			{
				Scheme currentScheme = *currentSchemesToJoinIterator;
				
				schemesToJoinDisplay += currentScheme.toStringSchemeValues() + "\n";
			}
			
		cout << schemesToJoinDisplay << endl;
		*/
		
		
		vector <pair <int, int>> currentSchemeMatchIndices;
			
		Scheme currentRuleBodyJoinedSchemes = joinRuleBodyRelationSchemes (r0Submit.getTupleNames(), r1Submit.getTupleNames(), currentSchemeMatchIndices);//currentRuleBodySchemesToJoin);
		
		//Tuple currentRuleBodyRelationNewTuple = joinRuleBodyRelationTuples (currentRuleBodyRelation);
		
		set <Tuple> currentRuleBodyJoinedTuples = joinRuleBodyRelationTuples (currentRuleSubmit, r0Submit.getTupleNames(), r1Submit.getTupleNames(), r0Submit.getTuples(), r1Submit.getTuples(), currentSchemeMatchIndices);
		
		joinSchemesMatchIndices.clear();
		
		Relation joinedRelation (r0Submit.getRelationName() + r1Submit.getRelationName(), currentRuleBodyJoinedSchemes);
		
		joinedRelation.insertTuplesSet (currentRuleBodyJoinedTuples);
		
		return joinedRelation;
	}
	
	
	
//This is where I left of at 9:46 PM on 3-19-2016
//This is where I left off at 9:24 PM on 3-21-2016
//This seems to successfully join the parameter values from multiple predicates into one new scheme
Scheme Database::joinRuleBodyRelationSchemes (Scheme s0Submit, Scheme s1Submit, vector <pair <int, int>> &currentSchemeMatchIndices)//set <Scheme> currentRuleBodySchemesToJoinSubmit)
	{
		//cout << "Entered the Join SCHEMES function in Database" << endl << endl;
		
		Scheme resultScheme (s0Submit);
		
		//vector <pair <int, int>>
		
		for (unsigned int i = 0; i < s0Submit.size(); i++)
			{
				//if (resultScheme.contains (s1Submit [i]) == false)
					//{
						//resultScheme.push_back (s1Submit [i]);
					//}
					
					for (unsigned int j = 0; j < s1Submit.size(); j++)
						{
							if (s0Submit [i] == s1Submit [j])
								{
									pair <int, int> currentPair (i, j);
									
									currentSchemeMatchIndices.push_back (currentPair);
									
									break;
								}
							
							else
								{
									if (resultScheme.contains (s1Submit [j])== false)
										{
											resultScheme.push_back (s1Submit [j]);
										}
								}
						}
			}
		
		/*
		for (set <Scheme>::iterator currentRuleSchemesIterator = currentRuleBodySchemesToJoinSubmit.begin(); currentRuleSchemesIterator != currentRuleBodySchemesToJoinSubmit.end(); currentRuleSchemesIterator++)
			{
				Scheme currentRuleScheme = *currentRuleSchemesIterator;
				
						for (unsigned int i = 0; i < currentRuleScheme.size(); i++)
							{
								if (resultScheme.contains (currentRuleScheme[i]) == false)
									{
										resultScheme.push_back (currentRuleScheme[i]);
									}
								
									
								//else
									//{
										//joinSchemesMatchIndices.push_back (i);
									//}
								
							}
			}
		*/
		
		//Scheme testScheme;
		
		//cout << "Resulting JOINED Scheme: " << resultScheme.toStringSchemeValues() << endl << endl;
		
		return resultScheme;
	}
	









//This is where I left of at 9:46 PM on 3-19-2016
//This is where I left of at 12:39 PM on 3-23-2016
//This is where I left off at 9:53 PM on 3-23-16
//My Tuple values show up properly when the ORIGINAL tuple values are present, but for some reason are lost COMPLETELY when trying to join them
set <Tuple> Database::joinRuleBodyRelationTuples (Rule currentRuleSubmit, Scheme s0Submit, Scheme s1Submit, set <Tuple> t0Submit, set <Tuple> t1Submit, vector <pair <int, int>> &currentSchemeMatchIndices)//Relation currentRuleBodyRelationSubmit)
	{
		//cout << "Entered Join Rule Body Relation Tuples function in Database" << endl;
		//cout << "This is the FIRST stage of Attempting to Join Tuples" << endl << endl;
		
		/*
		cout << endl << endl << endl << endl;
		cout << "Entered the FIRST phase of Joining Tuples" << endl << endl;
		cout << "Trying to join Tuple Set 0 with Tuple values: " << endl;
		
		stringstream tupleValuesToJoinDisplay;
		
		for (std::set <Tuple>::iterator t0Iterator = t0Submit.begin(); t0Iterator != t0Submit.end(); t0Iterator++)
			{
				Tuple t0CurrentTuple = *t0Iterator;
				
				tupleValuesToJoinDisplay << t0CurrentTuple.toStringTupleValues() << endl;
			}
			
			
		tupleValuesToJoinDisplay << endl << endl;
		tupleValuesToJoinDisplay << "Trying to join above Tuple Values with Set 1 Tuple Values: " << endl;
		
		for (std::set <Tuple>::iterator t1Iterator = t1Submit.begin(); t1Iterator != t1Submit.end(); t1Iterator++)
			{
				Tuple t1CurrentTuple = *t1Iterator;
				
				tupleValuesToJoinDisplay << t1CurrentTuple.toStringTupleValues() << endl;
			}
			
		cout << tupleValuesToJoinDisplay.str() << endl << endl << endl << endl;
		*/
		
		set <Tuple> joinedTuples;
		
		//bool joinable = true;
		
		//Iterate through the Indices where the SCHEMES matched
		//for (unsigned int i = 0; i < joinSchemesMatchIndices.size(); i++)
			//{
				
				//Iterate through the Tuples and COMPARE the values at each Index where the SCHEMES matched... if ALL values at these indices in Tuples match, the Tuples CAN join
				for (std::set <Tuple>::iterator tupleSetIterator0 = t0Submit.begin(); tupleSetIterator0 != t0Submit.end(); tupleSetIterator0++)
					{
						Tuple currentTuple0 = *tupleSetIterator0;
						
						for (std::set <Tuple>::iterator tupleSetIterator1 = t1Submit.begin(); tupleSetIterator1 != t1Submit.end(); tupleSetIterator1++)
							{
								Tuple currentTuple1 = *tupleSetIterator1;
								
								//If a pair of non-matching values is found inside the Tuples at an Index where the SCHEMES matched, then the Tuples CANNOT join
								if (checkJoinTuples (currentTuple0, currentTuple1, currentSchemeMatchIndices) == true)
									{
										Tuple joinedTuple = joinCurrentTuples (currentRuleSubmit, s0Submit, s1Submit, currentTuple0, currentTuple1, currentSchemeMatchIndices);
										
										/*
										if (currentRuleSubmit.getHeadPredicate ().toStringName () == "f")
											{
												cout << "___________Adding_________" << joinedTuple.toStringTupleValues () << " to the set of JOINED Tuples to be Added to f" << endl << endl;
											}
										*/
										
										joinedTuples.insert (joinedTuple);
										
										//joinable = false;
									}
									
								else
									{
										//cout << "Tuples were NOT joinable" << endl << endl;
									}
							}
					}
			//}
			
		/* 
		if (joinable != false)
			{
				Tuple joinedTuple = joinCurrentTuples (joinSchemesMatchIndices, currentTuple0, currentTuple1);
										
				joinedTuples.insert (joinedTuple);
			}
		*/
		return joinedTuples;//testTuple;
	}
	
	
	
	
	



bool Database::checkJoinTuples (Tuple tupleSubmit0, Tuple tupleSubmit1, vector <pair <int, int>> &currentSchemesMatchIndices)
	{
		
		//cout << "Entered Check Join Tuples function in Database" << endl;
		//cout << "This is the SECOND stage of Attempting to Join Tuples" << endl << endl;
		//cout << "Checking whether the two current tuples can match" << endl << endl << endl;
		
		//bool joinable = true;
		
		//cout << "Trying to match Tuple0 and tuple1" << endl << endl;
		
		//cout << "Scheme 0: " << s0Submit.toStringSchemeValues() << endl << endl;
		
		//cout << "Tuple0: " << endl;
		//cout << tupleSubmit0.toStringTupleValues() << endl << endl;
		
		//cout << "Scheme 1: " << s1Submit.toStringSchemeValues() << endl << endl;
		
		//cout << "Tuple1: " << endl;
		//cout << tupleSubmit1.toStringTupleValues() << endl << endl;
		
		
		/* This original code for Lab 4 was not working because it was based on a FAULTY container of "matched scheme indices" which was inaccurate
		//Iterate through the Indices where the SCHEMES matched
		for (unsigned int i = 0; i < joinSchemesMatchIndices.size(); i++)
			{
				
				//Iterate through the Tuples and COMPARE the values at each Index where the SCHEMES matched... if ALL values at these indices in Tuples match, the Tuples CAN join
				//for (std::set <Tuple>::iterator tupleSetIterator0 = t0Submit.begin(); tupleSetIterator0 != t0Submit.end(); tupleSetIterator0++)
					//{
						//Tuple currentTuple0 = *tupleSetIterator0;
						
						//for (std::set <Tuple>::iterator tupleSetIterator1 = t1Submit.begin(); tupleSetIterator1 != t1Submit.end(); tupleSetIterator1++)
							//{
								//Tuple currentTuple1 = *tupleSetIterator1;
								
								//If a pair of non-matching values is found inside the Tuples at an Index where the SCHEMES matched, then the Tuples CANNOT join
								if (tupleSubmit0 [joinSchemesMatchIndices[i]] != tupleSubmit1 [joinSchemesMatchIndices[i]])
									{
										//Tuple joinedTuple = joinCurrentTuples (joinSchemesMatchIndices[i], currentTuple0, currentTuple1);
										
										//joinedTuples.insert (joinedTuple);
										
										joinable = false;
									}
							//}
					//}
			}
		*/
		
		/*
		for (unsigned int i = 0; i < s0Submit.size(); i++)
			{
				for (unsigned int j = 0; j < s1Submit.size(); j++)
					{
						cout << "Scheme 0 VALUE is: " << s0Submit.getColumnName (i) << endl << endl;
						cout << "Scheme 1 VALUE is: " << s1Submit.getColumnName (j) << endl << endl;
						
						cout << "Tuple 0 VALUE is: " << tupleSubmit0.getTupleValue (i) << endl << endl;
						cout << "Tuple 1 VALUE is: " << tupleSubmit1.getTupleValue (j) << endl << endl;
						
						if (s0Submit [i] == s1Submit [j])
							{	
								if (tupleSubmit0 [i] != tupleSubmit1 [j])
									{
										cout << endl << endl << endl << "Current Tuples ABOVE are NOT joinable" << endl << endl << endl;
										
										joinable = false;
									}
							}
					}
			}
			*/
			
			for (unsigned int i = 0; i < currentSchemesMatchIndices.size(); i++)
				{
					if (tupleSubmit0 [currentSchemesMatchIndices[i].first] != tupleSubmit1 [currentSchemesMatchIndices[i].second])
						{
							return false;
						}
				}
		
		return true;
		//return joinable;
	}
	
	
	
	
	






//Join the currently submitted pair of Tuples
//This is where I left of at 9:22 PM on 3-23-16
//I need to figure out how to be able to join Tuples that may possibly match at multiple indices
Tuple Database::joinCurrentTuples (Rule currentRuleSubmit, Scheme s0Submit, Scheme s1Submit, Tuple tupleSubmit0, Tuple tupleSubmit1, vector <pair <int, int>> &currentSchemesMatchIndices)
	{
		//cout << "Entered Join Current Tuples function in Database" << endl;
		//cout << "This is the Stage where I ACTUALLY Try to Join Tuples" << endl << endl << endl;
		
		//cout << "Trying to match Tuple0 and tuple1" << endl << endl;
		
		//cout << "Scheme 0: " << s0Submit.toStringSchemeValues() << endl << endl;
		
		//cout << "Tuple0: " << endl;
		//cout << tupleSubmit0.toStringTupleValues() << endl << endl;
		
		//cout << "Scheme 1: " << s1Submit.toStringSchemeValues() << endl << endl;
		
		//cout << "Tuple1: " << endl;
		//cout << tupleSubmit1.toStringTupleValues() << endl << endl;
		
		
		//cout << "Intiating the Joined Tuple" << endl << endl << endl;
		Tuple joinedTuple (tupleSubmit0);
		//cout << "Started the Joined Tuple" << endl << endl << endl;
		
		for (unsigned int i = 0; i < tupleSubmit1.size(); i++)
			{
				bool currentMatchValue = false;
				
				for (unsigned int j = 0; j < currentSchemesMatchIndices.size(); j++)
					{
						if (i == currentSchemesMatchIndices [j].second)
							{
								currentMatchValue = true;
							}
					}
					
				if (currentMatchValue == false)
					{
						joinedTuple.push_back (tupleSubmit1.getTupleValue (i));
					}
			}
			
			
		/*	
		if (currentRuleSubmit.getHeadPredicate ().toStringName () == "r")
			{
				cout << endl << endl << endl;
				cout << "____________________________________________ Just JOINED a Tuple for rule R _______________________________" << endl;
				cout << endl << endl << endl;
			}
		*/
		
		//cout << endl << endl << endl << endl << endl;
		
		//cout << "Joined Tuple Values: " << joinedTuple.toStringTupleValues() << endl << endl << endl;
		/*
		unsigned int j = 0;
		
		while (j < index)
			{
				joinedTuple.push_back (tupleSubmit1 [j]);
				
				j++;
			}
			
		j = index + 1;
		
		while (j < tupleSubmit1.size())
			{
				joinedTuple.push_back (tupleSubmit1 [j]);
				
				j++;
			}
		*/	
		
		return joinedTuple;
	}
	
	
	
	
	
	
	
	
	
	
	
void Database::convertJoinedRuleBodyRelationsToHeadPredicateRelations ()
	{
		stringstream outputStringStream;
		
		//cout << endl << endl << endl << endl << endl << "Rule Evaluation" << endl << endl << endl << endl << endl;
		//outputStringStream << "Rule Evaluation" << endl << endl;
		outputFileStream << outputStringStream.str ();
		
		for (unsigned int i = 0; i < rulePredicateContainer.size(); i++)
			{
				//cout << rulePredicateContainer[i].toStringHead() << " :- " << rulePredicateContainer[i].toStringBody() << endl << endl;
				//outputStringStream << rulePredicateContainer[i].toStringHead() << " :- " << rulePredicateContainer[i].toStringBody() << endl << endl;
				//outputFileStream << outputStringStream.str ();
				
				//convertCurrentRuleHeadPredicateToRelation (rulePredicateContainer [i].getHeadPredicate());
				convertCurrentRuleHeadPredicateToRelation (rulePredicateContainer [i]);//.getHeadPredicate());
			}
		//outputFileStream << outputStringStream.str();
		displayRuleEvaluationFollow (ruleRelationLoopCount);
	}
	
	
	
	
void Database::convertCurrentRuleHeadPredicateToRelation (Rule currentRule)//Predicate currentRuleHeadPredicate)
	{
		Predicate currentRuleHeadPredicate = currentRule.getHeadPredicate ();
		
		stringstream outputStringStream;
		
		//outputStringStream << currentRule.toStringHead() << " :- " << currentRule.toStringBody() << endl;
		
		//cout << "Converting the Current Rule Head Predicate To Relation" << endl << endl;
		
		//cout << "Current Rule Head Predicate is: " << currentRuleHeadPredicate.toStringName() << endl;
		//cout << "It has body elements: " << currentRuleHeadPredicate.toStringBody() << endl << endl;
		
		//string currentRuleHeadPredicateName = currentRuleHeadPredicate.toStringName();
		Relation currentRuleHeadPredicateRelation;
		
		map<string, Relation>::iterator ruleHeadPredicateRelationIterator = relationContainerRules.find (currentRuleHeadPredicate.toStringName());
		
		if (ruleHeadPredicateRelationIterator != relationContainerRules.end())
			{
				currentRuleHeadPredicateRelation = ruleHeadPredicateRelationIterator->second;
			}
			
			
		//cout << "Found the JOINED Relation that matches the Current Rule HEAD Predicate" << endl << endl;
		
		//cout << "The JOINED Relation that matches the Current Rule Head Predicate is: " << currentRuleHeadPredicateRelation.getRelationName() << endl << endl;
		
		//cout << "The Column NAMES of the JOINED Relation that matches the current Rule Head Predicate ARE:" << currentRuleHeadPredicateRelation.getTupleNames().toStringSchemeValues() << endl << endl;
		
		//cout << "The JOINED Relation that matches the Current Rule Head Predicate has TUPLE values of: " << endl;
		//currentRuleHeadPredicateRelation.displayTuples();
		
		vector <Parameter> currentRuleHeadPredicateBodyComponents = currentRuleHeadPredicate.getBodyComponents();
		
		Scheme currentRuleHeadPredicateScheme;
		
		for (unsigned int i = 0; i < currentRuleHeadPredicateBodyComponents.size(); i++)
			{
				//currentRuleHeadPredicateScheme.push_back (currentRuleHeadPredicateBodyComponents [i].getTokenValue());
				if (currentRuleHeadPredicateBodyComponents [i].getTokenType ()== "STRING")
					{
						currentRuleHeadPredicateRelation = currentRuleHeadPredicateRelation.selectOnString (i, currentRuleHeadPredicateBodyComponents [i].getTokenValue());
						
						currentRuleHeadPredicateRelation.displayTuples();
					}
					
				if (currentRuleHeadPredicateBodyComponents [i].getTokenType ()== "ID")
					{
						//cout << "Matching current Rule HEAD Predicate on ID" << endl << endl << endl;
						
						vector <int> currentRuleVariableIndexContainer = answerQueryIDTest (currentRuleHeadPredicate, i);
						
						string currentRuleHeadPredicateVariable = currentRuleHeadPredicateBodyComponents[i].getTokenValue();
						
						currentRuleHeadPredicateRelation = currentRuleHeadPredicateRelation.selectOnID (currentRuleVariableIndexContainer, currentRuleHeadPredicateVariable);
						
						//cout << "AFTER Matching current Rule HEAD Predicate on ID, the Tuple values are: " << endl << endl;
						
						//currentRuleHeadPredicateRelation.displayTuples();
					}
			}
			
		//currentRuleHeadPredicateRelation.convertColumnNames (currentRuleHeadPredicate);
			
		currentRuleHeadPredicateRelation = currentRuleHeadPredicateRelation.projectRuleHeadPredicate (currentRuleHeadPredicate);
		
		
		
		//Relation currentRuleHeadPredicateRelation (currentRuleHeadPredicateName, currentRuleHeadPredicateScheme);
		
		relationContainer [currentRuleHeadPredicateRelation.getRelationName()].insertTuplesSet (currentRuleHeadPredicateRelation.getTuples());
		
		//relationContainerRules [currentRuleHeadPredicateRelation.getRelationName()].insertTuplesSet (currentRuleHeadPredicateRelation.getTuples());
		
		//for (unsigned int i = 0; i < rulePredicateContainer.size(); i++)
			//{
				//displayRulesAndTupleValues (currentRule);
			//}
		
		outputStringStream << "Displaying Column Names and Associated Tuple Values for newly created RULE Relation" << endl << endl << endl << endl << endl;
		//cout << endl << endl << endl << relationContainer [currentRuleHeadPredicateRelation.getRelationName()].displayTuplesProject () << endl << endl << endl;
		//outputStringStream << relationContainer [currentRuleHeadPredicateRelation.getRelationName()].displayTuplesProject ();
		//outputFileStream << outputStringStream.str ();
		//cout << "Displayed Column Names and Associated Tuple Values for newly created RULE Relation" << endl << endl << endl << endl << endl;
		
		//cout << "Newly Created Rule Head Predicate Relation: " << currentRuleHeadPredicateRelation.getRelationName() << endl << endl;
		
		//cout << "It has Column Names:" << endl << endl;
		//cout << currentRuleHeadPredicateRelation.getTupleNames().toStringSchemeValues() << endl << endl;
		
		//cout << "It has Tuple Values:" << endl << endl;
		//currentRuleHeadPredicateRelation.displayTuples();
		
		//cout << endl << endl << endl << endl;
	}
	
	
	
	
	
	
	
	
unsigned int Database::getTotalRelationTuplesCount ()
	{
		unsigned int totalTuplesCount = 0;
		
		for (std::map <string, Relation>::iterator totalRelationIterator = relationContainer.begin(); totalRelationIterator != relationContainer.end(); totalRelationIterator++)
			{
				//Relation currentRelation = totalRelationIterator -> second;
				
				totalTuplesCount += (totalRelationIterator->second).getTupleCount ();
			}
			
		return totalTuplesCount;
	}






void Database::displayRulesAndTupleValues (Rule &currentRuleSubmit)//Relation& currentRuleRelationConstructSubmit)//Rule currentRule)
	{
		//cout << "Entered displayRulesAndTupleValues which is in Database" << endl << endl << endl << endl;
		
		stringstream outputStringStream;
		
		//for (unsigned int i = 0; i < rulePredicateContainer.size(); i++)
			//{
				//cout << "Current Rule is: " << endl << endl;
				
				//outputStringStream << rulePredicateContainer[i].getHeadPredicate ().toStringName () << rulePredicateContainer[i].getHeadPredicate ().toStringBody () << " :- " << rulePredicateContainer[i].toStringBody () << endl;
				outputStringStream << currentRuleSubmit.getHeadPredicate ().toStringName () << currentRuleSubmit.getHeadPredicate ().toStringBody () << " :- " << currentRuleSubmit.toStringBody () << endl;
				
				//cout << "Attempting to Find NEW Tuples for the Accompanying Relation to  this Rule" << endl << endl;
				//if (rulePredicateContainer[i].getHeadPredicate ().toStringName () == currentRule.getHeadPredicate ().toStringName ())
					//{	
						std::map <string, Relation>::iterator relationIterator = relationContainerRules.find (currentRuleSubmit.getHeadPredicate ().toStringName ());//rulePredicateContainer[i].getHeadPredicate ().toStringName ());//currentRule.getHeadPredicate ().toStringName());
						
						//Relation currentRelation = relationIterator -> second;
						if (relationIterator != relationContainerRules.end ())//currentRuleRelationConstructSubmit.getRelationName () == rulePredicateContainer[i].getHeadPredicate ().toStringName ())
							{
								//cout << endl << endl << "__________Displaying Tuples BEFORE Clearing_________" << endl << endl;
								//(relationIterator -> second).displayTuples ();
								if ((relationIterator -> second).getTupleCount () > 0)
									{
										outputStringStream << (relationIterator -> second).displayTuplesSelect ();
								
										(relationIterator -> second).clearTuplesSet ();
									}
								//cout << endl << endl << "______________Displaying Tuples AFTER Clear____________" << endl << endl;
								//(relationIterator -> second).displayTuples ();
							}
					//}
					
			//}
			
		outputFileStream << outputStringStream.str ();
	}
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
	
//These functions are used for Lab 5
void Database::generateGraphs ()
	{
		//cout << "Entered generateGraphs which is in Database" << endl << endl;
		
		for (int i = 0; i < rulePredicateContainer.size (); i++)
			{
				Node currentForwardRuleNode;
				
				forwardGraph [i] = currentForwardRuleNode;
				
				std::map <int, Node>::iterator reverseGraphIterator = reverseGraph.find (i);
				
				if (reverseGraphIterator == reverseGraph.end ())
					{
						reverseGraph [i] = currentForwardRuleNode;
					}
				
				setGraphAdjacencies (i, rulePredicateContainer [i]);
			}
			
			
		//displayGraphs ();
	}
	
	
	
	
void Database::setGraphAdjacencies (int indexSubmit, Rule &currentRuleSubmit)
	{
		//cout << "Entered setGraphAdjacencies which is in Database" << endl << endl;
		
		for (int j = 0; j < currentRuleSubmit.getRuleBodyPredicates ().size (); j++)
			{
				for (int k = 0; k < rulePredicateContainer.size (); k ++)
					{
						//cout << "Current Rule Body Predicate NAME: " << currentRuleSubmit.getRuleBodyPredicates () [j].toStringName () << endl;
						//cout << "Current Rule Predicate HEAD Predicate NAME: " << rulePredicateContainer [k].getHeadPredicate ().toStringName () << endl;
						
						
						if (currentRuleSubmit.getRuleBodyPredicates () [j].toStringName () == rulePredicateContainer [k].getHeadPredicate ().toStringName ())
							{
								std::map <int, Node>::iterator forwardGraphIterator = forwardGraph.find (indexSubmit);
								
								(forwardGraphIterator -> second).setAdjacentNodes (k);
								
								
								
								std::map <int, Node>::iterator reverseGraphIterator = reverseGraph.find (k);
								
								if (reverseGraphIterator != reverseGraph.end ())
									{
										//cout << "Node " << k << "ALREADY in the Reverse Graph" << endl << endl;
										
										int reverseInt = indexSubmit;
										(reverseGraphIterator -> second).setAdjacentNodes (reverseInt);
										
										//cout << "Submitted to Adjacency List of NODE " << k << " in the REVERSE Graph" << endl;
										//cout << "Node " << k << " now has REVERSE Graph Adjacency List of: " << (reverseGraphIterator -> second).toStringAdjacentNodes () << endl << endl;
									}
									
								else
									{
										//cout << "Node " << k << "DID NOT already exist in the Reverse Graph" << endl << endl;
										
										Node currentReverseNode;
										
										reverseGraph [k] = currentReverseNode;
										
										//cout << "Created and entry for Node " << k << " inside the REVERSE Graph" << endl << endl;
										
										//For some reason, the value doesn't seem to be getting inserted
										int reverseInt = indexSubmit;
										reverseGraph [k].setAdjacentNodes (reverseInt);
										
										//cout << "Submitted to Adjacency List of NODE " << k << " in the REVERSE Graph" << endl << endl;
										
										//cout << "Node " << k << "'s Adjacency List is now: " << reverseGraph [k].toStringAdjacentNodes () << endl << endl;
										//cout << "Node " << k << " now has REVERSE Graph Adjacency List of: " << (reverseGraphIterator -> second).toStringAdjacentNodes () << endl << endl;
										//cout << "The Size of Node " << k << "'s Adjacency List is now: " << reverseGraph [k].getAdjacentNodesCount () << endl << endl;//(reverseGraphIterator -> second).getAdjacentNodesCount () << endl << endl;
									}
								//Node currentReverseRuleNode;
								
								//reverseGraph [k] = currentReverseRuleNode;
								
								
							}
					}
			}
	}
	
	
	
	
	
void Database::displayGraphs ()
	{
		//cout << "Entered displayGraphs which is in Database" << endl << endl << endl;
		
		//cout << "_______________Displaying Adjacency List of Forward Graph_______________" << endl << endl;
		stringstream outputStringStream;
		
		outputStringStream << "Dependency Graph" << endl;
		
		for (std::map <int, Node>::iterator forwardGraphIterator = forwardGraph.begin (); forwardGraphIterator != forwardGraph.end (); forwardGraphIterator++)
			{
				outputStringStream << "  R" << forwardGraphIterator -> first << ": " << forwardGraphIterator -> second.toStringAdjacentNodes () << endl;
			}
			
			
			
		//cout << endl << endl << endl << endl << endl << endl;
		
		//cout << "_______________Displaying Adjacency List of Reverse Graph________________" << endl << endl;
		
		outputStringStream << endl << "Reverse Graph" << endl;
		
		for (std::map <int, Node>::iterator reverseGraphIterator = reverseGraph.begin (); reverseGraphIterator != reverseGraph.end (); reverseGraphIterator++)
			{
				outputStringStream << "  R" << reverseGraphIterator -> first << ": " << reverseGraphIterator -> second.toStringAdjacentNodes () << endl;
			}
			
		outputStringStream << endl;
			
		outputFileStream << outputStringStream.str ();
	}
	
	
	
	
	

void Database::dfsForestReverseGraph ()
	{
		//cout << "Entered dfsReverseGraph which is in Database" << endl << endl;
		
		//int postOrderNumber;
		
		for (std::map <int, Node>::iterator reverseGraphIterator = reverseGraph.begin (); reverseGraphIterator != reverseGraph.end (); reverseGraphIterator++)
			{
				if ((reverseGraphIterator -> second).getVisitStatus () == false)
					{
						dfsForestReverseNode (reverseGraphIterator -> first, reverseGraphIterator -> second);
						
						
						
						//(reverseGraphIterator -> second).setVisitStatus ();
						
						postOrderContainer.push_back (reverseGraphIterator -> first);
						
						(reverseGraphIterator -> second).setPostOrderNumber (postOrderContainer.size ());
					}
			}
		
	}
	
	
	
	
	
void Database::dfsForestReverseNode (int currentGraphInt, Node &currentGraphNode)
	{
		//cout << "Entered dfsForestReverseNode which is in Database" << endl << endl;
		
		//cout << endl << endl << endl;
		
		//cout << "Hit Node: " << currentGraphInt << endl;
		
		//cout << "Current Node's Adjacent Nodes: " << currentGraphNode.toStringAdjacentNodes () << endl << endl << endl;
		
		currentGraphNode.setVisitStatus ();
		
		//cout << "Set Current Node's visit Status to TRUE" << endl << endl;
		
		if (currentGraphNode.getAdjacentNodesCount () > 0)
			{
				//cout << "Current Node has at least one adjacent node" << endl << endl;
				
				//cout << "Current Node has " << currentGraphNode.getAdjacentNodesCount () << " adjacent nodes" << endl << endl;
				
				set<int> currentSet = currentGraphNode.getAdjacentNodes ();
				
				for (std::set <int>::iterator adjacentNodeIterator = currentSet.begin (); adjacentNodeIterator != currentSet.end (); adjacentNodeIterator++)
					{
						//cout << "Current Adjacent Node: " << *adjacentNodeIterator << endl;
						
						int currentAdjacentNode = *adjacentNodeIterator;
						
						std::map <int, Node>::iterator reverseGraphIterator = reverseGraph.find (currentAdjacentNode);
						
						//cout << "Found Adjacent Node for the Current Node" << endl << endl;
						
						if ((reverseGraphIterator -> second).getVisitStatus ()== false)
							{
								//cout << "Adjacent Node visit status was FALSE" << endl << endl;
								
								dfsForestReverseNode (reverseGraphIterator -> first, reverseGraphIterator -> second);
								
								//cout << "Post Order Container is size " << postOrderContainer.size () << " before adding to the container" << endl << endl;
								
								//cout << "Adding " << reverseGraphIterator -> first << " to the Post Order Number Container" << endl << endl;
								
								postOrderContainer.push_back (reverseGraphIterator -> first);
								
								//cout << "Post Order Container is size " << postOrderContainer.size () << " after adding to the container" << endl << endl;
								
								(reverseGraphIterator -> second).setPostOrderNumber (postOrderContainer.size ());
								
								(reverseGraphIterator -> second).setVisitStatus ();
							}
							
						//postOrderNumber++;
					}
			}
			
			
		else
			{
				//postOrderNumber++;
				
				return;
			}
			
		
		
				
		//currentGraphNode.setPostOrderNumber (postOrderNumber);
			
			
		//cout << "Node " << currentGraphInt << "'s Post Order Number: " << postOrderNumber << endl << endl;
			
		return;
	}
	
	
	
	
	
void Database::displayPostOrderNumbers ()
	{	
		//cout << "Entered displayPostOrderNumbers which is in Database" << endl << endl;
		
		//cout << "Post Order Numbers Container is of size: " << postOrderContainer.size () << endl << endl;
		/*
		for (std::map <int, Node>::iterator reverseGraphIterator = reverseGraph.begin (); reverseGraphIterator != reverseGraph.end (); reverseGraphIterator++)
			{
				cout << "Node: " << reverseGraphIterator -> first << endl;
				cout << "\t Post Order Num: " << (reverseGraphIterator -> second).getPostOrderNumber () << endl << endl << endl;
			}
		*/	
			
		//cout << endl << endl << endl << "____________Attempting to Match Correct Post Order Numbers with postOrderContainer____________" << endl << endl << endl;
		stringstream outputStringStream;
		
		outputStringStream << "Postorder Numbers" << endl;
		
		/*
		for (int i = 0; i < postOrderContainer.size (); i++)
			{
				if (i < postOrderContainer.size () - 1)
					{
						outputStringStream << "  R" << postOrderContainer [i] << ": " << i+1 << endl;-
					}
					
				else
					{
						outputStringStream << "  R" << postOrderContainer [i] << ": " << i+1 << endl << endl;
					}
			}
		*/
		
		for (std::map <int, Node>::iterator reverseGraphIterator = reverseGraph.begin (); reverseGraphIterator != reverseGraph.end (); reverseGraphIterator++)
			{
				outputStringStream << "  R" << reverseGraphIterator -> first << ": " << (reverseGraphIterator -> second).getPostOrderNumber () << endl;
			}
			
		outputStringStream << endl;
			
		outputFileStream << outputStringStream.str ();
	}
	
	
	
	
	
void Database::displaySCCOrder ()
	{
		//cout << "Entered displaySCCOrder which is in Database" << endl << endl;
		
		stringstream outputStringStream;
		
		//outputStringStream.clear ();
		
		outputStringStream << "SCC Search Order" << endl;
		
		for (int i = postOrderContainer.size () - 1; i >= 0; i--)
			{
				outputStringStream << "  R" << postOrderContainer [i] << endl;
			}
			
		outputStringStream << endl;
		
		outputFileStream << outputStringStream.str();
	}
	
	
	
	
	
void Database::dfsForestForwardGraph ()
	{
		//cout << "Entered dfsForestForwardGraph which is in Database" << endl << endl;
		
		for (int i = postOrderContainer.size () - 1; i >= 0; i--)
			{
				std::map <int, Node>::iterator forwardGraphIterator = forwardGraph.find (postOrderContainer [i]);
				
				if ((forwardGraphIterator -> second).getVisitStatus () == false)
					{
						currentSCC.insert (forwardGraphIterator -> first);
						
						dfsForestReversePostOrder (forwardGraphIterator -> second);
						
						
						set <int> currentGroup = currentSCC;
						
						//I'm not sure why sort isn't working for c++ because I've placed "#include <algorithm" in Database.hs
						//std::sort (currentGroup.begin (), currentGroup.end ());
						
						
						sccContainer.push_back (currentGroup);
						
						currentSCC.clear ();
					}
			}
	}
	
	
	
	
	
void Database::dfsForestReversePostOrder (Node &currentPostOrderNode)
	{	
		
		//cout << "Entered dfsForestReversePostOrder" << endl << endl;
		currentPostOrderNode.setVisitStatus ();
		
		if (currentPostOrderNode.getAdjacentNodesCount () > 0)
			{
				set <int> currentAdjacentSet = currentPostOrderNode.getAdjacentNodes ();
				
				for (std::set <int>::iterator adjacentNodeIterator = currentAdjacentSet.begin (); adjacentNodeIterator != currentAdjacentSet.end (); adjacentNodeIterator++)
					{
						std::map <int, Node>::iterator forwardGraphIterator = forwardGraph.find (*adjacentNodeIterator);
						
						if ((forwardGraphIterator -> second).getVisitStatus () == false)
							{
								currentSCC.insert (forwardGraphIterator -> first);
								
								dfsForestReversePostOrder (forwardGraphIterator -> second);
							}
					}
			}
	}





void Database::displaySCC ()
	{
		for (int i = 0; i < sccContainer.size (); i++)
			{
				//cout << "Current Strongly Connected Components" << endl << endl;
				//set <int> currentSCCGroup = sccContainer [i];
				
				stringstream currentSCC;
				
				for (std::set <int>::iterator currentSCCIterator = sccContainer [i].begin (); currentSCCIterator != sccContainer [i].end (); currentSCCIterator++)
					{
						
						int currentCC = *currentSCCIterator;
						//cout << sccContainer [i] [j].getHeadPredicate ().toStringName () << sccContainer [i] [j].getHeadPredicate ().toStringBody () << " :- " << sccContainer [i] [j].toStringBody () << endl;
						if (currentCC < sccContainer [i].size () - 1)
							{
								currentSCC << "R" << currentCC << "  ";
							}
							
						else
							{
								currentSCC << "R" << currentCC << "\n\n";
							}
					}
				
				//cout << currentSCC.str ();
					
				//cout << endl << endl << endl << endl;
			}
	}
	
	
	
	
	
	
void Database::answerSCC ()
	{
		//cout << "Entered answerSCC which is in Database" << endl << endl;
		
		
		for (int i = 0; i < sccContainer.size (); i++)
			{
						answerRules (sccContainer [i]);
			}
			
		//std::set <set <int>>::iterator sccGroupContainerIterator = sccContainer.begin ();
		
		//set <int> sccCurrentGroup = *sccGroupContainerIterator;
		
		//answerRules (sccCurrentGroup);
		
	}
	
	
	
	
	
bool Database::isSimpleSCC (set <int> &sccCurrentGroup)
	{
		if (sccCurrentGroup.size () > 1)
			{
				return false;
			}
			
		else
			{
				std::set <int>::iterator sccCurrentGroupIterator = sccCurrentGroup.begin ();
				
				std::map <int, Node>::iterator forwardGraphIterator = forwardGraph.find (*sccCurrentGroupIterator);
				
				
				if ((forwardGraphIterator -> second).dependsOn (*sccCurrentGroupIterator))
					{
						return false;
					}
					
				else
					{
						return true;
					}
			}
	}
