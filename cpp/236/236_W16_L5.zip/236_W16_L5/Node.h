#ifndef NODE_H_
#define NODE_H_

#include <iostream>

#include <algorithm>

using namespace std;

struct Node
	{
		set <int> adjacentNodes;
		
		bool visitStatus = false;
		
		int postOrderNumber;
		
		
		Node ()
			{
			};
			
		~Node ()
			{
			};
			
			
		void setVisitStatus ()
			{
				visitStatus = true;
			};
			
			
		bool getVisitStatus ()
			{
				return visitStatus;
			};
			
			
		void setPostOrderNumber (int postOrderNumberSubmit)
			{
				postOrderNumber = postOrderNumberSubmit;
			};
			
			
		int getPostOrderNumber ()
			{
				return postOrderNumber;
			};
			
			
		void setAdjacentNodes (int adjacentNodeSubmit)
			{
				adjacentNodes.insert (adjacentNodeSubmit);
				
				//std::sort (adjacentNodes.begin (), adjacentNodes.end ());
			};
			
			
		set <int> getAdjacentNodes ()
			{
				return adjacentNodes;
			};
			
			
		int getAdjacentNodesCount ()
			{
				return adjacentNodes.size ();
			};
			
			
		string toStringAdjacentNodes ()
			{
				stringstream adjacencyString;
				
				for (std::set <int>::iterator adjacentNodeIterator = adjacentNodes.begin (); adjacentNodeIterator != adjacentNodes.end (); adjacentNodeIterator++)
					{
						adjacencyString << "R" << *adjacentNodeIterator << " ";
					}
					
				return adjacencyString.str ();
			};
			
			
		bool dependsOn (int nodeSubmit)
			{
				for (std::set <int>::iterator adjacentNodeIterator = adjacentNodes.begin (); adjacentNodeIterator != adjacentNodes.end (); adjacentNodeIterator++)
					{
						if (nodeSubmit == *adjacentNodeIterator)
							{
								return true;
							}
					}
					
				return false;
			};
			
			
		
	};

#endif //NODE_H_
