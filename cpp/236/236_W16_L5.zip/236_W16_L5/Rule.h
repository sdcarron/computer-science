/*
 * Rule.h
 *
 *  Created on: Sep 30, 2015
 *      Author: heypono
 */

#ifndef RULE_H_
#define RULE_H_

#include "Predicate.h"

class Rule
	{
		friend class DatalogProgram;
	
		private:
			
			Predicate headPredicate;
			
			vector<Predicate> bodyComponents;
			
		public:
			Rule()
				{
					
				};
			
			~Rule()
				{
				
				};
			
			
		string toStringBody()
			{
				string predicateDisplay;
			
				if (bodyComponents.size() > 0)
					{
						predicateDisplay = bodyComponents[0].predicateName + bodyComponents[0].toStringBody();
					
						for (unsigned int i = 1; i < bodyComponents.size(); i++)
							{
								predicateDisplay += "," + bodyComponents[i].predicateName + bodyComponents[i].toStringBody();
							}
					}
				
				return predicateDisplay;
			};
			
			
		string toStringHead()
			{
				string headPredicateDisplay;
				
				headPredicateDisplay = headPredicate.toStringName() + headPredicate.toStringBody();
				
				return headPredicateDisplay;
			};
			
			
		int getBodyComponentsCount()
			{
				return bodyComponents.size();
			};
			
			
		Predicate getHeadPredicate ()
			{
				return headPredicate;
			};
			
		vector <Predicate> getRuleBodyPredicates()
			{
				return bodyComponents;
			};
	};



#endif /* 236_LAB1_RULE_H_ */
