/*
 * Analyzer.cpp
 *
 *  Created on: May 5, 2015
 *      Author: heypono
 */

#include "Analyzer.h"

bool Analyzer::setStaticTokenMap()
	{
			staticTokenMap [","] = "COMMA";
			staticTokenMap ["."] = "PERIOD";
			staticTokenMap ["?"] = "Q_MARK";
			staticTokenMap ["("] = "LEFT_PAREN";
			staticTokenMap [")"] = "RIGHT_PAREN";
			staticTokenMap [":"] = "COLON";
			staticTokenMap [":-"] = "COLON_DASH";
			staticTokenMap ["+"] = "ADD";
			staticTokenMap ["*"] = "MULTIPLY";
			staticTokenMap ["#"] = "COMMENT";
			staticTokenMap ["#|"] = "COMMENT";
			staticTokenMap ["|#"] = "CLOSING COMMENT";
			staticTokenMap ["'"] = "STRING";
			staticTokenMap ["Schemes"] = "SCHEMES";
			staticTokenMap ["Facts"] = "FACTS";
			staticTokenMap ["Rules"] = "RULES";
			staticTokenMap ["Queries"] = "QUERIES";
			
			return true;
	}




//Read in the Input File
void Analyzer::importStrings (char* fileName)
	{
		setStaticTokenMap();
	
		//cout << "Attempting to open the file." << endl;
	
		ifstream inputStream;
		inputStream.open (fileName);
		
		if (inputStream.fail() == true)
			{
				cout << "The file did not open properly." << endl;
			}
		
		
		//cout << "The file was accepted." << endl;
		
		
		//Variables used to track line number and line length
		lineNumber = 1;
		
		
		//Variable to track total number of TOKENS in file
		numTokens = 0;	
		
		//Read through the input file one character at a time
		while (inputStream.get(inputChar))
			{
				//Variables for constructing string to identify incoming Static TOKEN elements
				string inputCharString;
				inputCharString += inputChar;
				
				//cout << "input Char: " << inputChar << endl << endl;
				
				//cout << "input Char String: " << inputCharString << endl << endl;
				
			
				//After reaching current line's end, move down one more line
				if (inputCharString=="\n" || inputCharString == "\r")
					{
						lineNumber++;
					}
				
				//If the current Character is some kind of WHITE SPACE other than \n or \r, do NOTHING
				else if (isspace(inputChar))
					{
					
					}
				
				//Check if the current Character is a TOKEN in the Map
				else if (booleanStaticTokenType(inputCharString))
					{
						//Call identifyTokenFunction (ifstream& inputStream, string inputCharString)
						identifyTokenFunction (inputStream, inputCharString);
					}
				
				
				
				
				//If the current Character is ALPHANUMERIC, finder whether it is a Key Word or an ID
				else if (isLetter(inputChar) /*|| isNumber(inputChar)*/)
					{
						//Call analyzerKeyword_Or_ID (ifstream& inputStream, string inputCharString);
						analyzerKeyword_Or_ID (inputStream, inputCharString);
						
					}
				
				
				
				//If the current Character falls in none of the above categories, it must be UNDEFINED
				else
					{
						/* Prior to Winter Semester 2016 This is how I handled unrecognized input
						createTokenType = "UNDEFINED";
						
						
						//cout << "The token type of" << inputChar << " is: " << createTokenType << endl << endl;
						
						//cout << "Line Number is: " << lineNumber << endl;
						
						//Increment the total number of TOKENS
						numTokens++;
						
						//Call function to create New TOKEN element and Insert it into tokenContainer
						addTokenContainer (createTokenType, inputCharString, lineNumber);
						*/
						
						
						
						
						//In Winter Semester 2016, I was required to handle unrecognized input by breaking at the error and issuing an "input error statement
						inputError ();
						
						break;
					}
				
				
				
				//addTokenContainer ();
				
				
						
			}
		
		//Call function to check for EOF
		//endOfFileCheck (inputStream);

		//Call function to display TOKEN elements
		//tokenDisplay();
		//tokenDisplayW16 ();
		
		if (tokenErrorContainer.size () == 0)
			{
				//cout << "importStrings() is where the EoF token is being generated for input13.txt" << endl;
				endOfFileCheck (inputStream);
				
				tokenDisplayW16();
			}
			
		else
			{
				tokenDisplayW16();
			}
		
		//Display number of Tokens
		//cout << "Total Tokens = " << numTokens << endl;
	}




//IDENTIFY the TOKEN Type
/*bool Analyzer::getStaticTokenType (string tokenValue)
	{
		cout << "Token Value is: " << tokenValue << endl;
	
		//If the TOKEN has a STATIC Type, call getStaticTokenType function to IDENTIFY the Type
		if (tokenValue=="," || tokenValue=="." || tokenValue=="?" || tokenValue=="(" || tokenValue==")" ||
				tokenValue==":" || tokenValue==":-" || tokenValue=="+" || tokenValue =="*" ||
				tokenValue == "#" || tokenValue == "#|" || tokenValue == "|#" || tokenValue == "'" ||
				tokenValue=="Schemes" || tokenValue=="Facts" || tokenValue=="Rules" || tokenValue=="Queries")
			 {
					cout << "Calling getStaticTokenType" << endl;
			
					getStaticTokenType (tokenValue);
					
					return true;
			 }
		
		//Otherwise, call VARIOUS functions to IDENTIFY the Type
		
		
		//Otherwise, return false
		else
			{
				return false;
			}
	}*/




//If the TOKEN has a STATIC Type, IDENTIFY the Type in the MAP
bool Analyzer::booleanStaticTokenType (string keySymbol)
	{
		//cout << "Looking in the Map NOW" << endl;
	
				map<string, string>::iterator mapIterator = staticTokenMap.find(keySymbol);
			
				//If the TOKEN Symbol is matched in the MAP, assign the associated Type NAME for TOKEN to be created
				if (mapIterator != staticTokenMap.end())
					{
						//cout << "Found the element in the Map" << endl;
					
						createTokenType = mapIterator->second;
						
						//cout << createTokenType;
						
						return true;
					}
				
				//If the TOKEN Symbol is not matched in the MAP, return false
		
		
		return false;
	}






//If the TOKEN has a STATIC Type, IDENTIFY the Type in the MAP
string Analyzer::getStaticTokenType (string keySymbol)
	{
		//cout << "Looking in the Map NOW" << endl;
	
				map<string, string>::iterator mapIterator = staticTokenMap.find(keySymbol);
			
				//If the TOKEN Symbol is matched in the MAP, assign the associated Type NAME for TOKEN to be created
				if (mapIterator != staticTokenMap.end())
					{
						//cout << "Found the element in the Map" << endl;
					
						string foundTokenType = mapIterator->second;
						
						return foundTokenType;
						//cout << createTokenType;
					}
				
				//If the TOKEN Symbol is not matched in the MAP, return false
		
		
		return "";
	}
	



//Identify whether the subbmited String Character is a NUMBER
bool Analyzer::isNumber(char stringChar)
	{
		string convertedChar;
		convertedChar += stringChar;
	
		//If the submitted character is a DIGIT, return true
		if (isdigit(convertedChar.at(0)))
			{
				return true;
			}
		
		else
			{
				return false;
			}
	/*
		int numCount = 0;
		int alpCount = 0;

		for (int i=0; i<expression.length(); i++)
			{
				if (isdigit(expression.at(i)))
					{
						numCount++;
					}

				else
					{
						alpCount++;
					}
			}

		if (numCount==expression.length())
			{
				return true;
			}
		else if (alpCount > 0)
			{
				return false;
			}
	*/
	}




//Identify whether the submitted String Character is a LETTER
bool Analyzer::isLetter (char stringChar)
	{
		string compareString = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz";
		
		int match = 0;
		
		int compareStringLength = compareString.length();
		
		stringstream compareStringCharacterConverter;
		string compareStringCharacter;
		
		for (int i = 0; i < compareStringLength; i++)
			{
				//compareStringCharacterConverter << compareString.at(i);
				//compareStringCharacterConverter >> compareStringCharacter;
			
				if (stringChar == compareString.at(i))
					{
						match = 1;
					}
			}
		
		if (match == 1)
			{
				return true;
			}
		
		else
			{
				return false;
			}		
	}




//Identify whether the submitted String Character is a HASH = # symbol (Signifying boundary of a comment)
bool Analyzer::isHash (string stringChar)
	{
		if (stringChar == "#")
			{
				return true;
			}
		
		else
			{
				return false;
			}
	}









//Identify whether the potential Multi-line Comment TOKEN is Comment OR is UNDEFINED
void Analyzer::multiLineComment (ifstream& inputStream, string inputCharString)
	{
		//cout << "Trying to find if it is a multi-line comment or UNDEFINED" << endl << endl;
										
		//Variable to retain the BEGINNING Line Number if this is a Multi-line Comment
		//int lineNumberInitial = lineNumber;
		
		//cout << "Multi-line Comment inputCharString AT START: " << inputCharString << endl << endl;
		
		//cout << "Current CHAR when first starting function: " << inputChar << endl << endl;
		
		//inputStream.get (inputChar);
		
		//cout << "Current CHAR when starting loop to look for CHARS to add: " << endl << endl;
		
		//Get the First Character following the OPENING Comment TOKEN to start looking for CLOSING Comment Token
		//inputStream.get (inputChar);
		
		//cout << "Current Char before Entering Multi-line Comment WHILE LOOP: " << inputChar << endl << endl;
		
		//Pull in additional Characters into the POTENTIAL Comment UNTIL finding a Successful CLOSING or Failed CLOSING
		while (true)
			{
			
				//If EOF is hit and no CLOSING Comment marker is seen, it's UNDEFINED
				if (inputStream.eof())
					{
						//cout << "Hit EOF" << endl << endl;
					
						createTokenType = "UNDEFINED";
						
						
						//cout << "inputchar string before substring: " << inputCharString << endl;
						
						inputCharString = inputCharString.substr(0, inputCharString.length() - 1 );
								
						//cout << "inputchar string AFTER substring: " << inputCharString << endl;
						
						break;
					}

				//cout << "Current Character String for Potential Multi-line Comment: " << inputCharString << endl << endl;
				
				//If FIRST half of Closing Multi-line Comment marker is observed, WATCH for the Other half
				if (inputChar == '|')
					{
						//inputCharString += inputChar;
						
						if (inputStream.peek() == '#')
							{
								inputStream.get(inputChar);
								
								inputCharString += inputChar;
								
								break;
							}
						
						else
							{
								inputStream.get(inputChar);
								
								//string currentAddChar;
								//currentAddChar += inputChar;
								
								//cout << "Current Char added to String: " << currentAddChar << endl << endl;
								//cout << "Current INPUT Char STRING before ADDING: " << inputCharString << endl << endl; 
								
								inputCharString += inputChar;
								
								//cout << "Current INPUT Char STRING after ADDING: " << inputCharString << endl << endl;
							}
					}
				
				
				
				//If hitting a NEW LINE in a Multi-line Comment, INCREMENT Line COUNT and add the NEXT Character for the next iteration
				else if (inputChar == '\n')
					{
						lineNumber++;
						
						//cout << " Random Thing" << endl << endl;
						
						inputStream.get(inputChar);
						
						inputCharString += inputChar;
					}
				
				//Otherwise just add the current Character to the Comment
				else
					{
						//inputStream.get(inputChar);
						
						//inputCharString += inputChar;
					
						inputStream.get(inputChar);
													
						//string currentAddChar;
						//currentAddChar += inputChar;
						
						//cout << "Current Char added to String: " << currentAddChar << endl << endl;
						//cout << "Current INPUT Char STRING before ADDING: " << inputCharString << endl << endl; 
						
						inputCharString += inputChar;
						
						//cout << "Current INPUT Char STRING after ADDING: " << inputCharString << endl << endl;
					}
				
				//inputCharString += inputChar;
				//inputStream.get(inputChar);
			}
		
		//cout << "Token Type: " << createTokenType << endl << endl;
		//cout << "Line Number: " << lineNumberInitial << endl << endl;
		
		//For Winter 2016, we don't count comments as a token
		//numTokens++;	
		
		//Call function to create New TOKEN element and Insert it into tokenContainer
		//addTokenContainer (createTokenType, inputCharString, lineNumberInitial);
	}










//Identify the Single-line Comment TOKEN
void Analyzer::singleLineComment (ifstream& inputStream, string inputCharString)
	{
		//cout << "Entering Single Line Comment" << endl << endl;
	
		//Add Characters to the Comment until hitting \n or EOF
		while (inputStream.peek() != '\n' && !(inputStream.eof()))
			{
				inputStream.get(inputChar);
				
				inputCharString += inputChar;
			}
		
		//cout << "The single line Comment is: " << inputCharString << endl << endl;
		
		//For Winter 2016, we don't count comments as a token
		//numTokens++;
		
		/*if (inputStream.peek() == '\n')
			{
				lineNumber++;
			}
		*/
		
		//addTokenContainer (createTokenType, inputCharString, lineNumber);
	}







//Identify whether the potential String TOKEN is String OR is UNDEFINED
void Analyzer::analyzerString (ifstream& inputStream, string inputCharString)
	{
		//getStaticTokenType (inputCharString);
									
		//if (getStaticTokenType(inputCharString) == "STRING")
			//{
				//Variables to retain the BEGINNING and END Line Number if this is a Multi-line String
				int lineNumberInitial = lineNumber;
				//int lineNumberEnd;
				
				//cout << "Entered the string gathering function. Current string is: " << inputCharString << endl << endl;
				
				//inputCharString += inputChar;
				
				inputStream.get(inputChar);
			
				//Initial While Loop conditions: inputChar == '\'' && inputStream.peek() == '\'' || inputChar != '\'' && inputChar != inputStream.eof()
				while (true)
					{
						//cout << "Updated Input Char String is: " << inputCharString << endl << endl;
					
						//If the current Character is ' then add it to the String and check the next Character
						if (inputChar == '\'')
							{
								inputCharString += inputChar;
							
								if (inputStream.peek() == '\'')
									{
										inputStream.get(inputChar);
										
										inputCharString += inputChar;
										
										//inputStream.get(inputChar);
									}
								
								//Because I am required to treat multi-line strings and EoF in a string as input error for
								//Winter Semester 2016, following a single-line string is where I increment token count and
								//Where I submit the new token to be created
								else
									{
										numTokens++;
										
										addTokenContainer (createTokenType, inputCharString, lineNumberInitial);
										
										break;
									}
							}
						
						//Otherwise if the current Character is \n, just add it to the String and increment Line Count
						//Prior to Winter Semester 2016, the ABOVE is what I would do with \n in a string
						//Now, in Winter Semester 2016, I am required to treat \n in a string as an "input error"
						else if (inputChar == '\n')
							{
								/*Before Winter Semester 2016, this is how I handled \n in a string
									{
										lineNumber++;
									}
							
								inputCharString += inputChar;
								*/
								
								//In Winter Semester 2016, I am required to treat \n in a string as an input error
								inputError();
								
								break;
							}
						
						//Otherwise, just add the current Character to the String
						else
							{
								inputCharString += inputChar;
							}
						
						//After adding the previous Character, get the NEXT Character for the next iteration
						inputStream.get(inputChar);
						
						//Prior to Winter Semester 2016, I treated EoF inside of a string as "UNDEFINED"
						//Now, in Winter Semester 2016, I am required to treat EoF inside of a string as an input error
						if (inputStream.eof())
							{
								//This is how I treated EoF inside of a string before Winter Semester 2016
								//createTokenType = "UNDEFINED";
								
								//tokenDisplayW16();
								
								//In Winter Semester 2016, I am required to handle EoF inside of a string as an input error
								inputError();
							
								break;
							}
						
					}
				
				//Before Winter Semester 2016, when a multi-line string was valid and when EoF in a string resulted in "UNDEFINED" tokens
				//This is where I would increment the token count, BUT NOW only SINGLE LINE strings are valid, so this is being relocated to that section
				//of code in this function
				//numTokens++;
				
				//cout << "(B) The token type is: " << createTokenType << endl << endl;
				
				//cout << "The token value is: " << inputCharString << endl << endl;
												
				//lineNumberEnd = lineNumber;
				
				//lineNumber = lineNumberInitial;
		
				//cout << "Line Number is: " << lineNumber << endl;
				
				//lineNumber = lineNumberEnd;	
				
			//}
				
				
				//Before Winter Semester 2016, when a multi-line string was valid and when EoF in a string resulted in "UNDEFINED" tokens
				//This is where I would submit the new token to be created, BUT NOW only SINGLE LINE strings are valid, so this is being relocated to that section
				//of code in this function
				//Call function to create New TOKEN element and Insert it into tokenContainer
				//addTokenContainer (createTokenType, inputCharString, lineNumberInitial);
	}







//Identify whether the stream of Characters is a Keyword TOKEN or is a ID TOKEN
void Analyzer::analyzerKeyword_Or_ID (ifstream& inputStream, string inputCharString)
	{
		int lineNumberInitial = lineNumber;
	
		//Continue constructing the current String as long as ALPHANUMERIC Characters immediately follow it
		while (isLetter(inputStream.peek()) || isNumber(inputStream.peek()) || inputStream.peek() == '\n')
			{
				inputStream.get(inputChar);
				
				if (inputChar == '\n')
					{
						lineNumber++;
						
						break;
					}
			
				else
					{
						inputCharString += inputChar;
					}
			}
		
		//cout << "Input Char String: " << inputCharString << endl;
		
		if (booleanStaticTokenType(inputCharString))
			{
				createTokenType = getStaticTokenType (inputCharString);
				
				//cout << "The token type is: " << createTokenType << endl << endl;
				
				//cout << "Line Number is: " << lineNumberInitial << endl;
				
				//Increment the total number of TOKENS
				numTokens++;
			}
		
		else
			{
				createTokenType = "ID";
			
				//cout << "The token type is: " << createTokenType << endl << endl;
				
				//cout << "Line Number is: " << lineNumberInitial << endl;
				
				//Increment the total number of TOKENS
				numTokens++;
			}
		
		//Call function to create New TOKEN element and Insert it into tokenContainer
		addTokenContainer (createTokenType, inputCharString, lineNumberInitial);
	}





/* This is how I would display the captured tokens to the TERMINAL, before Winter Semester 2016
//Display the TOKENS in the Container
void Analyzer::tokenDisplay ()
	{	
		for (int i = 0; i < tokenContainer.size (); i++)
			{
				cout << tokenContainer[i].toStringToken() << endl;
				
				//tokenContainer.pop_back ();
			}
	}
*/	


//This is how I am required to display the captured tokens for Winter Semester 2016
void Analyzer::tokenDisplayW16 ()
	{
		//For Winter 2016, we are required to output the Tokens to a file
		ofstream outputFile;
		
		//cout << "Get output file " << endl;
		
		//Open the appropriate output file for dislpaying the captured tokens
		//"getOutputFile()" retrieves the SECOND file name issued in the terminal argument vector
		outputFile.open (getOutputFile());
		
		//cout << "Opened the output file" << endl;
		
		//Write out each of the captured tokens to the appropriate output file
		for (unsigned int i = 0; i < tokenContainer.size (); i++)
			{
				//cout << "Writing " << tokenContainer[i].toStringToken() << " to output file" << endl;
				
				outputFile << tokenContainer[i].toStringToken() << endl;
			}
			
		//cout << "Checking for error token" << endl;
			
		//If an input error was encountered, display it to the output file
		if (tokenErrorContainer.size () > 0)
			{
				outputFile << tokenErrorContainer[0] << endl;
			}
			
		//If no input error occurred, then list the number of tokens captured
		else
			{
				outputFile << "Total Tokens = " << numTokens << endl;
			}
	}






//Add a new TOKEN to the Container
void Analyzer::addTokenContainer (string tokenTypeInput, string tokenValueInput, int lineNumberInput)
	{
		//Create the TOKEN to be added to the Container and PUSH it onto the back of the container
		Token addToken = Token (tokenTypeInput, tokenValueInput, lineNumberInput);
						
		//Push each new TOKEN onto the FRONT of the Container, because std::vector only has removal functionality from the rear
		tokenContainer.push_back(addToken);
		
		//Push each new TOKEN onto the FRONT of the VECTOR
		//tokenVector.insert(tokenVector.begin(), addToken);
		//tokenVector.push_back(addToken);
	}
	
	
	
//Add an Error to the ERROR Container For Winter Semester 2016
void Analyzer::addTokenErrorContainer (string tokenErrorInput)
	{
			tokenErrorContainer.push_back (tokenErrorInput);
	}






//Identify the ENTIRE TOKEN now encountered
void Analyzer::identifyTokenFunction (ifstream& inputStream, string inputCharString)
	{
		//Peek at the NEXT Character to know whether I need it or not
		if (inputCharString == ":" && inputStream.peek() == '-')
			{
				//If the NEXT Character was needed to construct a TOKEN, pull it in
				inputStream.get(inputChar);
				
				inputCharString += inputChar;
				
				createTokenType = getStaticTokenType (inputCharString);
				//Find the TOKEN in the Map
				//getStaticTokenType(inputCharString);
				
				//cout << "(A) The token type is: " << createTokenType << endl << endl;
				
				//cout << "Line Number is: " << lineNumber << endl;
				
				//Increment the total number of TOKENS
				numTokens++;
				
				//Call function to create New TOKEN element and Insert it into tokenContainer
				addTokenContainer (createTokenType, inputCharString, lineNumber);
			}
				
		
		//Check whether the POTENTIAL Multi-line Comment IS a Comment OR UNDEFINED
		else if (inputCharString == "#" /*&& inputStream.peek() == '|'*/)
			{
	
				if (inputStream.peek() == '|')
					{
						//Call isMultiLineComment(ifstream& inputStream, string inputCharString);
						inputStream.get(inputChar);
							
						//inputCharString += inputChar;
						inputCharString += "|";
						
						createTokenType = getStaticTokenType (inputCharString);
							
						multiLineComment (inputStream, inputCharString);
					}
				
				else
					{
						//Call singleLineComment(ifstream& inputStream, string inputCharString);
						singleLineComment (inputStream, inputCharString);
					}
	
			}


		
		else if (inputCharString == "'")
			{
				createTokenType = getStaticTokenType (inputCharString);
			
				//Call analyzerString (ifstream& inputStream, string inputCharString);
				analyzerString (inputStream, inputCharString);
			}
		
		
		
		
		//If the NEXT Character was NOT needed to construct a TOKEN, find the current TOKEN
		else
			{		
				//if (getStaticTokenType(inputCharString) != "STRING")
					//{
				createTokenType = getStaticTokenType(inputCharString);
				
						//cout << "(B) The token type is: " << createTokenType << endl << endl;
						
						//cout << "Line Number is: " << lineNumber << endl;
					//}
				
				//Increment the total number of TOKENS
				numTokens++;
				
				//Call function to create New TOKEN element and Insert it into tokenContainer
				addTokenContainer (createTokenType, inputCharString, lineNumber);
			}
	}






//Check to see if at the EOF
bool Analyzer::endOfFileCheck (ifstream& inputStream)
	{
		//If at the End of File and the File is FULLY Parsed, return true
		if (inputStream.eof())
			{
				createTokenType = "EOF";
				string inputCharString = "";
				numTokens++;
				
				addTokenContainer (createTokenType, inputCharString, lineNumber);
			
				//cout << "Total Number of Tokens = " << numTokens << endl;
			
				return true;
			}
		//Otherwise, something went wrong while Parsing the File
		else
			{
				return false;
			}
	}






//Get the Container of TOKEN elements for Parsing
vector <Token> Analyzer::getParseVector ()
	{
		return tokenContainer;
	}
	
	
	
	


//Produce the input error information, and pass it to the addTokenErrorContainer function
void Analyzer::inputError ()
	{
		stringstream lineNumberConvert;
		lineNumberConvert <<  lineNumber;
		
		string errorString;
		errorString = "Input error on line " + lineNumberConvert.str();
		
		cout << "This is the newly constructed errorString: " << errorString << endl;
		
		addTokenErrorContainer (errorString);
	}
