/*
 * Analyzer.h
 *
 *  Created on: May 5, 2015
 *      Author: heypono
 */

#ifndef ANALYZER_H_
#define ANALYZER_H_

#include "Token.cpp"

#include <vector>

#include <string>
#include <map>

#include <fstream>
#include <iostream>
#include <sstream>

class Analyzer
	{
		private:
			string createTokenType;
			string createTokenValue;
			string createTokenLineNumber;
		
			map <string, string> staticTokenMap;
				
			bool setStaticTokenMap();
			
			char inputChar;
			char inputCharAdd;
			
			int lineNumber;
			
			int numTokens;
			
			char* outputFile;
			
			vector<Token> tokenContainer;
			vector<string> tokenErrorContainer;
			//vector<Token> tokenVector;
			/*std::vector<Token> tokenVector;
			    {
			        Token tokenInsert;
			        //ntoken.isOperator = true;
			        //ntoken.opr = '+';
			        tokenVector.push_back(tokenInsert*&);
			        tokenVector.insert (tokenVector.begin(), tokenInsert*&);
			        
			        tokenVector.pop_back (tokenInsert*&);
			    }*/
			
			
		
		public:
			Analyzer(char* argv1, char* argv2)
							{
								//char fileName = argv[1];
								outputFile = argv2;
								
								importStrings (argv1);
							};
						
			~Analyzer()
				{
				};
			
			void importStrings (char* fileName);
			
			bool booleanStaticTokenType (string keySymbol);
			
			string getStaticTokenType (string keySymbol);
						
			//bool getTokenType (string tokenValue);
			
			bool isNumber (char stringChar);
			
			bool isLetter (char stringChar);
			
			bool isHash (string stringChar);
			
			bool endOfFileCheck (ifstream& inputStream);
			
			void identifyTokenFunction (ifstream& inputStream, string inputCharString);
			
			void multiLineComment (ifstream& inputStream, string inputCharString);
			
			void singleLineComment (ifstream& inputStream, string inputCharString);
			
			void analyzerString (ifstream& inputStream, string inputCharString);
			
			void analyzerKeyword_Or_ID (ifstream& inputStream, string inputCharString);
			
			void tokenDisplay ();
			
			void tokenDisplayW16 ();
			
			void addTokenContainer (string tokenTypeInput, string tokenValueInput, int lineNumberInput);
			
			void addTokenErrorContainer (string tokenErrorInput);

			vector <Token> getParseVector ();
			
			char* getOutputFile ()
				{
					return outputFile;
				}
				
			void inputError ();
	};



#endif /* ANALYZER_H_ */
