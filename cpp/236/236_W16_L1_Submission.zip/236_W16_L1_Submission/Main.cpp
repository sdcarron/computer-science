/*
 * Main.cpp
 *
 *  Created on: May 5, 2015
 *      Author: heypono
 */

#include "Token.h"
#include "Analyzer.h"
//#include "DatalogProgram.h"
//#include "Predicate.h"

//#include "Relation.h"
//#include "Database.h"

#include <iostream>
#include <fstream>


using namespace std;

int main(int argc, char* argv[])
	{
			Analyzer x (argv[1], argv[2]);
			

			//cout << "IN MAIN F'n Getting the Tokens from the Analyzer to begin Parsing" << endl << endl;
			vector<Token> parseContainer;

			parseContainer = x.getParseVector();

			//cout << "IN MAIN F'n ------- sending Tokens to the PARSER" << endl << endl;
			/*for (int i=parseContainer.size () - 1; i >= 0; i--)
						{
							cout << parseContainer[i].toStringToken() << endl;

							//tokenContainer.pop_back ();
						}
			 */
			
			
			
			
			
			
			//For Lab 2
			//DatalogProgram datalogParser (parseContainer);
			
			//datalogParser.parseTokens (parseContainer);
			
			
			
			
			
			
			
			//For Lab 2
			//Obtain the Schemes, Facts, and Queries from the Datalog Parser
			
			//cout << "Obtaining the Predicates for SCHEMES, FACTS, and QUERIES" << endl << endl;
			
			//vector <Predicate> schemePredicateContainer = datalogParser.getSchemes();
			//vector <Predicate> factPredicateContainer = datalogParser.getFacts();
			//vector <Predicate> queryPredicateContainer = datalogParser.getQueries();
			
			//vector <vector <string>> factPredicateStringContainer;
			
			
			
			
			
			
			
			
			//For Lab 3
			//Capture the String Elements from each Fact Predicate, in order to submit them as values into the Relation Tables
			/*for (int i = 0; i < factPredicateContainer.size(); i++)
				{
					//Get the Parameter Vector from the CURRENT Fact Predicate
					vector <Parameter> currentFactPredicateBody = factPredicateContainer[i].getBodyComponents();
					
					//Vector to hold the String Elements from the CURRENT Fact Predicate's BODY
					vector <string> currentFactPredicateString;
				
					
					for (int j = 0; j < currentFactPredicateBody.size(); j++)
						{		
							//If the CURRENT Element in the CURRENT Fact Predicate's BODY is a String, then Capture it
							if (currentFactPredicateBody[j].getTokenValue() != "," && currentFactPredicateBody[j].getTokenValue() != "(" && currentFactPredicateBody[j].getTokenValue() != ")" && currentFactPredicateBody[j].getTokenValue() != ".")
								{
									currentFactPredicateString.push_back (currentFactPredicateBody[j].getTokenValue());
								}
						}
					
					//Store each Fact Predicate's String Elements as a Vector
					factPredicateStringContainer.push_back (currentFactPredicateString);
				}
			
			
			
			//Verify that the String Elements from each Fact Predicate were Captured correctly
			cout << "Displaying Fact Predicate Strings before submitting them to the Database" << endl << endl;
			
			for (int i = 0; i < factPredicateStringContainer.size(); i++)
				{
					for (int j = 0; j < factPredicateStringContainer[i].size(); j++)
						{
							cout << factPredicateStringContainer[i][j] << endl;
						}
					
					cout << endl << endl << endl;
				}
			*/
			
										//cout << "Printing the Predicates for SCHEMES" << endl << endl;
										
										//for (int i=0; i < schemesPredicates.size(); i++)
											//{
												//cout << "  " << schemesPredicates[i].toStringName() << schemesPredicates[i].toStringBody() << endl;
											//}
										
										//cout << endl << endl << "Printing the Predicates for FACTS" << endl << endl;
										
										//for (int i=0; i < factsPredicates.size(); i++)
											//{
												//cout << "  " << factsPredicates[i].toStringName() << factsPredicates[i].toStringBody() << endl;
											//}
										
										
										//cout << endl << endl << "Printing the Predicates for QUERIES" << endl << endl;
										
										//for (int i=0; i < queriesPredicates.size(); i++)
											//{
												//cout << "  " << queriesPredicates[i].toStringName() << queriesPredicates[i].toStringBody() << endl;
											//}
										
										
										
										//Relation testRelation (schemesPredicates[0].toStringName(), schemesPredicates[0].getBodyComponents());
										
										//cout << testRelation.getRelationName () << endl << endl;
										
										//testRelation.displayColumnNames();
			
			//For Lab 3
			//Begin the Database functions
			//Database database (schemePredicateContainer, factPredicateContainer, factPredicateStringContainer, queryPredicateContainer);
			
			//database.databaseRun();
			
			
			
			
			
			return 0;
	}


