/*
 * datalogProgram.h
 *
 *  Created on: Sep 30, 2015
 *      Author: heypono
 */

#ifndef DATALOGPROGRAM_H_
#define DATALOGPROGRAM_H_

#include "Token.h"
#include "Predicate.h"
#include "Rule.h"

#include <vector>
#include <list>
#include <set>
#include <iostream>
#include <fstream>

#include <stdexcept>

#include <algorithm>

using namespace std;

class DatalogProgram
	{
		private:
	
			vector<Token> tokenContainer;
			
			vector<Predicate> schemePredicateContainer;
			vector<Predicate> factPredicateContainer;
			vector<Predicate> rulePredicateContainer;
			vector<Predicate> queryPredicateContainer;
			vector<Rule> rulePredicateContainerTest;
			
			
			
			map <string, string> keyWordMap;
			
			
			
			//These are the Predicates to be included in each corresponding Vector (ABOVE)
			Predicate currentSchemeConstruct;
			
			Predicate currentFactConstruct;
			
			Predicate currentRuleConstruct;
			Predicate currentHeadPredicateConstruct;
			
			Rule currentRuleConstructTest;
			Predicate currentRulePredicateConstructTest;
			
			Predicate currentQueryConstruct;
			
			
			
			
			//These are the Parameters to be included in each corresponding Predicate (ABOVE)
			Parameter currentSchemeToken;
			
			Parameter currentFactToken;
			
			Parameter currentRuleToken;
			Parameter currentHeadPredicateToken;
			
			Parameter currentQueryToken;
			
			
			
			Parameter expressionPotential;
			
			
			//Variables for monitoring Parenthese balance for Expressions
			int ruleLeftParenCount;
			int ruleRightParenCount;
			
			int queryLeftParenCount;
			int queryRightParenCount;
			
			
			//Variable for monitoring Location within Submitted TOKEN Vector
			unsigned int index;
			
			
			
			//Variables for counting the number of each TOKEY Type encountered
			int schemeCount = 0;
			int factCount = 0;
			int ruleCount = 0;
			int queryCount = 0;
			
			
			//List for holding the Strings from FACTs for the domain
			set<string> factDomain;
			
			
			//Output file for displaying the parsed data
			char* outputFile;
	
		public:
			DatalogProgram (vector<Token> tokenContainerSubmit, char* argv2) : tokenContainer(tokenContainerSubmit), index(0)
				{
					outputFile = argv2;
					
					keyWordMap ["Schemes"] = "SCHEMES";
					keyWordMap ["Facts"] = "FACTS";
					keyWordMap ["Rules"] = "RULES";
					keyWordMap ["Queries"] = "QUERIES";
				};
			
			~DatalogProgram()
				{
				
				};
			
			
			void parseTokens (vector<Token> tokenContainer);
			
			bool matchToken (string tokenType);
			
			bool matchTokenParameter (string tokenType);
			
			
			//Supporting functions for overall parsing. Each is associated with specific TOKEN Type
			
				//Functions associated with SCHEME
				void schemeParse ();
				void schemeListParse();
				
				void stringListParse();
				
				
				//Functions associated with FACT
				void factParse ();
				void factListParse();
				
				
				//Functions associated with RULE
				void ruleParse ();
				void ruleListParse();
				
				void headPredicateParse();
				void idListHeadPredicateParse();
				
				void rulePredicateParse();
				void rulePredicateListParse();
				
				void ruleParameterParse();
				void ruleParameterListParse();
				
				void ruleExpressionParse();
				
				
				//Functions associated with QUERY
				void queryParse ();
				void queryListParse();
				
				void queryPredicateParse();
				
				void queryParameterParse();
				void queryParameterListParse();
				
				void queryExpressionParse();
				
				
				
				//Function for displaying TOTAL results
				void fileEnd(char* outputFile);
			
			
			
			
			
			void idListSchemeParse();
			void idListRuleParse();
			
			
			
			
			//Supporting functions for above specific parsing functions
			
			//Checks whether the Predicate begins correctly
			bool isOpening();
			
			//Supporting functions to check whether the Predicate Body has correct structure
			bool isID();
			
			bool isComma();
			
			
			
			//Checks whether the POTENTIAL Parameter is of Type ID, STRING, or EXPRESSION
			bool isParameter();
			
			bool isExpression(int index);
			
			
			//Checks whether the Token Type is a STRING and should, therefore, be added to the DOMAIN
			void tokenTypeCheck (string tokenTypeSubmit, string tokenValueSubmit);
			
			
			
			vector <Predicate> getSchemes()
				{
					return schemePredicateContainer;
				}
			vector <Predicate> getFacts()
				{
					return factPredicateContainer;
				}
			vector <Predicate> getQueries()
				{
					return queryPredicateContainer;
				}
			
			
			
			
			
	
	};



#endif /* DATALOGPROGRAM_H_ */
