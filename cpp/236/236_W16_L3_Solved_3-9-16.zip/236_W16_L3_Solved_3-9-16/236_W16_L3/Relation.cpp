/*
 * relation.cpp
 *
 *  Created on: Oct 22, 2015
 *      Author: heypono
 */


#include "Relation.h"

