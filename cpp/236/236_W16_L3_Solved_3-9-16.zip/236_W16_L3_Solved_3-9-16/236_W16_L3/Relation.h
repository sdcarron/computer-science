/*
 * relation.h
 *
 *  Created on: Oct 22, 2015
 *      Author: heypono
 */

#ifndef RELATION_H_
#define RELATION_H_

#include "Predicate.h"
#include "Parameter.h"
#include "Tuple.h"
#include "Scheme.h"

#include <vector>
#include <set>

#include <iostream>
#include <sstream>
#include <string>

#include <map>


using namespace std;


class Relation
	{
		private:
			string name;
		
			Scheme columnNames;
			
			set <Tuple> relationTuples;
			
			//int tupleCount;
	
			//Old Code Material
			/*
			string relationName;
			
			vector <Parameter> tupleNames;
			
			set <vector <string>> tupleValues;
			
			//map <string, string> tupleNameAndValueMap;
			*/
		
	
		public:
		
			Relation (string nameSubmit, Scheme columnNamesSubmit)
				{
					name = nameSubmit;
					
					columnNames = columnNamesSubmit;
					
					//tupleCount = 0;
				};
				
			Relation ()
				{
				};
				
			~Relation ()
				{
				};
				
				
			
			string getRelationName ()
				{
					return name;
				};
			
			Scheme getTupleNames ()
				{
					return columnNames;
				};
				
				
			set <Tuple> getTuples ()
				{
					return relationTuples;
				};
				
				
			void setColumnNames (int index, string indexName)
				{
					columnNames.setColumnName (index, indexName);
				};
				
				
			void insertTuples (Tuple tupleSubmit)
				{
					//if (std::find(std::begin(relationTuples), std::end(relationTuples), tupleSubmit) != std::end(relationTuples))
						//{

							//The String was found already in the Domain, so move on
						//}
					//else
						//{
							//The String was NOT already in the Domain, so insert it
							relationTuples.insert(tupleSubmit);
							
							//tupleCount++;
						//} 
					//relationTuples.insert (tupleSubmit);
					
					
				};
				
				
			void displayTuples ()
				{	
					cout << "Entered the Display Tuples function in RELATION.h" << endl << endl;
					cout << "set size = " << relationTuples.size() << endl;
					
					for (std::set <Tuple>::iterator it = relationTuples.begin(); it != relationTuples.end(); it++)
						{
							
							
							Tuple currentTuple = *it;
							
							//vector <string> currentTupleValues;
							
							//currentTupleValues = currentTuple.getTupleValues ();
							
							string tupleDisplay = "";
							
							for (unsigned int i = 0; i < currentTuple.size(); i++)
								{
									//cout << currentTuple[i] << ", " << endl;
									tupleDisplay += currentTuple[i] + ", ";
								}
								
							cout << tupleDisplay << endl << endl;
						}
				};
				
			
			//This returns the set of string values that are possible for each Variable in the Relation that matches the Query
			string displayTuplesSelect ()
				{
					
					string tupleDisplay = "";
					
					for (std::set <Tuple>::iterator it = relationTuples.begin(); it != relationTuples.end(); it++)
						{
							
							
							Tuple currentTuple = *it;
							
							//vector <string> currentTupleValues;
							
							//currentTupleValues = currentTuple.getTupleValues ();
							
							tupleDisplay += "  ";
							
							for (unsigned int i = 0; i < currentTuple.size(); i++)
								{
									//cout << currentTuple[i] << ", " << endl;
									
									if (i < currentTuple.size() - 1)
										{
											tupleDisplay += columnNames.getColumnName (i) + "=" + currentTuple[i] + " ";
										}
									else
										{
											tupleDisplay += columnNames.getColumnName (i) + "=" + currentTuple[i] + "\n";
										}
								}
							}	
						return tupleDisplay;
						
						//return "";
				};
				
				
			//This returns the set of string values that are possible for each Variable from the Query
			string displayTuplesProjectRename (map <int, vector<int>> queryTotalVariableIndexContainer, Scheme columnNamesSubmit)
				{
					columnNames = columnNamesSubmit;
					
					
					string tupleDisplay = "";
					
					for (std::set <Tuple>::iterator itTuple = relationTuples.begin(); itTuple != relationTuples.end(); itTuple++)
						{
							Tuple currentTuple = *itTuple;
							
							tupleDisplay += "  ";
						
							for (std::map <int, vector<int>>::iterator itVariable = queryTotalVariableIndexContainer.begin(); itVariable != queryTotalVariableIndexContainer.end(); itVariable++)
								{
									int currentLocationInQuery = itVariable->first;
									
									vector <int> currentIndexes = itVariable->second;
									
									string currentVariable = columnNames[currentLocationInQuery];
									
									tupleDisplay += currentVariable + "=" + currentTuple[currentIndexes[0]] + " ";
								}
								
							tupleDisplay += "\n";
						}
						
					return tupleDisplay;
				};
			
				
				
			int getTupleCount ()
				{
					//stringstream tupleCountStream;
					
					//tupleCountStream << tupleCount;
					
					//string tupleCountString;
					
					//tupleCountStream >> tupleCountString;
					
					return relationTuples.size();
				};
				
				
				
			//The calling Relation gets converted into a NEW Relation that has the submitted String Value in the correct index location
			Relation selectOnString (int index, string stringValue)
				{
					Relation selectStringResult (name, columnNames);
					
					cout << "index = " << index << "\nstringValue = " << stringValue << "\nset size = " << this->relationTuples.size() << endl;
					
					for (std::set <Tuple>::iterator it = relationTuples.begin(); it != relationTuples.end(); it++)
						{
							cout << "in for loop...\n";
							Tuple currentTuple = *it;
							
							cout << "currentTuple[index] = " << currentTuple[index] << endl;
							cout << "stringValue = " << stringValue << endl;
							if (currentTuple [index] == stringValue)
								{
									selectStringResult.insertTuples (currentTuple);
								}
						}
						
						
					return selectStringResult;
				};
				
				
				
			//The calling Relation gets converted into a NEW Relation that has Variable Values in the correct index locations
			Relation selectOnID (vector <int> indexes, string IDValue)
				{
					Relation selectIDResult (name, columnNames);
					
					for (std::set <Tuple>::iterator it = relationTuples.begin(); it != relationTuples.end(); it++)
						{
							Tuple currentTuple = *it;
							
							bool tupleCheck = true;
							
							//This portion accounts for the same Variable Value (Column Name) occuring in locations within the current Tuple that match
							//the correct locations in the Query from which the index values are obtained
							if (indexes.size () > 1)
								{
									for (unsigned int i = 1; i < indexes.size (); i++)
										{
											if (currentTuple[indexes[i]] == currentTuple[indexes[i-1]])
												{
													tupleCheck = true;
												}
												
											else
												{
													tupleCheck = false;
												}
										}
										
									if (tupleCheck == true)
										{
											selectIDResult.insertTuples (currentTuple);
										}
								}
							
							//If the submitted Variable Value has only one location in the Query, then just add each Tuple	
							else
								{
									selectIDResult.insertTuples (currentTuple);
								}
						}
						
						
						
					return selectIDResult;
				};
				
				
			//This converts the column names of the calling Relation to match the Variable Values in the current Query (for RENAME)
			void convertColumnNames (Predicate currentQuery)
				{
					vector <Parameter> currentQueryBody = currentQuery.getBodyComponents();
					
					for (unsigned int i = 0; i < currentQueryBody.size(); i++)
						{
							if (currentQueryBody[i].getTokenType() == "ID")
								{
									columnNames.setColumnName (i, currentQueryBody[i].getTokenValue());
								}
						}		
				};
		
			//Old Code Material
			/*
			Relation(string relationNameSubmit, vector<Parameter> tupleNamesSubmit) : relationName(relationNameSubmit), tupleNames(tupleNamesSubmit)
				{
				
				};
			
			Relation()
				{
				
				};
			
			~Relation()
				{
				
				};
			
			
			void insertValues (vector <string> valuesSubmit)
				{
					//if (std::find (std::begin (columnValues), std::end (columnValues), columnValues_Submit) != std::end(columnValues))
						//{
						
						//}
				
					//else
						//{
							tupleValues.insert (valuesSubmit);
						//}
				};
			
			
			string getRelationName ()
				{
					return relationName;
				};
			
			
			
			
			//Display the Tuple Names at the COLUMN HEADS within the Relation Table
			void displayTupleNames ()
				{
					cout << "Displaying Column Names for: " << relationName << endl << endl;
				
					for (unsigned int i = 0; i < tupleNames.size(); i++)
						{
							cout << "element[" << i << "]: " << tupleNames[i].tokenValue << endl;
						}
					
					cout << endl << endl;
				};
			
			
			
			
			
			//Display the Tuple Values within the Relation Table
			void displayTupleValues ()
				{
					vector <string> currentTuple;
				
					for (std::set<vector <string>>::iterator it = tupleValues.begin(); it != tupleValues.end(); it++)
						{
							currentTuple = *it;
						
							for (unsigned int i = 0; i < currentTuple.size(); i++)
								{
									cout << currentTuple[i] << endl;
								}
						}
				};
			
			
			
			
			set <vector <string>> getTupleValues ()
				{
					return tupleValues;
				};
				
			
			
			
			void setTupleNames (int index, string indexName)
				{
					tupleNames[index].setTokenValue (indexName);
				}
				
				
			vector <Parameter> getTupleNames ()
				{
					return tupleNames;
				};
			*/
			
			
	};



#endif /* RELATION_H_ */
