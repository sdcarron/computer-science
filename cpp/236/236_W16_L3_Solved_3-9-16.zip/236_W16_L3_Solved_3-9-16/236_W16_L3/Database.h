/*
 * dataBase.h
 *
 *  Created on: Oct 22, 2015
 *      Author: heypono
 */

#ifndef DATABASE_H_
#define DATABASE_H_


#include "Relation.h"

#include <map>
#include <vector>

#include <fstream>

using namespace std;

class Database
	{
		private:
			map <string, Relation> relationContainer;
			
			
			//Submitted data containers
			vector <Predicate> schemePredicateContainer;
			vector <Predicate> factPredicateContainer;
			vector <Predicate> queryPredicateContainer;
			
			
			//Set to hold the potential Tuple matches for each Query
			set <Tuple> relationTuplesCopy;
			
			
			//Map to hold the locations of IDs in the Query body
			map <string, vector <int>> queryVariableIndexContainer;
			//vector <int> currentVariableIndexContainer;
			
			
			//Output File
			char* outputFile;
		
			ofstream outputFileStream;
			
			
			map <int, vector <int>> queryTotalVariableIndexContainer;
			map <string, vector <int>> queryTotalVariableContainer;
			//vector <int> queryTotalVariableIndexValues;
			
			//stringstream outputStringStream;
			
			//Old Code Material
			/*
			map <string, Relation> relationContainer;
			
			//map <string, vector <int>> queryVariableIndexContainer;
			
			vector <Predicate> schemePredicateContainer;
			vector <Predicate> factPredicateContainer;
			vector <Predicate> queryPredicateContainer;
			
			std::set <Predicate> factPredicateSet;
			
			vector <vector <string>> factPredicateStringContainer;
			
			
			//Output file for displaying the analysis results
			char* outputFile;
			*/
	
		public:
			
			Database (vector <Predicate> schemePredicateContainerSubmit, vector <Predicate> factPredicateContainerSubmit, vector< vector<string>> factPredicateStringContainerSubmit, vector <Predicate> queryPredicateContainerSubmit, char* argv2)
				{
					outputFile = argv2;
					
					schemePredicateContainer = schemePredicateContainerSubmit;
					
					factPredicateContainer = factPredicateContainerSubmit;
					
					queryPredicateContainer = queryPredicateContainerSubmit;
					
				};
				
			Database ()
				{
				};
				
			~Database ()
				{
				};
				
				
				
				
			void databaseRun ();	
				
			void createRelations ();
				
			void addRelationValues ();
			
			void displayMatchSchemesAndFacts (char* outputFile);
			
			void matchQueries ();
			
			void answerQuery (Relation relationCopy, /*set <Tuple> relationTuplesCopy,*/ Predicate currentQuerySubmit);
			
			void answerQueryStringTest (/*set <Tuple> relationTuplesCopy,*/ Predicate currentQuery, int i);
			vector <int> answerQueryIDTest (Predicate currentQuery, unsigned int i);
			
			void displaySelectProjectRename (Relation currentOutputRelation, Predicate currentQuery);
			
			
			void displayResults (/*map <string, vector <int>> queryVariableIndexContainer,*/ /*set <Tuple> relationTuplesCopy,*/ Predicate currentQuery);
			
			void displayResultsStrings (char* outputFile, Predicate currentQuery);
			
			void displayResultsProject (char* outputFileName, Predicate currentQuery);
			
			vector <int> getUniqueVariableIndexValues (vector <int> currentQueryVariableIndexValues, vector <Parameter> currentQueryBody);
			
			//Old Code Material
			/*
			Database (vector <Predicate> schemePredicateContainerSubmit, vector <Predicate> factPredicateContainerSubmit, vector< vector<string>> factPredicateStringContainerSubmit, vector <Predicate> queryPredicateContainerSubmit, char* argv2) //: schemePredicateContainer (schemePredicateContainerSubmit), factPredicateContainer (factPredicateContainerSubmit), factPredicateStringContainer (factPredicateStringContainerSubmit), queryPredicateContainer (queryPredicateContainerSubmit)
				{
					outputFile = argv2;
					
					schemePredicateContainer = schemePredicateContainerSubmit;
					factPredicateContainer = factPredicateContainerSubmit;
					factPredicateStringContainer = factPredicateStringContainerSubmit;
					queryPredicateContainer = queryPredicateContainerSubmit;
				};
			
			~Database ()
				{
					
				};
				
				
			void databaseRun ();
			
			void createRelations ();
			
			void addRelationValues ();
			
			void displayMatchSchemesAndFacts (char* outputFile);
			
			void matchQueries ();
			void answerQuery (set <vector <string>> relationValuesCopy, Predicate currentQuery);
			
			
			
			
			
			bool answerQuerySelect (set <vector <string>> currentQueryRelationTest, Predicate currentQuery);
			bool answerQueryRename (set <vector <string>> currentQueryRelationTest, Predicate currentQuery);
			bool answerQueryProject (set <vector <string>> currentQueryRelationTest, Predicate currentQuery);
			
			
			void displayResults (map <string, vector <int>> queryVariableIndexContainer, set <vector <string>> relationValuesCopy, Predicate currentQuery);
			*/
	};




#endif /* DATABASE_H_ */
