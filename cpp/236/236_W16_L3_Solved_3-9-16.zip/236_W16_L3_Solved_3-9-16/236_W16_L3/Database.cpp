/*
 * dataBase.cpp
 *
 *  Created on: Oct 22, 2015
 *      Author: heypono
 */


#include "Database.h"

//Create a Relation for each Scheme Predicate and ADD the Relation to the MAP
void Database::createRelations ()
	{
		cout << "Creating Relations" << endl << endl;
	
		//Look at each Scheme Predicate
		for (unsigned int i = 0; i < schemePredicateContainer.size(); i++)
			{
				
				vector <string> currentSchemeStrings;
				
				for (unsigned int j = 0; j < schemePredicateContainer[i].getBodyComponents().size(); j++)
					{
						currentSchemeStrings.push_back (schemePredicateContainer[i].getBodyComponents()[j].getTokenValue());
					}
					
				Scheme currentSchemeColumnNames (currentSchemeStrings);
					
				//Create a Relation for the CURRENT Scheme Predicate
				Relation relationCreate (schemePredicateContainer[i].toStringName(), currentSchemeColumnNames);
				
				//Add the NEW Relation into the MAP
				//For a KEY to the NEW Relation, use the CURRENT Scheme Predicate's NAME
				relationContainer [schemePredicateContainer[i].toStringName()] = relationCreate;
			}
		
		cout << "Finished Creating Relations... Now Inserting Relation Table Values (Fact Predicate Strings)" << endl << endl;
		
		//Add Table Values for each Relation that MATCHES a Fact Predicate's NAME
		addRelationValues();
	}






//This is the MAIN Funtion for the Database
void Database::databaseRun ()
	{
		createRelations();
	}






//Add the String Elements from each Fact Predicate into the Relation Table that MATCHES the Fact Predicate's NAME 
void Database::addRelationValues ()
	{
		cout << "Inserting Fact Predicate String Elements into PROPER Relation Tables" << endl << endl;
		
		//Look at each Fact Predicate
		for (unsigned int i = 0; i < factPredicateContainer.size(); i++)
			{
				//factPredicateSet.insert (factPredicateContainer[i]);
				
				//Find the proper Relation that MATCHES the CURRENT Fact Predicate's NAME
				map<string, Relation>::iterator relationNamesIterator = relationContainer.find(factPredicateContainer[i].toStringName());
				
				Relation properRelation;
						
				//If the CURRENT Fact Predicate's NAME is found inside the MAP then add the String Elements from the CURRENT Fact Predicate BODY into the Relation
				if (relationNamesIterator != relationContainer.end())
					{					
						vector <string> currentFactStrings;
						
						cout << "Adding tuple values for the [" << factPredicateContainer[i].toStringName() << "] Relation" << endl << endl;
						cout << "Tuple values being added are: " << factPredicateContainer [i].toStringBody() << endl << endl;
						
						for (unsigned int j = 0; j < factPredicateContainer[i].getBodyComponents().size(); j++)
							{
								currentFactStrings.push_back (factPredicateContainer[i].getBodyComponents()[j].getTokenValue());
							}
						
						Tuple tupleCreate (currentFactStrings);
						
						cout << tupleCreate.toStringTupleValues();
						
						//Add the CURRENT Fact Predicate's String Elements as Tuple Values into the proper Relation Table
						relationNamesIterator->second.insertTuples (tupleCreate);
					}
			}
		
		
		cout << "Now Checking if the Tuple Values were ACTUALLY SAVED in the Relation Tables" << endl << endl;

		
		for (std::map <string, Relation>::iterator it = relationContainer.begin(); it != relationContainer.end(); it++)
			{
				cout << "The number of Tuples in the current Relation, " << it->first << ", is" << it->second.getTupleCount() << endl << endl;
				
				it->second.displayTuples();
			}
		
		cout << "Now Will Attempt to Match Queries" << endl << endl;
		
		
		//Match the Schemes and Facts information using each relation's tuple values
		displayMatchSchemesAndFacts(outputFile);
		
		
		
	}
	
	
	
	
	
	
	
	
	
	
	
void Database::displayMatchSchemesAndFacts (char* outputFileName)
{
	
	stringstream outputStringStream;
	//ofstream outputFileStream;
	
	outputFileStream.open (outputFileName);
	
	outputFileStream << "Scheme Evaluation" << endl << endl;
	
	outputFileStream << "Fact Evaluation" << endl << endl;
	
	for (std::map <string, Relation>::iterator it = relationContainer.begin(); it != relationContainer.end(); it++)
		{
			//outputFileStream << it->first << endl;
			outputStringStream << it->first << endl;
			
			vector <string> currentRelationTupleNames = it->second.getTupleNames();
			
			set <Tuple> currentRelationTuples = it->second.getTuples();
			
			for (std::set <Tuple>::iterator relationTupleIterator = currentRelationTuples.begin(); relationTupleIterator != currentRelationTuples.end(); relationTupleIterator++)
				{
					vector <string> currentTuple;
					
					currentTuple = *relationTupleIterator;
					
					//vector <Parameter> currentFactPredicateParameters;
					
					//currentFactPredicateParameters = currentFactPredicate.getBodyComponents();
					
					for (unsigned int i = 0; i < currentTuple.size(); i++)
						{
							if (i == 0)
								{
									//outputFileStream << "  " << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
									outputStringStream << "  " << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
								}
							else if (i < currentTuple.size())
								{
									//outputFileStream << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
									outputStringStream << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
								}
							else
								{
									//outputFileStream << currentRelationTupleNames[i] << "=" << currentTuple[i];
									outputStringStream << currentRelationTupleNames[i] << "=" << currentTuple[i];
								}
						}
						
					//outputFileStream << endl;
					outputStringStream << endl;
					
					
				}
				
				//outputStringStream << "Query Evaluation" << endl << endl;
				
				//outputFileStream << outputStringStream.str();
				//outputFileStream.flush();
				
				outputStringStream << endl;
		}
		
		outputStringStream << "Query Evaluation" << endl << endl;
				
		outputFileStream << outputStringStream.str();
		
		//Match Query Predicates with the proper Relation Table
		matchQueries();
}
	
	
	
	





//Match Query Predicates with the proper Relation Table 
void Database::matchQueries()
	{	
		//cout << "Beginning process of Matching Queries" << endl << endl;
	
		//set <Tuple> relationTuplesCopy;
	
		//cout << "Declared set for copying the Tuple Values" << endl << endl;
		
		//Look at each Query Predicate
		for (unsigned int i = 0; i < queryPredicateContainer.size(); i++)
			{
				//cout << "Looking for the CURRENT Query Predicate NAME in the MAP to find the Proper Relation" << endl << endl;
				
				//Find the proper Relation that MATCHES the CURRENT Query Predicate's NAME
				map <string, Relation>::iterator mapIterator = relationContainer.find (queryPredicateContainer[i].toStringName());
				
				Relation relationCopy = mapIterator->second;
				
				//If the CURRENT Query Predicate's NAME is found in the MAP, copy the Tuple Values from that Relation in order to TRY answering the Query
				if (mapIterator != relationContainer.end())
					{
						//Copy the Tuple Values from the proper Relation in the MAP in order to TRY answering the Query
						relationTuplesCopy =  mapIterator->second.getTuples();
						
						
						//If the CURRENT Query Predicate's NAME is in the MAP, AND the Tuple Values from that Relation Table in the MAP were successfully copied,
						//then submit those Tuple Values to check whether they can answer the CURRENT Query
						if (relationTuplesCopy.size() >= 0)
							{
								//cout << "Calling the Answer Query Function on Q Predicate " << queryPredicateContainer[i].toStringName() << endl << endl;
								//cout << "The Parameters for this Q Predicate are: " << queryPredicateContainer[i].toStringBody() << endl;
								
								//cout << endl << endl;
								cout << "About to go to the Answer Query Function. The Query attempting to answer is: " << queryPredicateContainer[i].toStringBody() << endl;
								
								cout << "The Tuple Values being tested for whether they can answer this Query are: " << endl;
								mapIterator->second.displayTuples();
								
								Predicate currentQuerySubmit = queryPredicateContainer[i];
								
								answerQuery (relationCopy, /*relationTuplesCopy,*/ currentQuerySubmit);
							}
					}
			}
	}










//Check whether the submitted Tuple Values can answer the submitted Query
void Database::answerQuery (Relation relationCopy, /*set <Tuple> relationTuplesCopy,*/ Predicate currentQuery)
	{
		cout << "Entered the Answer Query Function" << endl << endl;
	
		//Vector to hold the Parameter Values from the CURRENT Query Predicate Body
		vector <Parameter> currentQueryBody = currentQuery.getBodyComponents();
		
		//MAP to hold Vectors of (Potentially MULTIPLE Different Variables) Variable locations within the CURRENT Query Predicate Body
		map <string, vector <int>> queryVariableIndexContainer;
		
		cout << "Attempting to answer Query: " << endl;
		cout << currentQuery.toStringBody() << endl << endl;
		
		vector <int> queryVariableIndexes;
		
		//Relation selectOnStringRelation (relationCopy.getRelationName(), relationCopy.getTupleNames());
		
		//Relation selectOnIDRelation (relationCopy.getRelationName(), relationCopy.getTupleNames());
	
		//Look at each Element in the CURRENT Query Predicate Body
		for (unsigned int i = 0; i < currentQueryBody.size(); i++)
			{
				cout << "Iterating through the CURRENT Query Predicate Body" << endl;
				cout << "At element [" << i << "] which is: " << currentQueryBody[i].getTokenValue() << endl << endl;
			
				//If the CURRENT Element is a String, check whether that String Value is matched by RELATION Table Values
				if (currentQueryBody[i].getTokenType() == "STRING")
					{
						cout << "Calling the Answer Query STRINGS function" << endl;
						
						//answerQueryStringTest (/*relationTuplesCopy,*/ currentQuery, i);
						
						//relationCopy.displayTuples();
						
						//Relation temp = relationCopy.selectString (i, currentQueryBody[i].getTokenValue());
						//selectOnStringRelation = relationCopy.selectOnString (i, currentQueryBody[i].getTokenValue());
						relationCopy = relationCopy.selectOnString (i, currentQueryBody[i].getTokenValue());
						//relationCopy.displayTuples();
					}
				
				
				
				//This is the portion I'm currently working on (note left 10:00 PM 2/26/2016)
				//If the CURRENT Element in the Query Predicate is NOT a String, then it MUST be a ID/Variable
				//else if (queryVariableIndexContainer[currentQueryBody[i].getTokenValue()].size() == 0)
				else if (currentQueryBody[i].getTokenType() == "ID")
					{
						
						//cout << "Calling the Answer Query ID function" << endl;
						cout << "Calling the selectOnID function in Relation.h" << endl;
						
						vector <int> currentVariableIndexContainer = answerQueryIDTest (currentQuery, i);
						
						string currentVariable = currentQueryBody[i].getTokenValue();
						
						relationCopy = relationCopy.selectOnID (currentVariableIndexContainer, currentVariable);
						
						//answerQueryIDTest (currentQuery, i);
						
						
						
						
						//relationTuplesCopy
						
						
						
						/*
						
						//vector <Parameter> currentQueryBody = currentQuery.getBodyComponents();
		
						cout << "Found a Variable in the CURRENT Query Predicate" << endl << endl;
						cout << "The Variable Value is: " << currentQueryBody[i].getTokenValue() << endl << endl;
						
						//Vector to hold the Variable locations within the CURRENT Query Predicate Body
						vector <int> currentVariableIndexContainer;
						
						//Add the CURRENT Index to the Vector of ID/Variable Index locations within the CURRENT Query Predicate Body
						currentVariableIndexContainer.push_back (i);
						
						//Set the Tuple Name for the RELATION Table at the CURRENT Index to the ID/Variable Value
						//relationContainer[currentQuery.toStringName()].setColumnNames (i, currentQueryBody[i].getTokenValue());
						
						cout << "Creating a New Entry in the Variable INDEX MAP for Variable " << currentQueryBody[i].getTokenValue() << endl << endl;
						//Add the Vector of Variable locations to the MAP with the KEY of the ID/Variable Value
						queryVariableIndexContainer[currentQueryBody[i].getTokenValue()] = currentVariableIndexContainer;
					
						
						//Store the INDEX for each occurrence of the CURRENT Variable
						for (unsigned int l = i; l < currentQueryBody.size(); l++)
							{
								//If the SAME ID/Variable Value is found AGAIN in the CURRENT Query Predicate Body, store the new location to the Vector
								if (currentQueryBody[l].getTokenValue() == currentQueryBody[i].getTokenValue())
									{
										for (std::set<Tuple>::iterator m = relationTuplesCopy.begin(); m != relationTuplesCopy.end(); m++)
											{
												Tuple duplicateTuple = *m;
												
												if (duplicateTuple[i] != duplicateTuple[l])
													{
														std::set <Tuple>::iterator mTemporary;
														
														mTemporary = m;
														
														mTemporary++;
														
														relationTuplesCopy.erase (m);
														
														m = mTemporary;
													}
											}
										
										cout << "The INDEX Values stored for Variable " << currentQueryBody[l].getTokenValue() << " are:" << endl;
										
										for (unsigned int index = 0; index < queryVariableIndexContainer[currentQueryBody[l].getTokenValue()].size(); index++)
											{
												cout << "[" << index << "] is the Index Value: " << queryVariableIndexContainer[currentQueryBody[l].getTokenValue()][index] << endl;
											}
									
										cout << "Now adding the NEW Index Value of: " << l << endl << endl;
										
										//currentVariableIndexContainer.push_back (l);
										queryVariableIndexContainer[currentQueryBody[l].getTokenValue()].push_back (l);
										
										//Set the Tuple Name for the RELATION Table at the CURRENT Index to the ID/Variable Value
										//relationContainer[currentQuery.toStringName()].setTupleNames (l, currentQueryBody[l].getTokenValue());
									}
							}

						*/
					}
				
				
				else
					{
	
					}
			}
		
		/*
		relationCopy.displayTuples();
		
		cout << endl << endl << endl;
		cout << "Displaying Tuple Column Names and Associated Values" << endl;
		cout << relationCopy.displayTuplesSelect();
		
		
		cout << endl << endl << endl;
		cout << "Displaying Projected Tuple Column Names and Associated Values" << endl;
		cout << relationCopy.displayTuplesProjectRename(queryTotalVariableIndexContainer, relationCopy.getTupleNames());
		
		
		cout << endl << endl;
		cout << "Converting Column Names for RENAME" << endl;
		relationCopy.convertColumnNames (currentQuery);
		cout << endl << endl;
		cout << relationCopy.displayTuplesProjectRename(queryTotalVariableIndexContainer, relationCopy.getTupleNames());
		
		queryTotalVariableIndexContainer.clear();
		queryTotalVariableContainer.clear();
		*/
		//selectOnStringsRelation.displayTuples();
		//selectOnIDRelation.displayTuples();
		//displayResults (/*queryVariableIndexContainer,*/ /*relationTuplesCopy,*/ currentQuery);
		
		displaySelectProjectRename (relationCopy, currentQuery);
	}
	
	
	
	
	
	
	
	
void Database::displaySelectProjectRename (Relation currentOutputRelation, Predicate currentQuery)
	{
		stringstream outputStringStream;
		
		//outputStringStream << "Currently outputting Relation: " << currentOutputRelation.getRelationName() << "\t which has " << currentOutputRelation.getTupleCount() << " Tuples" << endl << endl;
		
		if (currentOutputRelation.getTupleCount() > 0)
			{
				outputStringStream << currentQuery.toStringName() << currentQuery.toStringBody() << "? Yes(" << currentOutputRelation.getTupleCount() << ")" << endl;
				//outputFileStream << outputStringStream.str();
				
				outputStringStream << "select" << endl;
				outputStringStream << currentOutputRelation.displayTuplesSelect();
				//outputFileStream << outputStringStream.str();
				
				
				outputStringStream << "project" << endl;
				outputStringStream << currentOutputRelation.displayTuplesProjectRename (queryTotalVariableIndexContainer, currentOutputRelation.getTupleNames());
				//outputFileStream << outputStringStream.str();
				
				
				currentOutputRelation.convertColumnNames (currentQuery);
				outputStringStream << "rename" << endl;
				outputStringStream << currentOutputRelation.displayTuplesProjectRename (queryTotalVariableIndexContainer, currentOutputRelation.getTupleNames()) << endl;
				outputFileStream << outputStringStream.str();
			}
			
		else
			{
				//stringstream outputStringStream;
				outputStringStream << currentQuery.toStringName() << currentQuery.toStringBody() << "? No" << endl << endl;
				
				outputFileStream << outputStringStream.str();
			}
			
		queryTotalVariableIndexContainer.clear();
		queryTotalVariableContainer.clear();
	}
	

	
	
	
	



//void Database::answerQueryStringTest (/*set <Tuple> currentRelationTuplesCopy,*/ Predicate currentQuery, int i)
	/*{
		set <Tuple> temporaryRelationTuplesCopyReplace;
		
		vector <Parameter> currentQueryBody = currentQuery.getBodyComponents();
		
		cout << "The Number of TUPLES being tested for whether they can answer this query is: " << relationTuplesCopy.size() << endl << endl;
					
		//Look at each Tuple within the CURRENT Relation Table
		for (std::set <Tuple>::iterator j = relationTuplesCopy.begin(); j != relationTuplesCopy.end(); j++)
			{
				//Capture the CURRENT Tuple
				Tuple currentRelationValues = *j;
				
				cout << "(inside the answerQuery Function) Printing the Elements for the current tuple being TESTED" << endl << endl;
				
				string currentTupleBeingTested;
				currentTupleBeingTested = currentRelationValues.toStringTupleValues();
				
				
				//for (unsigned int k = 0; k < currentRelationValues.size(); k++)
					//{
						//currentTupleBeingTested += currentRelationValues[k] + ", ";
					//}
				
				
				cout << "The CURRENT tuple values being tested INSIDE the answerQuery Function: " << currentTupleBeingTested << endl << endl;
			
				//If the CURRENT Element from the Query Predicate Body DOES NOT match the CURRENT Tuple's Element at the SAME INDEX,
				//then the CURRENT Tuple is NOT a match for the CURRENT Query
				//if (currentQueryBody[i].getTokenValue() != currentRelationValues[i])
				
				//if (currentQueryBody[i].getTokenValue() != currentRelationValues[i])
					//{
						//std::set <vector <string>>::iterator jTemporary;
					
						//jTemporary = j;
						
						//jTemporary--;
						
						//cout << "Deleting " << currentTupleBeingTested << endl << endl;
						
						//relationTuplesCopy.erase (j);
						
						//j--;
						
						//cout << "Deleted " << currentTupleBeingTested << endl << endl;
						
						//j = jTemporary;
						
					//}
				
					
					
				if (currentQueryBody[i].getTokenValue() == currentRelationValues[i])
					{
						//std::set <vector <string>>::iterator jTemporary;
					
						//jTemporary = j;
						
						//jTemporary--;
						
						cout << "Adding " << currentTupleBeingTested << endl << endl;
						
						temporaryRelationTuplesCopyReplace.insert (*j);
						
						//j--;
						
						cout << "Added " << currentTupleBeingTested << endl << endl;
						
						//j = jTemporary;
						
					}
				
				
				//if (relationTuplesCopy.size() == 0)
					//{
						//map <string, vector <int>> queryVariableIndexContainer;
						
						//displayResults (queryVariableIndexContainer, relationTuplesCopy, currentQuery);
					
						//return;
					//}
				
			}
			
		relationTuplesCopy = temporaryRelationTuplesCopyReplace;
			
	}
*/
	
	
	
	
	
	
	
	
vector <int> Database::answerQueryIDTest (Predicate currentQuery, unsigned int i)
	{
		set <Tuple> temporaryRelationTuplesCopyReplace;
		
		vector <Parameter> currentQueryBody = currentQuery.getBodyComponents();
		
		cout << "Found a Variable in the CURRENT Query Predicate" << endl << endl;
		cout << "The Variable Value is: " << currentQueryBody[i].getTokenValue() << endl << endl;
		
		//Vector to hold the Variable locations within the CURRENT Query Predicate Body
		//vector <int> currentVariableIndexContainer;
		
		//Add the CURRENT Index to the Vector of ID/Variable Index locations within the CURRENT Query Predicate Body
		vector <int> currentVariableIndexContainer;
		currentVariableIndexContainer.push_back (i);
		
		vector <int> currentVariableIndexes = queryTotalVariableContainer[currentQueryBody[i].getTokenValue()];
		
		if (currentVariableIndexes.size() == 0)
		{
			queryTotalVariableContainer[currentQueryBody[i].getTokenValue()].push_back (i);
			
			queryTotalVariableIndexContainer[i].push_back (i);
		}
		//Set the Tuple Name for the RELATION Table at the CURRENT Index to the ID/Variable Value
		//relationContainer[currentQuery.toStringName()].setColumnNames (i, currentQueryBody[i].getTokenValue());
		
		cout << "Creating a New Entry in the Variable INDEX MAP for Variable " << currentQueryBody[i].getTokenValue() << endl << endl;
		//Add the Vector of Variable locations to the MAP with the KEY of the ID/Variable Value
		queryVariableIndexContainer[currentQueryBody[i].getTokenValue()] = currentVariableIndexContainer;
	
		
		//Store the INDEX for each occurrence of the CURRENT Variable
		for (unsigned int l = i; l < currentQueryBody.size(); l++)
			{
				//If the SAME ID/Variable Value is found AGAIN in the CURRENT Query Predicate Body, store the new location to the Vector
				if (currentQueryBody[l].getTokenValue() == currentQueryBody[i].getTokenValue() && l != i)
					{
						/*
						for (std::set<Tuple>::iterator m = relationTuplesCopy.begin(); m != relationTuplesCopy.end(); m++)
							{
								Tuple duplicateTuple = *m;
								
								
								if (duplicateTuple[i] != duplicateTuple[l])
									{
										
										std::set <Tuple>::iterator mTemporary;
										
										mTemporary = m;
										
										mTemporary++;
										
										relationTuplesCopy.erase (m);
										
										m = mTemporary;
										
									}
								
								
								
								if (duplicateTuple[i] == duplicateTuple[l])
									{
										
										temporaryRelationTuplesCopyReplace.insert (*m);
										
									}
								
							}
						
						
						
						cout << "The INDEX Values stored for Variable " << currentQueryBody[l].getTokenValue() << " are:" << endl;
						
						for (unsigned int index = 0; index < queryVariableIndexContainer[currentQueryBody[l].getTokenValue()].size(); index++)
							{
								cout << "[" << index << "] is the Index Value: " << queryVariableIndexContainer[currentQueryBody[l].getTokenValue()][index] << endl;
							}
					
						cout << "Now adding the NEW Index Value of: " << l << endl << endl;
						*/
						currentVariableIndexContainer.push_back (l);
						
						queryTotalVariableIndexContainer[i].push_back (l);
						
						//queryVariableIndexContainer[currentQueryBody[l].getTokenValue()].push_back (l);
						
						//Set the Tuple Name for the RELATION Table at the CURRENT Index to the ID/Variable Value
						//relationContainer[currentQuery.toStringName()].setTupleNames (l, currentQueryBody[l].getTokenValue());
					}
			}
			
			cout << "Displaying the index locations for Variable " << currentQueryBody[i].getTokenValue() << endl << endl;
			for (unsigned int i = 0; i < currentVariableIndexContainer.size(); i++)
				{
					cout << "currentVariableIndexContainer[" << i << "] = " << currentVariableIndexContainer[i] << endl;
				}
			
			return currentVariableIndexContainer;
			//relationTuplesCopy = temporaryRelationTuplesCopyReplace;
	}













//Display the results of Answering the Query
//void Database::displayResults (/*map <string, vector <int>> queryVariableIndexContainer,*/ /*set <Tuple> relationValuesCopy,*/ Predicate currentQuery)
	/*{
		//Tell how many FACTS Predicates satisfy the submitted QUERY
		if (relationTuplesCopy.size() > 0 && queryVariableIndexContainer.size() == 0)
			{
				cout << "Relation Tuples Copy > 0, AND queryVariableIndexContainer size = 0" << endl << endl;
				
				//cout << currentQuery.toStringName() << "(" << currentQuery.toStringBody() << ")?  Yes(" << relationTuplesCopy.size() << ")" << endl;
				//cout << "There are " << relationValuesCopy.size() << " elements in the reuslt" << endl << endl;
				
				displayResultsStrings (outputFile, currentQuery);
				
				displayResultsProject (outputFile, currentQuery);
			}
		
		//Tell how many FACTS Predicates satisfy the submitted QUERY AND tell what String LITERAL values each Variable in the QUERY may assume
		else if (relationTuplesCopy.size() > 0 && queryVariableIndexContainer.size() > 0)
			{
				cout << "Both the Relation Tuples copy > 0 AND queryVariableIndexContainer > 0" << endl << endl;
				
				
				
				//cout << currentQuery.toStringName() << "(" << currentQuery.toStringBody() << ")?  Yes(" << relationTuplesCopy.size() << ")" << endl;
				
				displayResultsStrings (outputFile, currentQuery);
				
				displayResultsProject (outputFile, currentQuery);
				
				
				//for (std::map <string, vector <int>>::iterator itVariable = queryVariableIndexContainer.begin(); itVariable != queryVariableIndexContainer.end(); itVariable++)
					//{
						//vector <int> currentQueryVariableIndexValues = itVariable->second;
						
						//string currentQueryVariableValue = itVariable->first;
						
						//cout << "The current Query Variable is: " << currentQueryVariableValue << endl;
						//cout << "This Variable is located at these indices within the Query Predicate: " << endl << endl;
						
						//for (int i = 0; i < currentQueryVariableIndexValues.size(); i++)
							//{
								//cout << "[" << currentQueryVariableIndexValues[i] << "]" << endl;
							//}
						
						
						//for (std::set <vector <string>>::iterator itTuple = relationValuesCopy.begin(); itTuple != relationValuesCopy.end(); itTuple++)
							//{
								//vector <string> currentTuple = *itTuple;
						
								//for (int i = 0; i < currentQueryVariableIndexValues.size(); i++)
									//{
										//cout << currentQueryVariableValue << " = " << currentTuple[currentQueryVariableIndexValues[i]] << endl;
										//cout << "Above Current Variable Value is located at index [" << currentQueryVariableIndexValues[i] << "] inside the FACT Predicate Body" << endl << endl;
									//}
							//}
						
					//}
				
				
				//for (std::set <Tuple>::iterator itTuple = relationTuplesCopy.begin(); itTuple != relationTuplesCopy.end(); itTuple++)
					//{
						//cout << "Looping thrhough the Tuples in the Answer" << endl;
					
						//Tuple currentTuple = *itTuple;
						
						//string tupleValuesInVariables;
					
						//unsigned int indexInTuple;
						
						//for (unsigned int i = 0; i < currentTuple.size(); i++)
							//{
								//indexInTuple = i;
							
								//cout << "Looping WITHIN the current Tuple" << endl;
							
								
							
								//for (std::map <string, vector<int>>::iterator itVariable = queryVariableIndexContainer.begin(); itVariable != queryVariableIndexContainer.end(); itVariable++)
									//{
										//vector <int> currentQueryVariableIndexValues = itVariable->second;
										
										//set <int> uniqueVariableIndexValues;
										
										//for (unsigned int j = 0; j < currentQueryVariableIndexValues.size(); j++)
											//{
												/cout << "Inserting the index value" << currentQueryVariableIndexValues[j] << endl;
											
												//uniqueVariableIndexValues.insert (currentQueryVariableIndexValues[j]);
											//}
										
										//string currentQueryVariableValue = itVariable->first;
										
										//cout << "Current variable Index Vector Size: " << currentQueryVariableIndexValues.size() << endl << endl;

										
										//for (std::set <int>::iterator k = uniqueVariableIndexValues.begin(); k != uniqueVariableIndexValues.end(); k++)
											//{
												//int currentUniqueIndex = *k;
												
												//cout << "current Unique Index Value: " << currentUniqueIndex << endl;
											
												//if (itVariable != queryVariableIndexContainer.end() && i == 0)
													//{
														//tupleValuesInVariables += currentQueryVariableValue + "= " + currentTuple[currentUniqueIndex] + ", ";
													//}
												
												//else
													//{
														//tupleValuesInVariables += currentQueryVariableValue + "= " + currentTuple[currentUniqueIndex];
													//}
											//}
										
									//}
								
								
							//}
						
						//if (indexInTuple == currentTuple.size() - 1)
							//{
								//cout << "Tuple Values for EAch Variable: " << tupleValuesInVariables << endl;
								//tupleValuesInVariables = "";
							//}
						
						
					//}
					
				
			//}
	
		//Otherwise, NO FACTS Predicates satisfy the submitted QUERY
		//else
			//{
				//cout << currentQuery.toStringName() << "(" << currentQuery.toStringBody() << ")?  No" << endl;
			//}
		
		
		
		//Clear out the queryVariableIndexContainer MAP in order to input all FRESH index values for the NEXT Query Predicate
		
		//for (std::map <string, vector <int>>::iterator itVariableClear = queryVariableIndexContainer.begin(); itVariableClear != queryVariableIndexContainer.end(); itVariableClear++)
			//{
				//delete itVariableClear->first;
				//delete itVariableClear->second;
			//}
		
		
		//queryVariableIndexContainer.clear();
		
		
		
		//for (std::set <vector <string>>::iterator it = relationValuesCopy.begin(); it != relationValuesCopy.end(); it++)
			//{
				//vector <string> currentRelationValues = *it;
				
				//string result;
				
				//for (int i = 0; i < currentRelationValues.size(); i++)
					//{
						//result += currentRelationValues[i];
					//}
				
				//cout << "Result: " << result << endl << endl;
			//}
		
		
		//cout << "I just displayed the result" << endl << endl;
	}








void Database::displayResultsStrings (char* outputFileName, Predicate currentQuery)
	{
		stringstream outputStringStream;
		
		//ofstream outputFileStream;
	
	//outputFileStream.open (outputFileName);
	
	//outputFileStream << "Scheme Evaluation" << endl << endl;
	
	//outputFileStream << "Fact Evaluation" << endl << endl;
	
	outputStringStream << currentQuery.toStringName() << "(" << currentQuery.toStringBody() << ")?  Yes(" << relationTuplesCopy.size() << ")" << endl;
	
	outputStringStream << "select" << endl;
	
	vector <string> currentRelationTupleNames;
	
	std::map <string, Relation>::iterator it = relationContainer.find(currentQuery.toStringName());
	//for (std::map <string, Relation>::iterator it = relationContainer.begin(); it != relationContainer.end(); it++)
		//{
			//outputFileStream << it->first << endl;
			//outputStringStream << it->first << endl;
			if (it != relationContainer.end())
				{
					currentRelationTupleNames = it->second.getTupleNames();
				}
			set <Tuple> currentRelationTuples = relationTuplesCopy;//it->second.getTuples();
			
			for (std::set <Tuple>::iterator relationTupleIterator = currentRelationTuples.begin(); relationTupleIterator != currentRelationTuples.end(); relationTupleIterator++)
				{
					vector <string> currentTuple;
					
					currentTuple = *relationTupleIterator;
					
					//vector <Parameter> currentFactPredicateParameters;
					
					//currentFactPredicateParameters = currentFactPredicate.getBodyComponents();
					
					for (unsigned int i = 0; i < currentTuple.size(); i++)
						{
							if (i == 0)
								{
									//outputFileStream << "  " << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
									outputStringStream << "  " << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
								}
							else if (i < currentTuple.size())
								{
									//outputFileStream << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
									outputStringStream << currentRelationTupleNames[i] << "=" << currentTuple[i] << " ";
								}
							else
								{
									//outputFileStream << currentRelationTupleNames[i] << "=" << currentTuple[i];
									outputStringStream << currentRelationTupleNames[i] << "=" << currentTuple[i];
								}
						}
						
					//outputFileStream << endl;
					outputStringStream << endl;
				} 
		//}
		
		
		outputFileStream << outputStringStream.str();
	}








void Database::displayResultsProject (char* outputFileName, Predicate currentQuery)
	{
		stringstream outputStringStream;
		
		outputStringStream << "project" << endl;
		
		//outputFileStream << outputStringStream.str();
		
		unsigned int indexInTuple;
		
		//unsigned int variableCountOnCurrentLoop = 0;
		
		vector <Parameter> currentQueryBody = currentQuery.getBodyComponents();
		
		map <string, vector <int>> variableValueAndUniqueIndexValues;
		
		vector <int> uniqueVariableIndexValues;
		
		unsigned int tupleCount = 0;
		
		//unsigned int indexInTuple;
		
		for (std::set <Tuple>::iterator itTuple = relationTuplesCopy.begin(); itTuple != relationTuplesCopy.end(); itTuple++)
			{
				cout << "Looping thrhough the Tuples in the Answer" << endl;
			
				Tuple currentTuple = *itTuple;
				
				string tupleValuesInVariables;
				
				//int displayIndex = 0;
			
				//unsigned int indexInTuple;
				
				for (unsigned int i = 0; i < currentTuple.size(); i++)
					{
						indexInTuple = i;
					
						//cout << "Looping WITHIN the current Tuple" << endl;
					
						
					
						for (std::map <string, vector<int>>::iterator itVariable = queryVariableIndexContainer.begin(); itVariable != queryVariableIndexContainer.end(); itVariable++)
							{
								vector <int> currentQueryVariableIndexValues = itVariable->second;
								
								
								uniqueVariableIndexValues = getUniqueVariableIndexValues (currentQueryVariableIndexValues, currentQueryBody);
								
								//set <int> uniqueVariableIndexValues;
								
								//set <string> uniqueVariableStrings;
								
								//for (unsigned int j = 0; j < currentQueryVariableIndexValues.size(); j++)
									/{
										//cout << "Inserting the index value" << currentQueryVariableIndexValues[j] << endl;
									
										
										//I think here I need to make sure that the Variable, in the Query, that's associated with the
										//current index value is NOT duplicated in the output
										
										//If the current String is NOT already in the Domain, insert it, otherwise, move on
										//set<int>::iterator it = uniqueVariableIndexValues.find(currentQueryBody[j].gettTokenValue());
										
										///set<string>::iterator it = uniqueVariableStrings.find(currentQueryBody[currentQueryVariableIndexValues[j]].getTokenValue());
										
										//if (it != uniqueVariableStrings.end())//std::find(std::begin(uniqueVariableStrings), std::end(uniqueVariableStrings), currentQueryBody[currentQueryVariableIndexValues[j]].getTokenValue()) != std::end(uniqueVariableStrings))
											//{

												//The String was found already in the Domain, so move on
											//}
										//else
											//{
												//The String was NOT already in the Domain, so insert it
												
												//if (currentFactToken.tokenType == "STRING")
												//{
													//factDomain.insert(currentFactToken.tokenValue);
												//}
												
												//uniqueVariableStrings.insert (currentQueryBody[currentQueryVariableIndexValues[j]].getTokenValue());
												
												//uniqueVariableIndexValues.insert (currentQueryVariableIndexValues[j]);
											//}
										
										
																			
										//uniqueVariableIndexValues.insert (currentQueryVariableIndexValues[j]);
									//}
								
								
								//string currentQueryVariableValue = itVariable->first;
								
								//cout << "Current variable Index Vector Size: " << currentQueryVariableIndexValues.size() << endl << endl;

								
								
								
										//for (std::set <int>::iterator k = uniqueVariableIndexValues.begin(); k != uniqueVariableIndexValues.end(); k++)
											//{
												//int currentUniqueIndex = *k;
												
												//cout << "current Unique Index Value: " << currentUniqueIndex << endl;
											
												//if (itVariable != queryVariableIndexContainer.end() && i==0)
													//{
													
													//if (indexInTuple % 2 == 0 && tupleCount % 2 == 0)
														//{
															//tupleValuesInVariables += currentQueryVariableValue + "= " + currentTuple[uniqueVariableIndexValues[i]] + ", ";//currentTuple[currentUniqueIndex] + ", ";
						//break;
															//tupleCount++;
														
														//}
														
														//else if (indexInTuple % 2 == 0 && tupleCount % 2 == 1)
														//{
														//tupleValuesInVariables += currentQueryVariableValue + "= " + currentTuple[uniqueVariableIndexValues[i+1]] + ", ";
															//tupleCount++;
														//}
														
														//else
														//{
															//break;
														//}
						
														//break;
													//}
												//displayIndex++;
												//else
													//{
														//tupleValuesInVariables += currentQueryVariableValue + "= " + currentTuple[currentUniqueIndex];
														//indexInTuple = currentTuple.size() - 1;
														
													//}
													
											//}
									
								
							//}
						
						//if (indexInTuple == currentTuple.size() - 1)
							//{
								//cout << "Tuple Values for EAch Variable: " << tupleValuesInVariables << endl;
								
								//outputStringStream << tupleValuesInVariables << endl;
								
								//outputFileStream << outputStringStream.str();
								
								//tupleValuesInVariables = "";
							//}
					//}
				
				//if (indexInTuple == currentTuple.size() - 1)
					//{
						//cout << "Tuple Values for EAch Variable: " << tupleValuesInVariables << endl;
						
						//outputStringStream << tupleValuesInVariables << endl;
						
						//outputFileStream << outputStringStream.str();
						
						//tupleValuesInVariables = "";
					//}
				
				
				//outputFileStream << outputStringStream.str();
				
			//}
			
			//outputFileStream << outputStringStream.str();
	//}









vector <int> Database::getUniqueVariableIndexValues (vector <int> currentQueryVariableIndexValues, vector<Parameter> currentQueryBody)
	{
		set <int> uniqueVariableIndexValues;
								
		set <string> uniqueVariableStrings;
		
		for (unsigned int j = 0; j < currentQueryVariableIndexValues.size(); j++)
			{
				cout << "Inserting the index value" << currentQueryVariableIndexValues[j] << endl;
			
				
				//I think here I need to make sure that the Variable, in the Query, that's associated with the
				//current index value is NOT duplicated in the output
				
				//If the current String is NOT already in the Domain, insert it, otherwise, move on
				//set<int>::iterator it = uniqueVariableIndexValues.find(currentQueryBody[j].gettTokenValue());
				
				//set<string>::iterator it = uniqueVariableStrings.find(currentQueryBody[currentQueryVariableIndexValues[j]].getTokenValue());
				
				//if (it != uniqueVariableStrings.end())//std::find(std::begin(uniqueVariableStrings), std::end(uniqueVariableStrings), currentQueryBody[currentQueryVariableIndexValues[j]].getTokenValue()) != std::end(uniqueVariableStrings))
					//{

						//The String was found already in the Domain, so move on
					//}
				//else
					//{
						//The String was NOT already in the Domain, so insert it
						
						//if (currentFactToken.tokenType == "STRING")
						//{
							//factDomain.insert(currentFactToken.tokenValue);
						//}
						
						//uniqueVariableStrings.insert (currentQueryBody[currentQueryVariableIndexValues[j]].getTokenValue());
						
						//uniqueVariableIndexValues.insert (currentQueryVariableIndexValues[j]);
					//}
				
				
													
				//uniqueVariableIndexValues.insert (currentQueryVariableIndexValues[j]);
			//}
			
			
			//vector <int> uniqueVariableIndexValuesVector;
			
			//int currentUniqueIndexValue;
			
			//for (std::set <int>::iterator uniqueIndexValuesIterator = uniqueVariableIndexValues.begin(); uniqueIndexValuesIterator != uniqueVariableIndexValues.end(); uniqueIndexValuesIterator++)
				//{
					//currentUniqueIndexValue = *uniqueIndexValuesIterator;
					
					//uniqueVariableIndexValuesVector.push_back (currentUniqueIndexValue);
				//}
				
			//return uniqueVariableIndexValuesVector;
	}
*/
