/*
 * Predicate.h
 *
 *  Created on: Sep 30, 2015
 *      Author: heypono
 */

#ifndef PREDICATE_H_
#define PREDICATE_H_

#include "Parameter.h"

#include <vector>

#include <iostream>

using namespace std;

class Predicate
	{
		friend class DatalogProgram;
		friend class Rule;
		friend class Main;
	
		private:
			
			//The name of the Predicate Object
			string predicateName;
			
			//The Parameter Objects that are components in the Predicate
			vector<Parameter> bodyComponents;
			
		public:
			Predicate()
				{
				
				};
			
			~Predicate()
				{
				
				};
			
			
			string toStringBody()
				{
					string predicateDisplay = "(";
					
					if (bodyComponents.size() > 0)
						{
							for (unsigned int i = 0; i < bodyComponents.size(); i++)
								{
									if (i < bodyComponents.size() - 1)
										{
											predicateDisplay += bodyComponents[i].tokenValue + ",";
										}
										
									else
										{
											predicateDisplay += bodyComponents[i].tokenValue + ")";
										}
								}
						}
					
					return predicateDisplay;
				};
			
			
			string toStringName()
				{
					return predicateName;
				}
			
			
			vector <Parameter> getBodyComponents ()
				{
					return bodyComponents;
				}
	};




#endif /* 236_LAB1_PREDICATE_H_ */
