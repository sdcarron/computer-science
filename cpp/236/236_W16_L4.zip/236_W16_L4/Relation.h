/*
 * relation.h
 *
 *  Created on: Oct 22, 2015
 *      Author: heypono
 */

#ifndef RELATION_H_
#define RELATION_H_

#include "Predicate.h"
#include "Parameter.h"
#include "Tuple.h"
#include "Scheme.h"

#include <vector>
#include <set>

#include <iostream>
#include <sstream>
#include <string>

#include <map>


using namespace std;


class Relation
	{
		private:
			string name;
		
			Scheme columnNames;
			
			set <Tuple> relationTuples;
			
			//int tupleCount;
	
			//Old Code Material
			/*
			string relationName;
			
			vector <Parameter> tupleNames;
			
			set <vector <string>> tupleValues;
			
			//map <string, string> tupleNameAndValueMap;
			*/
		
	
		public:
		
			Relation (string nameSubmit, Scheme columnNamesSubmit)
				{
					name = nameSubmit;
					
					columnNames = columnNamesSubmit;
					
					//tupleCount = 0;
				};
				
			Relation ()
				{
				};
				
			~Relation ()
				{
				};
				
				
			void setScheme (Scheme schemeSubmit)
				{
					columnNames = schemeSubmit;
				};
				
			
			string getRelationName ()
				{
					return name;
				};
			
			Scheme getTupleNames ()
				{
					return columnNames;
				};
				
				
			set <Tuple> getTuples ()
				{
					return relationTuples;
				};
				
				
			void setColumnNames (int index, string indexName)
				{
					columnNames.setColumnName (index, indexName);
				};
				
			void setRelationName (string relationNameSubmit)
				{
					name = relationNameSubmit;
				};
				
				
			void insertTuples (Tuple tupleSubmit)
				{
					//if (std::find(std::begin(relationTuples), std::end(relationTuples), tupleSubmit) != std::end(relationTuples))
						//{

							//The String was found already in the Domain, so move on
						//}
					//else
						//{
							//The String was NOT already in the Domain, so insert it
							relationTuples.insert(tupleSubmit);
							
							//tupleCount++;
						//} 
					//relationTuples.insert (tupleSubmit);
					
					
				};
				
				
			set <Tuple> insertTuplesSet (set <Tuple> tuplesSubmit)
				{
					set <Tuple> newTuplesAdded;
					
					int tupleCount;
					
					for (std::set <Tuple>::iterator tuplesSubmitIterator = tuplesSubmit.begin(); tuplesSubmitIterator != tuplesSubmit.end(); tuplesSubmitIterator++)
						{
							tupleCount = relationTuples.size ();
							
							Tuple currentTupleSubmit = *tuplesSubmitIterator;
							
							relationTuples.insert(currentTupleSubmit);
							
							if (relationTuples.size () > tupleCount)
								{
									newTuplesAdded.insert (currentTupleSubmit);
								}
						}
						
					return newTuplesAdded;
				};
				
				
				
			void replaceTuples (set <Tuple> replaceTuplesSubmit)
				{
					relationTuples = replaceTuplesSubmit;
				};
				
			
			void clearTuplesSet ()
				{
					set <Tuple> clearedTuples;
					
					relationTuples = clearedTuples;
				};
				
				
			void displayTuples ()
				{	
					//cout << "Entered the Display Tuples function in RELATION.h" << endl << endl;
					//cout << "set size = " << relationTuples.size() << endl;
					
					for (std::set <Tuple>::iterator it = relationTuples.begin(); it != relationTuples.end(); it++)
						{
							
							
							Tuple currentTuple = *it;
							
							//vector <string> currentTupleValues;
							
							//currentTupleValues = currentTuple.getTupleValues ();
							
							string tupleDisplay = "";
							
							for (unsigned int i = 0; i < currentTuple.size(); i++)
								{
									//cout << currentTuple[i] << ", " << endl;
									tupleDisplay += currentTuple[i] + ", ";
								}
								
							cout << tupleDisplay << endl << endl;
						}
				};
				
			
			//This returns the set of string values that are possible for each Variable in the Relation that matches the Query
			string displayTuplesSelect ()
				{
					
					string tupleDisplay = "";
					
					for (std::set <Tuple>::iterator it = relationTuples.begin(); it != relationTuples.end(); it++)
						{
							
							
							Tuple currentTuple = *it;
							
							//vector <string> currentTupleValues;
							
							//currentTupleValues = currentTuple.getTupleValues ();
							
							tupleDisplay += "  ";
							
							for (unsigned int i = 0; i < currentTuple.size(); i++)
								{
									//cout << currentTuple[i] << ", " << endl;
									
									if (i < currentTuple.size() - 1)
										{
											tupleDisplay += columnNames.getColumnName (i) + "=" + currentTuple[i] + " ";
										}
									else
										{
											tupleDisplay += columnNames.getColumnName (i) + "=" + currentTuple[i] + "\n";
										}
								}
							}	
						
						
						return tupleDisplay;
						
						//return "";
				};
				
				
			//This returns the set of string values that are possible for each Variable from the Query
			string displayTuplesProjectRename (map <int, vector<int>> queryTotalVariableIndexContainer, Scheme columnNamesSubmit)
				{
					columnNames = columnNamesSubmit;
					
					
					string tupleDisplay = "";
					
					for (std::set <Tuple>::iterator itTuple = relationTuples.begin(); itTuple != relationTuples.end(); itTuple++)
						{
							Tuple currentTuple = *itTuple;
							
							tupleDisplay += "  ";
						
							for (std::map <int, vector<int>>::iterator itVariable = queryTotalVariableIndexContainer.begin(); itVariable != queryTotalVariableIndexContainer.end(); itVariable++)
								{
									int currentLocationInQuery = itVariable->first;
									
									vector <int> currentIndexes = itVariable->second;
									
									string currentVariable = columnNames[currentLocationInQuery];
									
									tupleDisplay += currentVariable + "=" + currentTuple[currentIndexes[0]] + " ";
								}
								
							tupleDisplay += "\n";
						}
						
					return tupleDisplay;
				};
			
				
				
			int getTupleCount ()
				{
					//stringstream tupleCountStream;
					
					//tupleCountStream << tupleCount;
					
					//string tupleCountString;
					
					//tupleCountStream >> tupleCountString;
					
					return relationTuples.size();
				};
				
				
				
				
				
				
			string displayTuplesProject ()
				{
					string tupleDisplay = "";
					
					for (std::set <Tuple>::iterator it = relationTuples.begin(); it != relationTuples.end(); it++)
						{
							tupleDisplay += "  ";
							
							Tuple currentTuple = *it;
							
							for (unsigned int i = 0; i < currentTuple.size(); i++)
								{
									
									if (i < currentTuple.size () - 1)
										{
											tupleDisplay += columnNames.getColumnName (i) + "=" + currentTuple[i] + " ";
										}
										
									else
										{
											tupleDisplay += columnNames.getColumnName (i) + "=" + currentTuple[i] + "\n";
										}
								}
								
							//tupleDisplay += "\n";
						}
						
					return tupleDisplay;
				};
				
				
				
			//The calling Relation gets converted into a NEW Relation that has the submitted String Value in the correct index location
			Relation selectOnString (int index, string stringValue)
				{
					//cout << endl << endl << endl << "Entered Select ON String function which is in Relation" << endl << endl << endl;
					
					Relation selectStringResult (name, columnNames);
					
					//cout << "index = " << index << "\nstringValue = " << stringValue << "\nset size = " << this->relationTuples.size() << endl;
					
					for (std::set <Tuple>::iterator it = relationTuples.begin(); it != relationTuples.end(); it++)
						{
							//cout << "in for loop...\n";
							Tuple currentTuple = *it;
							
							//cout << "currentTuple Element Value = " << currentTuple[index] << endl;
							//cout << "Submitted stringValue = " << stringValue << endl;
							if (currentTuple [index] == stringValue)
								{
									selectStringResult.insertTuples (currentTuple);
								}
						}
						
						
					return selectStringResult;
				};
				
				
				
			//The calling Relation gets converted into a NEW Relation that has Variable Values in the correct index locations
			Relation selectOnID (vector <int> indexes, string IDValue)
				{
					//cout << endl << endl << endl << "Entered Select on ID function which is in Relation" << endl << endl << endl;
					
					
					Relation selectIDResult (name, columnNames);
					
					for (std::set <Tuple>::iterator it = relationTuples.begin(); it != relationTuples.end(); it++)
						{
							Tuple currentTuple = *it;
							
							bool tupleCheck = true;
							
							//This portion accounts for the same Variable Value (Column Name) occuring in locations within the current Tuple that match
							//the correct locations in the Query from which the index values are obtained
							if (indexes.size () > 1)
								{
									for (unsigned int i = 1; i < indexes.size (); i++)
										{
											if (currentTuple[indexes[i]] == currentTuple[indexes[i-1]])
												{
													tupleCheck = true;
												}
												
											else
												{
													tupleCheck = false;
												}
										}
										
									if (tupleCheck == true)
										{
											selectIDResult.insertTuples (currentTuple);
										}
								}
							
							//If the submitted Variable Value has only one location in the Query, then just add each Tuple	
							else
								{
									selectIDResult.insertTuples (currentTuple);
								}
						}
						
						
						
					return selectIDResult;
				};
				
				
			//This converts the column names of the calling Relation to match the Variable Values in the current Query (for RENAME)
			void convertColumnNames (Predicate currentQuery)
				{
					//cout << "Inside of convertColumnNames function, which is inside of RELATION" << endl << endl << endl;
					//cout << "Renaming the Columns for the Tuples in the Relation" << endl << endl;
					
					vector <Parameter> currentQueryBody = currentQuery.getBodyComponents();
					
					vector <int> idLocations;
					
					for (unsigned int i = 0; i < currentQueryBody.size(); i++)
						{
							if (currentQueryBody[i].getTokenType() == "ID")
								{
									idLocations.push_back (i);
								}
						}
					
					for (unsigned int i = 0; i < idLocations.size(); i++)
						{	
							//if (currentQueryBody[i].getTokenType() != "STRING")
								//{
									//cout << "Changing " << columnNames.getColumnName (i) << " to Value " << currentQueryBody[idLocations[i]].getTokenValue() << endl;
									
									columnNames.setColumnName (i, currentQueryBody[idLocations[i]].getTokenValue());
									
									//cout << "SUCCESSFULLY CHANGED column name.\t colum name at " << i << " is now" << columnNames.getColumnName (i) << endl << endl;
								//}
						}		
				};
				
				
				
				
			//This Projects the Current Relation, returning a NEW Relation with Columns where the submitted Predicate had IDs
			//This is where I left off at 12:24 PM on 3-14-16
			Relation project (Predicate currentPredicate)
				{
					//cout << "Inside Project (Predicate currentPredicate) function, which is inside of RELATION" << endl << endl;
					
					//cout << "Creating Vectors for tracking Variable lcoations" << endl;
					vector <Parameter> currentPredicateBody = currentPredicate.getBodyComponents();
					
					
					vector <int> idLocations;
					
					
					//cout << "Creating vector for capturing the new Scheme" << endl << endl;
					vector <string> resultColumnNames;
					
					
					
					
					//cout << "Iterating through the Rule Predicate Body, capturing ID locations and constructing new Scheme" << endl;
					for (unsigned int i = 0; i < currentPredicateBody.size(); i++)
						{
							if (currentPredicateBody[i].getTokenType() == "ID")
								{
									idLocations.push_back (i);
									
									resultColumnNames.push_back (columnNames[i]);
								}
						}
						
					//cout << "Creating new Scheme and Relation" << endl << endl;
					Scheme resultScheme (resultColumnNames);
					
					Relation resultRelation (name, resultScheme);
						
					//cout << "Created new Scheme and Relation, now Iterating through Tuples to add to new Relation" << endl << endl;
					
					
					//cout << endl << endl << endl << endl << "Current Predicate Body is: " << currentPredicate.toStringBody () << endl << endl << endl;
					
					//cout << "Current Relation Column Names are: " << columnNames.toStringSchemeValues() << endl << endl << endl;
					
					
					for (std::set <Tuple>::iterator tuplesIterator = relationTuples.begin(); tuplesIterator != relationTuples.end(); tuplesIterator++)
						{
							Tuple resultTuple;
						
							Tuple currentTuple = *tuplesIterator;
							
							vector <string> resultTupleString;
							
							
							//cout << "Checking to see if Tuple: " << currentTuple.toStringTupleValues() << "    should be added to the Relation" << endl << endl;
							//if (currentTuple.size () == columnNames.size () && idLocations.size ()== currentPredicateBody.size())
								//{
									for (unsigned int i = 0; i < idLocations.size(); i++)
										{
											//cout << "Attempting to add element " << idLocations[i] << "from the current Tuple to the result Tuple" << endl << endl << endl;
											
											resultTupleString.push_back (currentTuple.at (idLocations[i]));
											
											//resultScheme.push_back (columnNames[idLocations[i]]);
										}
										
									resultTuple.setTupleValues (resultTupleString);
									
									//cout << "Created the new Tuple" << endl << endl;
									
									resultRelation.insertTuples (resultTuple);
								
									//cout << "Just inserted into the Relation" << endl << endl;
								//}
							
								
							
							
							
							
						}
					
					
					//Relation testRelation ("test", resultScheme);
						
					return resultRelation;
				};
				
				
				
				
				
				
				
			Relation projectRuleHeadPredicate (Predicate currentPredicate)
				{
					
					//cout << "Inside projectRuleHeadPredicate function, which is in RELATION class" << endl << endl;
					
					//cout << "Creating Vectors for tracking Variable lcoations" << endl;
					vector <Parameter> currentPredicateBody = currentPredicate.getBodyComponents();
					
					
					vector <int> idLocations;
					
					
					//cout << "Creating vector for capturing the new Scheme" << endl << endl;
					vector <string> resultColumnNames;
					
					
					
					
					//cout << "Iterating through the Rule Predicate Body, capturing ID locations and constructing new Scheme" << endl;
					//for (unsigned int i = 0; i < currentPredicateBody.size(); i++)
						//{
							//if (currentPredicateBody[i].getTokenType() == "ID")
								//{
									//idLocations.push_back (i);
									
									//resultColumnNames.push_back (currentPredicateBody[i].getTokenValue());
								//}
						//}
						
					
					vector <int> ruleColumnNamesMatchLocations;
					
					//cout << "Attempting to Match the Current Rule Head Predicate Body elements with Column Names from the Matching Relation" << endl << endl << endl << endl;
					
					//cout << " Current Rule Head Predicate Body Elements are: " << currentPredicate.toStringBody() << endl << endl;
					//cout << " Current Matching Relation Column Names are: " << columnNames.toStringSchemeValues() << endl << endl;
					
					for (unsigned int j = 0; j < currentPredicateBody.size(); j++)
						{
							for (unsigned int k = 0; k < columnNames.size(); k++)
								{
									
									
									if (currentPredicateBody[j].getTokenValue() == columnNames[k])
										{
											//cout << "Matched the Current Predicate Body element at index " << j << " which is " << currentPredicateBody[j].getTokenValue() << endl << endl;
											//cout << "This Matches with the Matching RELATION Column Name at index" << k << " which is " << columnNames [k] << endl << endl;
											
											ruleColumnNamesMatchLocations.push_back (k);
											resultColumnNames.push_back (columnNames[k]);
										}
								}
						}
						
					//cout << "Creating new Scheme and Relation" << endl << endl;
					//Scheme resultScheme (resultColumnNames);
					
					Relation resultRelation (name, columnNames);//resultScheme);//columnNames);//resultScheme);
						
					//cout << "Created new Scheme and Relation, now Iterating through Tuples to add to new Relation" << endl << endl;
					
					
					for (std::set <Tuple>::iterator tuplesIterator = relationTuples.begin(); tuplesIterator != relationTuples.end(); tuplesIterator++)
						{
						
							Tuple currentTuple = *tuplesIterator;
							
							vector <string> resultTupleString;
							
							
							//cout << endl << endl << endl << "These are the column names of the Tuple being Added for the new relation: " << columnNames.toStringSchemeValues() << endl << endl;
							
							//cout << "Checking to see if Tuple: " << currentTuple.toStringTupleValues() << "    should be added to the Relation" << endl << endl << endl << endl;
							
							for (unsigned int l = 0; l < ruleColumnNamesMatchLocations.size(); l++)
								{
									
									//cout << endl << endl << endl << "Adding the Tuple Element at index " << ruleColumnNamesMatchLocations[l] << " which is: " << currentTuple [ruleColumnNamesMatchLocations [l]] << endl << endl;
									
									resultTupleString.push_back (currentTuple [ruleColumnNamesMatchLocations [l]]);
										
									
									
									
									//resultScheme.push_back (columnNames[idLocations[i]]);
								}
								
							Tuple resultTuple (resultTupleString);
							
							//cout << "Created the new Tuple" << endl << endl;
								
							resultRelation.insertTuples (resultTuple);
							
							//cout << "Just inserted into the Relation" << endl << endl;
							
						}
					
					
					//Relation testRelation ("test", resultScheme);
						
					return resultRelation;
				};
		
			//Old Code Material
			/*
			Relation(string relationNameSubmit, vector<Parameter> tupleNamesSubmit) : relationName(relationNameSubmit), tupleNames(tupleNamesSubmit)
				{
				
				};
			
			Relation()
				{
				
				};
			
			~Relation()
				{
				
				};
			
			
			void insertValues (vector <string> valuesSubmit)
				{
					//if (std::find (std::begin (columnValues), std::end (columnValues), columnValues_Submit) != std::end(columnValues))
						//{
						
						//}
				
					//else
						//{
							tupleValues.insert (valuesSubmit);
						//}
				};
			
			
			string getRelationName ()
				{
					return relationName;
				};
			
			
			
			
			//Display the Tuple Names at the COLUMN HEADS within the Relation Table
			void displayTupleNames ()
				{
					cout << "Displaying Column Names for: " << relationName << endl << endl;
				
					for (unsigned int i = 0; i < tupleNames.size(); i++)
						{
							cout << "element[" << i << "]: " << tupleNames[i].tokenValue << endl;
						}
					
					cout << endl << endl;
				};
			
			
			
			
			
			//Display the Tuple Values within the Relation Table
			void displayTupleValues ()
				{
					vector <string> currentTuple;
				
					for (std::set<vector <string>>::iterator it = tupleValues.begin(); it != tupleValues.end(); it++)
						{
							currentTuple = *it;
						
							for (unsigned int i = 0; i < currentTuple.size(); i++)
								{
									cout << currentTuple[i] << endl;
								}
						}
				};
			
			
			
			
			set <vector <string>> getTupleValues ()
				{
					return tupleValues;
				};
				
			
			
			
			void setTupleNames (int index, string indexName)
				{
					tupleNames[index].setTokenValue (indexName);
				}
				
				
			vector <Parameter> getTupleNames ()
				{
					return tupleNames;
				};
			*/
			
			
	};



#endif /* RELATION_H_ */
