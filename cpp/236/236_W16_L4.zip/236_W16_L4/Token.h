/*
 * Token.h
 *
 *  Created on: May 5, 2015
 *      Author: heypono
 */

#ifndef TOKEN_H_
#define TOKEN_H_

/*
 * Construct the Token Class
 * Enumerate the Token Types
 * Map each Token Type to the respective String
 */

#include <map>
#include <string>
#include <sstream>

using namespace std;

class Token
	{
		private:

		
			/*enum tokenType
				{
					COMMA = ",", PERIOD = ".", Q_MARK = "?", LEFT_PAREN = "(", RIGHT_PAREN = ")", COLON = ":", COLON_DASH = ":-", ADD = "+", MULTIPLY = "*",
					SCHEMES = "Schemes", FACTS = "Facts", RULES = "Rules", QUERIES = "Queries",
					
					
					ID, A letter followed by 0 or more letters or digits and is not a keyword (Schemes, Facts, Rules, Queries)
					
					STRING, Any sequence of characters enclosed in single quotes. Two single quotes denote an apostrophe within the string. For line-number counts, count all \n's within a string. A string token’s line number is the line where the string starts. If EOF is found before the end of the string, it is undefined (see UNDEFINED token below).
					
					COMMENT, A line comment starts with # and ends at the next newline or EOF.
								A block comment starts with a #| and ends with a |#. The comment's line number is the line where the comment started. Like STRING, if EOF is found before the end of the block comment, it is UNDEFINED (see UNDEFINED token below).
					
					WHITESPACE, Any character recognized by the isspace() function defined in ctype.h. Though we give it a token type here, these tokens will be ignored and not saved. Be sure to count the line numbers when skipping over white space.
					
					UNDEFINED, Any character not tokenized as a string, keyword, identifier, symbol, or white space is undefined. Additionally, any non-terminating string or non-terminating block comment is undefined. In both of the latter cases we reach EOF before finding the end of the string or the end of the block comment.
					
					EOF End of input file
				};*/
		
				
			string tokenType;
			string tokenValue;
			int tokenLineNumber;
			



		public:
			
			
			Token (string tokenType_In, string tokenValue_In, int tokenLineNumber_In) : tokenType (tokenType_In), tokenValue (tokenValue_In), tokenLineNumber (tokenLineNumber_In)
				{
				
				};
			
			Token ()
				{};
			
			~Token()
				{
				
				};

			/*map <string, tokenType*> getMap();*/
			
			string toStringToken ()
				{
					string lineNumberString;
					
					stringstream lineNumberConverter;
					lineNumberConverter << tokenLineNumber;
					lineNumberConverter >> lineNumberString;
					
					//Print out the token in this order: ( TOKENTYPE, TOKEN_SYMBOL/VALUE, LINENUMBER )
					return "(" + tokenType + "," + "\"" + tokenValue + "\"" + "," + lineNumberString + ")";
				};
			
			
			
			
			string getTokenType ()
				{
					return tokenType;
				};
			
			
			
			
			string getTokenValue ()
				{
					return tokenValue;
				};
			
			
			
			
	};



#endif /* TOKEN_H_ */
