#ifndef SCHEME_H_
#define SCHEME_H_

#include "Predicate.h"
#include "Parameter.h"

#include <vector>

using namespace std;

class Scheme : public std::vector<string>
{
	private:
	
	public:
		Scheme (vector <string> schemeColumnNamesSubmit)
			{
				
				for (unsigned int i=0; i<schemeColumnNamesSubmit.size(); i++)
					{
						this->push_back (schemeColumnNamesSubmit[i]);
					}
				
			};
			
		Scheme ()
			{
			};
			
		~Scheme ()
			{
			};
			
			
		string toStringSchemeValues ()
			{
				string schemeDisplay = "";
				
				for (unsigned int i=0; i<this->size(); i++)
					{
						schemeDisplay = schemeDisplay + this->at(i) + ", ";
					}
					
				return schemeDisplay;
			};
			
			
		void setColumnName (int index, string indexName)
			{
				this->at (index) = indexName;
			};
			
			
		string getColumnName (int index)
			{
				return this->at (index);
			};
			
			
		bool contains (string columnName)
			{
				bool columnNamePresent = false;
				
				for (unsigned int i = 0; i < this->size(); i++)
					{
						if (this->at (i) == columnName)
							{
								columnNamePresent = true;
							}
					}
					
				return columnNamePresent;
			}
	
};

#endif /* SCHEME_H_ */
