#ifndef TUPLE_H_
#define TUPLE_H_

#include "Predicate.h"
#include "Parameter.h"
#include <vector>

using namespace std;

class Tuple:public std::vector<string>
	{
		private:
			//vector <string> tupleValues;
			
		public:
			Tuple (vector <string> tupleValuesSubmit)
				{
					for (unsigned int i=0; i < tupleValuesSubmit.size(); i++)
						{
							this->push_back (tupleValuesSubmit[i]);
						}
					
					//tupleValues = tupleValuesSubmit;
				};
				
			Tuple ()
				{
				};
				
			~Tuple ()
				{
				};
				
				
			/*	
			vector <string> getTupleValues ()
				{
					return tupleValues;
				};
			*/	
				
			void setTupleValues (vector <string> tupleValuesSubmit)
				{
					for (unsigned int i=0; i < tupleValuesSubmit.size(); i++)
						{
							this->push_back (tupleValuesSubmit[i]);
						}
				};
			
			
			
			string toStringTupleValues ()
				{
					
					string tupleDisplay = "";
					
					for (unsigned int i=0; i < this->size(); i++)
						{
							tupleDisplay = tupleDisplay + this->at(i) + ", "; 
						}
						
					return tupleDisplay;
					
				};
				
				
				
			bool contains (string tupleValue)
				{
					bool valuePresent = false;
					
					for (unsigned int i = 0; i < this->size(); i++)
						{
							if (this->at(i) == tupleValue)
								{
									valuePresent = true;
								}
						}
						
					return valuePresent;
				};
				
			
			
			string getTupleValue (int index)
				{
					return this->at (index);
				};
	};

#endif /* TUPLE_H_ */
