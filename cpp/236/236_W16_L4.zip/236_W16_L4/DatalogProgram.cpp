/*
 * datalogProgram.cpp
 *
 *  Created on: Sep 30, 2015
 *      Author: heypono
 */

#include "DatalogProgram.h"

void DatalogProgram::parseTokens (vector<Token> tokenContainer)
	{
		//cout << "Entered Token Parser" << endl << endl;
		
		const string stages[] = {"SCHEMES", "FACTS", "RULES", "QUERIES"};
		
		try
			{
				//while (index < tokenContainer.size())
					//{
						//cout << "Current Token: " << tokenContainer[index].toStringToken() << endl << endl;
						//index++
						
						//First: parse the SCHEME information
						matchToken (stages[0]);
							
						
							//match the second TOKEN in order to begin the SCHEME parsing
							matchToken ("COLON");
							
							
							//Call parsing function for SCHEME
							schemeParse();
							
							
							//Recursively look for more SCHEME predicates
							schemeListParse();
							
							
						
						//Second: parse the FACTS information
						matchToken (stages[1]);
						
							
							//match the second TOKEN in order to begin the FACTS parsing
							matchToken ("COLON");
							
							
							//Call parsing function for FACT
							//factParse();
							
							
							//Recursively look for more FACT predicates
							factListParse();
							
						
						//Third: parse the RULES information
						matchToken (stages[2]);
						
						
							//match the second TOKEN in order to begin the RULES parsing
							matchToken ("COLON");
							
							
							//Call parsing function for RULE
							//ruleParse();
							
							//Recursively look for more RULE predicates
							ruleListParse();
						
						//Fourth: parse the QUERIES information
						matchToken (stages[3]);
						
						
							//match the second TOKEN needed to begin the QUERIES parsing
							matchToken ("COLON");
							
							
							//Call parsing function for QUERY
							queryParse();
							
							
							//Recursively look for more QUERY predicates
							queryListParse();
							
							
						//Last: sort Domain (FACT Strings) and force elements to be unique, and display Domain AND Parse results
						matchToken ("EOF");
						
						fileEnd(outputFile);
					//}
				}
				
			catch (Token errorThrownToken)
				{
					ofstream outputFileStream;
				
					outputFileStream.open (outputFile);
				
					outputFileStream << "Failure!" << endl;
				
					outputFileStream << "  " << tokenContainer[index].toStringToken() << endl;
				}
		
		

	}








//Attempt to match the submitted TOKEN Type 
bool DatalogProgram::matchToken (string tokenType)
	{
		/*
		try
			{
				if (tokenType == tokenContainer[index].getTokenType())
					{	
						index++;
						
						return true;
					}
			}
		
		catch (string tokenType)
			{
				cout << "Fail!" << endl;
				
				cout << tokenType << " did NOT match " << tokenContainer[index].getTokenType() << endl;
				
				return false;
			}
		*/
		
		
		//If the submitted TOKEN Type matches the current TOKEN Type in the Container, the increment the location in order to continue parsing
		if (tokenType == tokenContainer[index].getTokenType())
			{
				index++;
				
				return true;	
			}
		
		//Throw an error
		else
			{
				//cout << "Failing at TOKEN: " << tokenContainer[index].getTokenValue() << endl << endl;
			
				//index = tokenContainer.size() + 1;
				//return false;
				
				
				/* For Winter Semester 2016, We had to use a Try-Catch block because the following method for generating an error message would not pass valgrind
				ofstream outputFileStream;
				
				outputFileStream.open (outputFile);
				
				outputFileStream << "Failure!" << endl;
				
				outputFileStream << "  " << tokenContainer[index].toStringToken() << endl;
				
				exit(0);
				*/
				
				throw (tokenContainer[index]);
				
				return false;
			}
		
	}








//Attempt to match the submitted TOKEN Type 
bool DatalogProgram::matchTokenParameter (string tokenType)
	{
		/*
		try
			{
				if (tokenType == tokenContainer[index].getTokenType())
					{	
						index++;
						
						return true;
					}
			}
		
		catch (string tokenType)
			{
				cout << "Fail!" << endl;
				
				cout << tokenType << " did NOT match " << tokenContainer[index].getTokenType() << endl;
				
				return false;
			}
		*/
		
		
		//If the submitted TOKEN Type matches the current TOKEN Type in the Container, the increment the location in order to continue parsing
		if (tokenType == "STRING" || tokenType == "ID")
			{
				//cout << "Current Token Encountered: " << tokenContainer[index].getTokenValue() << ", which is of type: " << tokenContainer[index].getTokenType() << endl << endl;
				
				//cout << "Current Token Type: " << tokenContainer[index].getTokenType() << endl << endl;
				
				//cout << "Current Token Value: " << tokenContainer[index].getTokenValue() << endl << endl;
				
				string tokenValue;
				
				tokenValue = tokenContainer[index].getTokenValue();
				
					map<string, string>::iterator mapIterator = keyWordMap.find(tokenValue);
			
					//If the Submitted Value matches a Key Word (Schemes, Facts, Rules, Queries) then throw an error, otherwise, increment the index
					if (mapIterator != keyWordMap.end())
						{
							throw (tokenContainer [index]);
							
							return false;
						}
						
					else
						{
							index++;
							
							return true;
						}
			
				
			}
		
		//Throw an error
		else
			{
				//cout << "Failing at TOKEN: " << tokenContainer[index].getTokenValue() << endl << endl;
			
				//index = tokenContainer.size() + 1;
				//return false;
				
				
				/* For Winter Semester 2016, We had to use a Try-Catch block because the following method for generating an error message would not pass valgrind
				ofstream outputFileStream;
				
				outputFileStream.open (outputFile);
				
				outputFileStream << "Failure!" << endl;
				
				outputFileStream << "  " << tokenContainer[index].toStringToken() << endl;
				
				exit(0);
				*/
				
				throw (tokenContainer[index]);
				
				return false;
			}
		
	}
















//Parse the SCHEME info
void DatalogProgram::schemeParse()
	{
		currentSchemeConstruct.predicateName = "";
		
		currentSchemeConstruct.bodyComponents.clear();
	
	
		
		
		matchToken("ID");
		
		currentSchemeConstruct.predicateName = tokenContainer[index-1].getTokenValue();
		
		
		
		matchToken("LEFT_PAREN");
		
		currentSchemeToken.tokenType = tokenContainer[index-1].getTokenType();
		
		currentSchemeToken.tokenValue = tokenContainer[index-1].getTokenValue();
		
		//currentSchemeConstruct.bodyComponents.push_back (currentSchemeToken);
		
		
		
		//Match either String or ID token type
		matchTokenParameter (tokenContainer[index].getTokenType());
				
		currentSchemeToken.tokenType = tokenContainer[index-1].getTokenType();
				
		currentSchemeToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
		currentSchemeConstruct.bodyComponents.push_back (currentSchemeToken);
		
		
		
		tokenTypeCheck (currentSchemeToken.getTokenType(), currentSchemeToken.getTokenValue());
		
		
		idListSchemeParse();
		
		
		
		matchToken ("RIGHT_PAREN");
		
		currentSchemeToken.tokenType = tokenContainer[index-1].getTokenType();
				
		currentSchemeToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
		//currentSchemeConstruct.bodyComponents.push_back (currentSchemeToken);
		
		
		
		
		
		
		schemePredicateContainer.push_back (currentSchemeConstruct);
		
		//cout << "Checking to see What's being input into Scheme Predicate Holder: " << currentSchemeConstruct.toStringBody() << endl << endl;
		
		schemeCount++;
		
	}





//Continue parsing any remaining SCHEME info
void DatalogProgram::schemeListParse()
	{
		if (tokenContainer[index].getTokenType() == "ID")
			{
				schemeParse();
				
				schemeListParse();
			}
		
		else
			{
				return;
			}
	}





//Continue adding IDs the the current SCHEME Predicate being constructed
void DatalogProgram::idListSchemeParse()
	{
		if (tokenContainer[index].getTokenType() == "COMMA")
			{				
			
				matchToken ("COMMA");
				
				currentSchemeToken.tokenType = tokenContainer[index-1].getTokenType();
				
				currentSchemeToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
				//currentSchemeConstruct.bodyComponents.push_back(currentSchemeToken);
				
				
				//Match either String or ID Token Type
				matchTokenParameter (tokenContainer[index].getTokenType());
				
				currentSchemeToken.tokenType = tokenContainer[index-1].getTokenType();
								
				currentSchemeToken.tokenValue = tokenContainer[index-1].getTokenValue();
								
				currentSchemeConstruct.bodyComponents.push_back(currentSchemeToken);
				
				
				
				tokenTypeCheck (currentSchemeToken.getTokenType(), currentSchemeToken.getTokenValue());
				
				
				
				idListSchemeParse();
			}
		
		else 
			{
				return;
			}
	}



















//Parse the FACT info
void DatalogProgram::factParse()
	{
		currentFactConstruct.predicateName = "";
		
		currentFactConstruct.bodyComponents.clear();
		
		
	
		if (matchToken ("ID"))
			{
				currentFactConstruct.predicateName = tokenContainer[index-1].getTokenValue();
			}
		
		else
			{
				//cout << "Returning to the calling function--found no FACTS information" << endl;
			
				return;
			}
		
		
		
		matchToken ("LEFT_PAREN");
		
		currentFactToken.tokenType = tokenContainer[index-1].getTokenType();
		
		currentFactToken.tokenValue = tokenContainer[index-1].getTokenValue();
		
		//currentFactConstruct.bodyComponents.push_back(currentFactToken);
		
		
		//Match either String or ID Token Type
		matchTokenParameter (tokenContainer[index].getTokenType());
		
		currentFactToken.tokenType = tokenContainer[index-1].getTokenType();
				
		currentFactToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
		currentFactConstruct.bodyComponents.push_back(currentFactToken);
		
		
		
		
		tokenTypeCheck (currentFactToken.getTokenType(), currentFactToken.getTokenValue());
		
		
		
		
		stringListParse();
		
		
			
		
		matchToken ("RIGHT_PAREN");
		
		currentFactToken.tokenType = tokenContainer[index-1].getTokenType();
				
		currentFactToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
		//currentFactConstruct.bodyComponents.push_back(currentFactToken);
		
		
			
		matchToken ("PERIOD");
		
		currentFactToken.tokenType = tokenContainer[index-1].getTokenType();
				
		currentFactToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
		//currentFactConstruct.bodyComponents.push_back(currentFactToken);
		
		
		
		
		
		
		factPredicateContainer.push_back (currentFactConstruct);
		
		factCount++;
	}




//Continue parsing any remaining FACT info
void DatalogProgram::factListParse()
	{
		if (tokenContainer[index].getTokenType() == "ID")
			{
				factParse();
				
				factListParse();
			}
		
		else
			{
				return;
			}
	}







//Continue adding STRINGs to the current Predicate being constructed
void DatalogProgram::stringListParse()
	{
		if (tokenContainer[index].getTokenType() == "COMMA")
			{
				matchToken ("COMMA");
				
				currentFactToken.tokenType = tokenContainer[index-1].getTokenType();
						
				currentFactToken.tokenValue = tokenContainer[index-1].getTokenValue();
						
				//currentFactConstruct.bodyComponents.push_back(currentFactToken);
				
				
				//Match either String or ID Token Type
				matchTokenParameter (tokenContainer[index].getTokenType());
				
				currentFactToken.tokenType = tokenContainer[index-1].getTokenType();
						
				currentFactToken.tokenValue = tokenContainer[index-1].getTokenValue();
						
				currentFactConstruct.bodyComponents.push_back(currentFactToken);
				
				
				
				tokenTypeCheck (currentFactToken.getTokenType(), currentFactToken.getTokenValue());
				/*
				//If the current String is NOT already in the Domain, insert it, otherwise, move on
				//list<string>::iterator it = factDomain.find(currentFactToken.tokenValue);
				
				if (std::find(std::begin(factDomain), std::end(factDomain), currentFactToken.tokenValue) != std::end(factDomain))
					{

						//The String was found already in the Domain, so move on
					}
				else
					{
						//The String was NOT already in the Domain, so insert it
						if (currentFactToken.tokenType == "STRING")
						{
							factDomain.insert(currentFactToken.tokenValue);
						}
					}
				*/
			
				
				stringListParse();
			}
		
		else
			{
				return;
			}
	}



















//Parse the RULE info
void DatalogProgram::ruleParse()
	{
		headPredicateParse();
		
		currentRuleConstructTest.bodyComponents.clear();
		
		
		
		matchToken ("COLON_DASH");
		
		currentHeadPredicateToken.tokenType = tokenContainer[index-1].getTokenType();
				
		currentHeadPredicateToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
		currentHeadPredicateConstruct.bodyComponents.push_back (currentHeadPredicateToken);
		
		rulePredicateContainer.push_back (currentHeadPredicateConstruct);
		
		//currentRuleConstructTest.headPredicate.bodyComponents.push_back (currentHeadPredicateToken);
		
		//cout << "Head Predicate: " << currentRuleConstructTest.headPredicate.predicateName << endl;
		//cout << "Body Componnents: " << currentRuleConstructTest.headPredicate.toStringBody() << endl;
		
		
		rulePredicateParse();
		
		rulePredicateListParse();
		
		//cout << "Returned from the RULE Predicate LIST Parse function" << endl << endl;
		
		
		//matchToken ("RIGHT_PAREN");
											
		//currentRuleToken.tokenType = tokenContainer[index-1].getTokenType();
																
		//currentRuleToken.tokenValue = tokenContainer[index-1].getTokenValue();
																
		//currentRuleConstruct.bodyComponents.push_back(currentRuleToken);
		
		
		//cout << "Hit the LAST Right Parenth for Current RULE" << endl << endl;
		
		matchToken ("PERIOD");
									
		currentRuleToken.tokenType = tokenContainer[index-1].getTokenType();
														
		currentRuleToken.tokenValue = tokenContainer[index-1].getTokenValue();
														
		//currentRuleConstruct.bodyComponents.push_back(currentRuleToken);
		
		//currentRulePredicateConstructTest.bodyComponents.push_back (currentRuleToken);
		
		//currentRuleConstructTest.bodyComponents.push_back (currentRulePredicateConstructTest);
		
		
		
		rulePredicateContainerTest.push_back (currentRuleConstructTest);
		
		ruleCount++;
		
		
		return;
				
	}




//Continue parsing any remaining RULE info
void DatalogProgram::ruleListParse()
	{
		if (tokenContainer[index].getTokenType() == "ID")
			{
				//cout << "entered the Rule LIST parse function" << endl;
			
				ruleParse();
				
				ruleListParse();
			}
		
		else
			{
				return;
			}
	}



//Parse the Head Predicate for RULE
void DatalogProgram::headPredicateParse()
	{
		//Parameter currentHeadPredicateToken;
		//Predicate currentHeadPredicateConstruct;
		currentRuleConstructTest.headPredicate.predicateName = "";
		
		currentRuleConstructTest.headPredicate.bodyComponents.clear();
	
		
		if (matchToken ("ID"))
			{
				currentHeadPredicateConstruct.predicateName = tokenContainer[index-1].getTokenValue();
				
				currentRuleConstructTest.headPredicate.predicateName = tokenContainer[index-1].getTokenValue();
			}
		
		else
			{
				//cout << "Returning to calling function--found no RULES information" << endl;
			
				return;
			}
		
		
		
		
		
		matchToken ("LEFT_PAREN");
		
		currentHeadPredicateToken.tokenType = tokenContainer[index-1].getTokenType();
		
		currentHeadPredicateToken.tokenValue = tokenContainer[index-1].getTokenValue();
		
		currentHeadPredicateConstruct.bodyComponents.push_back (currentHeadPredicateToken);
		
		//currentRuleConstructTest.headPredicate.bodyComponents.push_back (currentHeadPredicateToken);
		
		
		
				
		//Match either String or ID Token Type
		matchTokenParameter (tokenContainer[index].getTokenType());
		
		currentHeadPredicateToken.tokenType = tokenContainer[index-1].getTokenType();
		
		currentHeadPredicateToken.tokenValue = tokenContainer[index-1].getTokenValue();
		
		currentHeadPredicateConstruct.bodyComponents.push_back (currentHeadPredicateToken);
		
		currentRuleConstructTest.headPredicate.bodyComponents.push_back (currentHeadPredicateToken);
		
		
		
		
		tokenTypeCheck (currentHeadPredicateToken.getTokenType(), currentHeadPredicateToken.getTokenValue());
		
		
		
		
		idListHeadPredicateParse();
		
		
		
		
		matchToken ("RIGHT_PAREN");
		
		currentHeadPredicateToken.tokenType = tokenContainer[index-1].getTokenType();
				
		currentHeadPredicateToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
		currentHeadPredicateConstruct.bodyComponents.push_back (currentHeadPredicateToken);
		
		//currentRuleConstructTest.headPredicate.bodyComponents.push_back (currentHeadPredicateToken);
		
		
		
		return;
	}







//Continue adding IDs the the current SCHEME Predicate being constructed
void DatalogProgram::idListHeadPredicateParse()
	{
		if (tokenContainer[index].getTokenType() == "COMMA")
			{				
			
				matchToken ("COMMA");
				
				currentHeadPredicateToken.tokenType = tokenContainer[index-1].getTokenType();
				
				currentHeadPredicateToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
				currentHeadPredicateConstruct.bodyComponents.push_back(currentHeadPredicateToken);
				
				//currentRuleConstructTest.headPredicate.bodyComponents.push_back (currentHeadPredicateToken);
				
				
				
				//Match either String or ID Token Type
				matchTokenParameter (tokenContainer[index].getTokenType());
				
				currentHeadPredicateToken.tokenType = tokenContainer[index-1].getTokenType();
								
				currentHeadPredicateToken.tokenValue = tokenContainer[index-1].getTokenValue();
								
				currentHeadPredicateConstruct.bodyComponents.push_back(currentHeadPredicateToken);
				
				currentRuleConstructTest.headPredicate.bodyComponents.push_back (currentHeadPredicateToken);
				
				
				
				
				tokenTypeCheck (currentHeadPredicateToken.getTokenType(), currentHeadPredicateToken.getTokenValue());
				
				
				
				
				idListHeadPredicateParse();
			}
		
		else 
			{
				return;
			}
	}




//Parse the Predicate for RULE
void DatalogProgram::rulePredicateParse()
	{
		//currentRuleConstructTest.bodyComponents.clear();
		currentRulePredicateConstructTest.predicateName = "";
		
		currentRulePredicateConstructTest.bodyComponents.clear();
	
	
	
		matchToken ("ID");
		
		currentRuleToken.tokenType = tokenContainer[index-1].getTokenType();
				
		currentRuleToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
		currentRuleConstruct.bodyComponents.push_back(currentRuleToken);
		
		currentRulePredicateConstructTest.predicateName = currentRuleToken.tokenValue;
		
		
		
		
		
		matchToken ("LEFT_PAREN");
		
		currentRuleToken.tokenType = tokenContainer[index-1].getTokenType();
				
		currentRuleToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
		currentRuleConstruct.bodyComponents.push_back(currentRuleToken);
		
		//currentRulePredicateConstructTest.bodyComponents.push_back (currentRuleToken);
		
		
		
		ruleParameterParse();
		
		ruleParameterListParse();
		
		
		
		matchToken ("RIGHT_PAREN");
		
		currentRuleToken.tokenType = tokenContainer[index-1].getTokenType();
						
		currentRuleToken.tokenValue = tokenContainer[index-1].getTokenValue();
						
		currentRuleConstruct.bodyComponents.push_back(currentRuleToken);
		
		//currentRulePredicateConstructTest.bodyComponents.push_back (currentRuleToken);
		
		currentRuleConstructTest.bodyComponents.push_back (currentRulePredicateConstructTest);
		
		
		
		
		/*cout << "Current Rule Construct: " << endl << endl;
		
		for (int i=0; i<currentRuleConstruct.bodyComponents.size(); i++)
			{
				cout << currentRuleConstruct.bodyComponents[i].tokenValue << endl;
			}*/	
			
		return;	
	}



//Continue adding any remaining Predicates into the RULE
void DatalogProgram::rulePredicateListParse()
	{
		//cout << "Entered the RULE Predicate LIST function" << endl << endl;
	
		if (tokenContainer[index].getTokenType() == "COMMA")
		{	
				matchToken ("COMMA");
				
				currentRuleToken.tokenType = tokenContainer[index-1].getTokenType();
								
				currentRuleToken.tokenValue = tokenContainer[index-1].getTokenValue();
								
				currentRuleConstruct.bodyComponents.push_back(currentRuleToken);
			
				//currentRulePredicateConstructTest.bodyComponents.push_back (currentRuleToken);
				
				
				
				rulePredicateParse();
				
				//cout << "Called the RULE Predicate Parse fucntion" << endl << endl;
				
				rulePredicateListParse();
				
				//cout << "Called the RULE Predicate LIST Parse fucntion" << endl << endl;
			}
		
		else
			{
				//cout << "Returning from the RULE Predicate LIST Parse function" << endl << endl;
			
				return;
			}
	}





//Parse the Parameter for CURRENT Predicate in RULE
void DatalogProgram::ruleParameterParse()
	{
		
		if (tokenContainer[index].getTokenType() == "ID")
			{
				matchTokenParameter ("ID");
				
				currentRuleToken.tokenType = tokenContainer[index-1].getTokenType();
						
				currentRuleToken.tokenValue = tokenContainer[index-1].getTokenValue();
						
				currentRuleConstruct.bodyComponents.push_back(currentRuleToken);
				
				currentRulePredicateConstructTest.bodyComponents.push_back (currentRuleToken);
			}
		
		
		else if (tokenContainer[index].getTokenType() == "STRING")
			{
				matchTokenParameter ("STRING");
							
				currentRuleToken.tokenType = tokenContainer[index-1].getTokenType();
									
				currentRuleToken.tokenValue = tokenContainer[index-1].getTokenValue();
									
				currentRuleConstruct.bodyComponents.push_back(currentRuleToken);
				
				currentRulePredicateConstructTest.bodyComponents.push_back (currentRuleToken);
				
				
				
				
				tokenTypeCheck (currentRuleToken.getTokenType(), currentRuleToken.getTokenValue());
			}
		
		else if (tokenContainer[index].getTokenType() == "COMMA")
			{
				ruleParameterListParse();
			}
		
		else if (tokenContainer[index].getTokenType() == "LEFT_PAREN")
			{
				currentRuleToken.tokenType = "EXPRESSION";
						
				currentRuleToken.tokenValue = "";
				
				ruleLeftParenCount = 0;
				ruleRightParenCount = 0;
				
				//cout << "Calling the RULE Expression Function" << endl << endl;
			
				ruleExpressionParse();
				
				currentRuleConstruct.bodyComponents.push_back (currentRuleToken);
				
				currentRulePredicateConstructTest.bodyComponents.push_back (currentRuleToken);
			}
		
		else
			{
				return;
			}
	}



//Continue adding any remaining Parameters into CURRENT Predicate in RULE
void DatalogProgram::ruleParameterListParse()
	{
		//cout << "Entered the Rule Parameter LIST Parse function" << endl << endl;
	
		if (tokenContainer[index].getTokenType() == "COMMA")
			{
				matchToken ("COMMA");
			
				currentRuleToken.tokenType = tokenContainer[index-1].getTokenType();
												
				currentRuleToken.tokenValue = tokenContainer[index-1].getTokenValue();
												
				//currentRuleConstruct.bodyComponents.push_back(currentRuleToken);
				
				//currentRulePredicateConstructTest.bodyComponents.push_back (currentRuleToken);
				
				ruleParameterParse();
				
				ruleParameterListParse();
			}
		
		else
			{
				return;
			}
	}






//Parse the Expression in CURRENT Predicate in RULE
void DatalogProgram::ruleExpressionParse()
	{
		//cout << "Entered the RULE Expression Parse function" << endl << endl;
								
		//currentRuleConstruct.bodyComponents.push_back(currentRuleToken);
		
		if (tokenContainer[index].getTokenType() == "LEFT_PAREN")
			{
				matchToken ("LEFT_PAREN");
				
				currentRuleToken.tokenValue = currentRuleToken.tokenValue + tokenContainer[index-1].getTokenValue();
				
				ruleLeftParenCount++;
			
				ruleExpressionParse();
			}
		
		
		else if (tokenContainer[index].getTokenType() == "ID")
			{
				matchToken ("ID");
				
				currentRuleToken.tokenValue += tokenContainer[index-1].getTokenValue();
				
				ruleExpressionParse();
						
			}
		
		else if (tokenContainer[index].getTokenType() == "STRING")
			{
				matchToken ("STRING");
				
				currentRuleToken.tokenValue += tokenContainer[index-1].getTokenValue();
				
				ruleExpressionParse();
			}
		
		else if (tokenContainer[index].getTokenType() == "ADD")
			{
				matchToken ("ADD");
							
				currentRuleToken.tokenValue += tokenContainer[index-1].getTokenValue();
				
				ruleExpressionParse();
			}
		
		else if (tokenContainer[index].getTokenType() == "MULTIPLY")
			{
				matchToken ("MULTIPLY");
							
				currentRuleToken.tokenValue += tokenContainer[index-1].getTokenValue();
				
				ruleExpressionParse();
			}
			
		
		else if (tokenContainer[index].getTokenType() == "RIGHT_PAREN")
			{
				matchToken ("RIGHT_PAREN");
																				
				currentRuleToken.tokenValue += tokenContainer[index-1].getTokenValue();
							
				ruleRightParenCount++;
				
				
				//cout << "Right Paren Count in CURRENT RULE: " << ruleRightParenCount << endl << endl;
				
				//cout << "Left Paren Count in CURRENT RULE: " << ruleLeftParenCount << endl << endl;
			
				if (ruleRightParenCount == ruleLeftParenCount)
					{
						return;
					}
				
				else
					{
						ruleExpressionParse();
					}
			}
		
		
		else
			{
				return;
			}
	}


















//Parse the QUERY info
void DatalogProgram::queryParse()
	{
		queryPredicateParse();
		
		
		
		queryCount++;
	}




//Continue parsing any remaining QUERY info
void DatalogProgram::queryListParse()
	{
		if (tokenContainer[index].getTokenType() == "ID")
			{
				queryParse();
				
				queryListParse();
			}
		
		else
			{
				return;
			}
	}




//Parse the Predicate in QUERY
void DatalogProgram::queryPredicateParse()
	{
		matchToken ("ID");
		
		currentQueryConstruct.predicateName = tokenContainer[index-1].getTokenValue();
		
		currentQueryConstruct.bodyComponents.clear();
		
		
				
		
		matchToken ("LEFT_PAREN");
		
		currentQueryToken.tokenType = tokenContainer[index-1].getTokenType();
		
		currentQueryToken.tokenValue = tokenContainer[index-1].getTokenValue();
		
		//currentQueryConstruct.bodyComponents.push_back (currentQueryToken);
		
		
		
		queryParameterParse();
		
		queryParameterListParse();
		
		
		
		matchToken ("RIGHT_PAREN");
		
		currentQueryToken.tokenType = tokenContainer[index-1].getTokenType();
				
		currentQueryToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
		//currentQueryConstruct.bodyComponents.push_back (currentQueryToken);
				
				
		
		
		matchToken ("Q_MARK");
		
		currentQueryToken.tokenType = tokenContainer[index-1].getTokenType();
		
		currentQueryToken.tokenValue = tokenContainer[index-1].getTokenValue();
		
		//currentQueryConstruct.bodyComponents.push_back (currentQueryToken);
		
		
		
		queryPredicateContainer.push_back (currentQueryConstruct);
	}




//Parse the Parameter for CURRENT Predicate in QUERY
void DatalogProgram::queryParameterParse()
	{
		matchTokenParameter (tokenContainer[index].getTokenType());
		
		currentQueryToken.tokenType = tokenContainer[index-1].getTokenType();
						
		currentQueryToken.tokenValue = tokenContainer[index-1].getTokenValue();
				
		currentQueryConstruct.bodyComponents.push_back(currentQueryToken);
		
		
		
		
		tokenTypeCheck (currentQueryToken.getTokenType(), currentQueryToken.getTokenValue());
		/*
		if (tokenContainer[index].getTokenType() == "ID")
			{
				matchToken ("ID");
				
				currentQueryToken.tokenType = tokenContainer[index-1].getTokenType();
						
				currentQueryToken.tokenValue = tokenContainer[index-1].getTokenValue();
						
				currentQueryConstruct.bodyComponents.push_back(currentQueryToken);
			}
		
		
		else if (tokenContainer[index].getTokenType() == "STRING")
			{
				matchToken ("STRING");
							
				currentQueryToken.tokenType = tokenContainer[index-1].getTokenType();
									
				currentQueryToken.tokenValue = tokenContainer[index-1].getTokenValue();
									
				currentQueryConstruct.bodyComponents.push_back(currentQueryToken);
				
				
				
				
				tokenTypeCheck (currentQueryToken.getTokenType(), currentQueryToken.getTokenValue());
			}
		
		
		else if (tokenContainer[index].getTokenType() == "COMMA")
			{
				queryParameterListParse();
			}
		
		
		else if (tokenContainer[index].getTokenType() == "LEFT_PAREN")
			{
				currentQueryToken.tokenType = "EXPRESSION";
						
				currentQueryToken.tokenValue = "";
				
				queryLeftParenCount = 0;
				queryRightParenCount = 0;
				
				//cout << "Calling the QUERY Expression Function" << endl << endl;
			
				queryExpressionParse();
				
				currentQueryConstruct.bodyComponents.push_back (currentQueryToken);
			}
		
		
		else
			{
				return;
			}
		*/
	}




//Continue adding any remaining Parameters into CURRENT Predicate in QUERY
void DatalogProgram::queryParameterListParse()
	{
		//cout << "Entered the Query Parameter LIST Parse function" << endl << endl;
		
		if (tokenContainer[index].getTokenType() == "COMMA")
			{
				matchToken ("COMMA");
			
				currentQueryToken.tokenType = tokenContainer[index-1].getTokenType();
												
				currentQueryToken.tokenValue = tokenContainer[index-1].getTokenValue();
												
				//currentQueryConstruct.bodyComponents.push_back(currentQueryToken);
				
				queryParameterParse();
				
				queryParameterListParse();
			}
		
		else
			{
				return;
			}
	}




//Parse the Expression for CURRENT Predicate in QUERY
void DatalogProgram::queryExpressionParse()
	{
		//cout << "Entered the QUERY Expression Parse function" << endl << endl;
									
		//currentRuleConstruct.bodyComponents.push_back(currentRuleToken);
		
		if (tokenContainer[index].getTokenType() == "LEFT_PAREN")
			{
				matchToken ("LEFT_PAREN");
				
				currentQueryToken.tokenValue = currentQueryToken.tokenValue + tokenContainer[index-1].getTokenValue();
				
				queryLeftParenCount++;
			
				queryExpressionParse();
			}
		
		
		else if (tokenContainer[index].getTokenType() == "ID")
			{
				matchToken ("ID");
				
				currentQueryToken.tokenValue += tokenContainer[index-1].getTokenValue();
				
				queryExpressionParse();
						
			}
		
		else if (tokenContainer[index].getTokenType() == "STRING")
			{
				matchToken ("STRING");
				
				currentQueryToken.tokenValue += tokenContainer[index-1].getTokenValue();
				
				queryExpressionParse();
			}
		
		else if (tokenContainer[index].getTokenType() == "ADD")
			{
				matchToken ("ADD");
							
				currentQueryToken.tokenValue += tokenContainer[index-1].getTokenValue();
				
				queryExpressionParse();
			}
		
		else if (tokenContainer[index].getTokenType() == "MULTIPLY")
			{
				matchToken ("MULTIPLY");
							
				currentQueryToken.tokenValue += tokenContainer[index-1].getTokenValue();
				
				queryExpressionParse();
			}
			
		
		else if (tokenContainer[index].getTokenType() == "RIGHT_PAREN")
			{
				matchToken ("RIGHT_PAREN");
				
				currentQueryToken.tokenValue += tokenContainer[index-1].getTokenValue();
				
				queryRightParenCount++;
				
				//cout << "Right Paren Count in CURRENT QUERY: " << queryRightParenCount << endl << endl;
								
				//cout << "Left Paren Count in CURRENT QUERY: " << queryLeftParenCount << endl << endl;
				
				if (queryRightParenCount == queryLeftParenCount)
					{
						return;
					}
				
				else
					{
						queryExpressionParse();
					}
			}
		
		
		else
			{
				return;
			}
	}









void DatalogProgram::fileEnd(char* outputFileName)
	{
		//cout << "Entering fileEnd Function" << endl << endl;
		//cout << "Success!" << endl;
		ofstream outputFileStream;
		
		outputFileStream.open (outputFileName);
		
		outputFileStream << "Success!" << endl;
		
		//Output the SCHEMES information
		outputFileStream << "Schemes(" << schemeCount << "):" << endl;
		
		for (unsigned int i = 0; i < schemePredicateContainer.size(); i++)
			{
				outputFileStream << "  " << schemePredicateContainer[i].predicateName << schemePredicateContainer[i].toStringBody() << endl;
			}
		
		
		
		//Output the FACTS information
		outputFileStream << "Facts(" << factCount << "):" << endl;
		
		for (unsigned int i = 0; i < factPredicateContainer.size(); i++)
			{
				outputFileStream << "  " << factPredicateContainer[i].predicateName << factPredicateContainer[i].toStringBody() << endl;
			}
		
		
		
		//Output the RULES information
		outputFileStream << "Rules(" << ruleCount << "):" << endl;
		
		for (unsigned int i = 0; i < rulePredicateContainerTest.size(); i++)
			{
				outputFileStream << "  " << rulePredicateContainerTest[i].headPredicate.predicateName << rulePredicateContainerTest[i].headPredicate.toStringBody() << " :- " << rulePredicateContainerTest[i].toStringBody() << endl;
			}
		
		
		
		//Output the QUERIES information
		outputFileStream << "Queries(" << queryCount << "):" << endl;
		
		for (unsigned int i = 0; i < queryPredicateContainer.size(); i++)
			{
				outputFileStream << "  " << queryPredicateContainer[i].predicateName << queryPredicateContainer[i].toStringBody() << endl;
			}
	
		
		//Output the DOMAIN information
		//factDomain.sort ();
		
		//factDomain.unique ();
		outputFileStream << "Domain(" << factDomain.size() << "):" << endl;
		
		int i = 0;
		
		for (std::set<string>::iterator it = factDomain.begin(); it != factDomain.end(); it++)
			{
				outputFileStream << "  " << *it << endl;
				
				i++;
			}
	}
	
	
	
	
	
	
	
	
void DatalogProgram::tokenTypeCheck (string tokenTypeSubmit, string tokenValueSubmit)
	{
		if (tokenTypeSubmit == "STRING")
			{
				if (std::find(std::begin(factDomain), std::end(factDomain), tokenValueSubmit) != std::end(factDomain))
					{

						//The String was found already in the Domain, so move on
					}
				else
					{
						//The String was NOT already in the Domain, so insert it
						factDomain.insert(tokenValueSubmit);
					}
			}
	}
