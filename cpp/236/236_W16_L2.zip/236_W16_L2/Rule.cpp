/*
 * Rule.cpp
 *
 *  Created on: Sep 30, 2015
 *      Author: heypono
 */

#include "Rule.h"


