/*
 * relation.h
 *
 *  Created on: Oct 22, 2015
 *      Author: heypono
 */

#ifndef RELATION_H_
#define RELATION_H_

#include "Predicate.h"

#include <vector>
#include <set>

#include <iostream>


using namespace std;


class Relation
	{
		private:
	
			string relationName;
			
			vector <Parameter> tupleNames;
			
			set <vector <string>> tupleValues;
	
		public:
		
			Relation(string relationNameSubmit, vector<Parameter> tupleNamesSubmit) : relationName(relationNameSubmit), tupleNames(tupleNamesSubmit)
				{
				
				};
			
			Relation()
				{
				
				};
			
			~Relation()
				{
				
				};
			
			
			void insertValues (vector <string> valuesSubmit)
				{
					//if (std::find (std::begin (columnValues), std::end (columnValues), columnValues_Submit) != std::end(columnValues))
						//{
						
						//}
				
					//else
						//{
							tupleValues.insert (valuesSubmit);
						//}
				};
			
			
			string getRelationName ()
				{
					return relationName;
				};
			
			
			
			
			//Display the Tuple Names at the COLUMN HEADS within the Relation Table
			void displayTupleNames ()
				{
					cout << "Displaying Column Names for: " << relationName << endl << endl;
				
					for (unsigned int i = 0; i < tupleNames.size(); i++)
						{
							cout << "element[" << i << "]: " << tupleNames[i].tokenValue << endl;
						}
					
					cout << endl << endl;
				};
			
			
			
			
			
			//Display the Tuple Values within the Relation Table
			void displayTupleValues ()
				{
					vector <string> currentTuple;
				
					for (std::set<vector <string>>::iterator it = tupleValues.begin(); it != tupleValues.end(); it++)
						{
							currentTuple = *it;
						
							for (unsigned int i = 0; i < currentTuple.size(); i++)
								{
									cout << currentTuple[i] << endl;
								}
						}
				};
			
			
			
			
			set <vector <string>> getTupleValues ()
				{
					return tupleValues;
				};
			
			
			
			void setTupleNames (int index, string indexName)
				{
					tupleNames[index].setTokenValue (indexName);
				}
			
			
			
	};



#endif /* RELATION_H_ */
