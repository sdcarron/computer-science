/*
 * Parameter.h
 *
 *  Created on: Sep 30, 2015
 *      Author: heypono
 */

#ifndef PARAMETER_H_
#define PARAMETER_H_

#include <string>

using namespace std;

class Parameter
	{
		friend class DatalogProgram;
		friend class Predicate;
		friend class Relation;
		friend class Main;
	
		private:
			string tokenType;
			string tokenValue;
	
		public:
			Parameter (string tokenType_Input, string tokenValue_Input) : tokenType(tokenType_Input), tokenValue(tokenValue_Input)
				{
				
				};
			
			Parameter()
				{
				
				};
			
			~Parameter()
				{
				
				};
			
			//If the Parameter of interest is an ID, return true
			bool isID(string tokenType)
				{
					if (tokenType == "ID")
						{
							return true;
						}
					
					else
						{
							return false;
						}
				};
			
			//If the Parameter of interest is a STRING, return true
			bool isString(string tokenType)
				{
					if (tokenType == "STRING")
						{
							return true;
						}
					
					else
						{
							return false;
						}
				};
			
			
			string getTokenValue ()
				{
					return tokenValue;
				};
			
			string getTokenType ()
				{
					return tokenType;
				};
			
			void setTokenValue (string valueSubmit)
				{
					tokenValue = valueSubmit;
				};
	};




#endif /* 236_LAB1_PARAMETER_H_ */
