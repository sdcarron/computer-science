/*
 * Pathfinder.cpp
 *
 *  Created on: Oct 13, 2014
 *      Author: heypono
 */

#include "Pathfinder.h"
#include <sstream>
#include <string>

Pathfinder::Pathfinder()
	{
		//maze3D;

		height=5;
		width=5;
		depth=5;

		srand(time(NULL));

		//Set the default status of the 3DMaze to be all 1's
		for (int z_sizeCheck = 0; z_sizeCheck<5; z_sizeCheck++)
			{
				for (int y_sizeCheck=0; y_sizeCheck<5; y_sizeCheck++)
					{
						for (int x_sizeCheck=0; x_sizeCheck<5; x_sizeCheck++)
							{
								maze3D[z_sizeCheck][y_sizeCheck][x_sizeCheck]=1;
							}
					}
			}
	}
Pathfinder::~Pathfinder()
	{

	}

//Part 1-----------------------------------------------------------------------------------
/*
 * getMaze
 *
 * Returns a string representation of the current maze. Returns a maze of all 1s if no maze
 * has yet been generated or imported.
 *
 * A valid string representation of a maze consists only of 125 1s and 0s (each separated
 * by spaces) arranged in five 5x5 grids (each separated by newlines). A valid maze must
 * also have 1s in the entrance cell (0, 0, 0) and in the exit cell (4, 4, 4).
 *
 * Cell (0, 0, 0) is represented by the first number in the string representation of the
 * maze. Increasing in x means moving toward the east, meaning cell (1, 0, 0) is the second
 * number. Increasing in y means moving toward the south, meaning cell (0, 1, 0) is the
 * sixth number. Increasing in z means moving downward to a new grid, meaning cell
 * (0, 0, 1) is the twenty-sixth number. Cell (4, 4, 4) is represented by the last number.
 *
 * Returns:		string
 *				A single string representing the current maze
 */
string Pathfinder::getMaze()
{

	//cout << "\n\nGET MAZE\n";
	//Variable to hold the final string representation of the maze
	string mazeString = "";

	//Variable to hold the current character that is to be added to the final string representation of the maze
	string currentChar = "";

	/*
	//Variable to count the number of empty cells to check for an empty maze
	int countNULL = 0;

	for (int z_sizeCheck = 0; z_sizeCheck<5; z_sizeCheck++)
		{
			for (int y_sizeCheck=0; y_sizeCheck<5; y_sizeCheck++)
				{
					for (int x_sizeCheck=0; x_sizeCheck<5; x_sizeCheck++)
						{
							if (maze3D[z_sizeCheck][y_sizeCheck][x_sizeCheck] == NULL)
								{
									countNULL++;
								}
						}
				}
		}

	cout << countNULL << endl;
	if (countNULL==125)
		{
			cout << "EMPTY MAZE\n";
			for (int i=1; i<126; i++)
				{
					if (i%5==0)
						{
							mazeString = mazeString + "1\n";
						}

					else
						{
							mazeString = mazeString + "1 ";
						}

					if (i%25==0)
						{
							mazeString = mazeString + "\n";
						}
				}
		}
	*/


	for (int z=0; z<5; z++)
		{
			for (int y=0; y<5; y++)
				{

					for (int x=0; x<5; x++)
						{
							/*
							currentChar = "" + maze3D[z][y][x];
							cout << "Current Character: " << currentChar;


							if (x==4)
								{
									mazeString = mazeString + currentChar + "\n";
								}
							else
								{

									mazeString = mazeString + currentChar + " ";
								}

							currentChar = "";
							*/

							if (x==4)
								{
										switch (maze3D[z][y][x])
											{
												case 1:
													mazeString = mazeString + "1\n";

													break;

												case 0:
													mazeString = mazeString + "0\n";

													break;
											}
								}

							else
								{
										switch(maze3D[z][y][x])
											{
												case 1:
													mazeString = mazeString + "1 ";

													break;

												case 0:
													mazeString = mazeString + "0 ";

													break;
											}
								}
						}


					if (y==4)
						{
							mazeString = mazeString + "\n";
						}
				}
		}
	//Return the final string representation of the maze
	//cout << mazeString;
	return mazeString;
}

/*
 * createRandomMaze
 *
 * Generates a random maze and stores it as the current maze.
 *
 * The generated maze must contain a roughly equal number of 1s and 0s and must have a 1
 * in the entrance cell (0, 0, 0) and in the exit cell (4, 4, 4).  The generated maze may be
 * solvable or unsolvable, and this method should be able to produce both kinds of mazes.
 */

void Pathfinder::createRandomMaze()
	{
	//cout << "\nCREATE CALLED\n";
		//Sets the size of the z dimension
		//maze3D = new int[height];

		int countOne = 0;
		int countZero = 0;

		//Seed the random number generator each time creating a new maze


		//sets each point along the z dimension to be the intended size of the y dimension
		for (int z=0; z<height; z++)
			{
				//Set the current point along the z dimension to be the intended size of the y dimension
				//maze3D[z] = new int[width];

				//Sets each point along the y dimension to be the intended size of the x dimension
				for (int y=0; y<width; y++)
					{
						//Set the current point along the y dimension to be the intended size of the x dimension
						//maze3D[z][y] = new int[depth];

						//For each point within the cube, set the value
						for (int x=0; x<depth; x++)
							{
								//If the current point is at (x=0, y=0, z=0) or at (x=4, y=4, z=4) then the value must be 1
								if ((z==0 && y==0 && x==0) || (z==4 && y==4 && x==4))
									{
										maze3D[z][y][x]=1;

										//countOne++;
									}

								//Otherwise, the current value must be randomly generated to be either 1 or 0
								else
									{
										maze3D[z][y][x]=rand()%2;

										/*
										if (maze3D[z][y][x]==1)
											{
												countOne++;
											}
										else if (maze3D[z][y][x]==0)
											{
												countZero++;
											}
										*/
									}

								/*
								if (x<4)
									{
										cout << "Height: " << z << " /Width: " << y << " /Depth: " << x << " /";
										cout << "| " << maze3D[z][y][x] << " |";
									}
								else
									{
										cout << "Height: " << z << " /Width: " << y << " /Depth: " << x << " /";
										cout << "| " << maze3D[z][y][x] << " |" << endl << endl;
									}
								*/
							}
					}
			}

		//cout << "Number of 1's: " << countOne << endl << endl;
		//cout << "Number of 0's: " << countZero << endl << endl;
	}
//-----------------------------------------------------------------------------------------

//Part 2-----------------------------------------------------------------------------------
/*
 * importMaze
 *
 * Reads in a maze from a file with the given file name and stores it as the current maze.
 * Does nothing if the file does not exist or if the file's data does not represent a valid
 * maze.
 *
 * The file's contents must be of the format described above to be considered valid.
 *
 * Parameter:	file_name
 *				The name of the file containing a maze
 * Returns:		bool
 *				True if the maze is imported correctly; false otherwise
 */
bool Pathfinder::importMaze(string file_name)
{
	//Input the submitted file
	//ifstream inputFile (file_name.c_str());

	//Alternative of above
	ifstream inputFile;
	inputFile.open(file_name.c_str());

	//cout << "Entering Importation Function" << endl;
	//cin.ignore();


	//String for holding each successive character in the submitted maze
	string inputChar;

	//Index variables for iteratively populating 3D maze
	int zCoord = 0;
	int yCoord = 0;
	int xCoord = 0;

	//Counter for monitoring the number of characters placed in the maze
	int countChar = 0;

	//Count the number of 1's and the number of 0's
	int numOf1 = 0;
	int numOf0 = 0;


	while (inputFile>>inputChar)
		{
			//cout << "Entering While Loop for the " << countChar << " time" << endl;
			//cin.ignore();

			//cout << "The first input numeric character is: " << inputChar << endl;
			//cin.ignore();

			//If any of the values in the submitted maze string is not 0, 1, or a space between a 0 and 1,
			//then the submitted maze is not a valid maze (it must contain only 0's and 1's)
			if (inputChar!="1" && inputChar!="0")
				{
					//cout << "The first input numeric character is 1, but it's breaking here anyway" << endl;
					//cin.ignore();

					return false;
				}

			//If the current character is a valid maze entry, place it into the current 3coordinate location
			if (inputChar=="1")
				{
					//cout << "Incrementing the count of 1 numeric characters" << endl;
					//cin.ignore();

					maze3DImportTest[zCoord][yCoord][xCoord]=1;
				}
			else if (inputChar=="0")
				{
					//cout << "Incrementing the count of 0 numeric characters" << endl;
					//cin.ignore();

					maze3DImportTest[zCoord][yCoord][xCoord]=0;
				}

			//Increment in x's first until x=4
			if (xCoord < 4)
				{
					//cout << "Incrementing the X coordinate to move EAST" << endl;
					//cin.ignore();

					xCoord++;
				}
			//If the x limit of 4 has been reached, reset x to 0 and increment y by 1
			else if (xCoord==4 && yCoord<4)
				{
					//cout << "Incrementing the Y coordinate and resetting the X coordinate to 0" << endl;
					//cin.ignore();

					xCoord=0;
					yCoord++;
				}
			//If both y and x are 4, reset both x and y to 0 and increment z by 1
			else if (xCoord==4 && yCoord==4 && zCoord<4)
				{
					//cout << "Incrementing the Z coordinate and resetting the X and Y coordinates to 0" << endl;
					//cin.ignore();

					xCoord=0;
					yCoord=0;
					zCoord++;
				}

			//Count the number of characters placed into the maze
			countChar++;
		}

	//If the number of characters pushed into the maze is not 125, then it's an invalid maze
	if (countChar!=125)
		{
			//cout << "There were not exactly 125 numeric characters" << endl;
			//cin.ignore();

			return false;
		}

	//If the first and last characters in the maze are not 1, then it's an invalid maze
	if (maze3DImportTest[0][0][0]!=1 || maze3DImportTest[4][4][4]!=1)
		{
			//cout << "Either the first or the last numeric character was not 1" << endl;
			//cin.ignore();

			return false;
		}

	for (int z=0; z<5; z++)
		{
			for (int y=0; y<5; y++)
				{
					for (int x=0; x<5; x++)
						{
							maze3D[z][y][x] = maze3DImportTest[z][y][x];
						}
				}
		}

	//if ()




	return true;
}
//-----------------------------------------------------------------------------------------

//Part 3-----------------------------------------------------------------------------------

//These test to see if the value one cell away from the current location is 1,
//if 1 is found in the neighboring cell, it is possible to move to that neighboring cell

/*
bool Pathfinder::moveEast(int currentZ, int currentY, int currentX){return false;}
bool Pathfinder::moveWest(int currentZ, int currentY, int currentX){return false;}
bool Pathfinder::moveSouth(int currentZ, int currentY, int currentX){return false;}
bool Pathfinder::moveNorth(int currentZ, int currentY, int currentX){return false;}
bool Pathfinder::moveUp(int currentZ, int currentY, int currentX){return false;}
bool Pathfinder::moveDown(int currentZ, int currentY, int currentX){return false;}
*/

bool Pathfinder::recursiveMove(int currentZ, int currentY, int currentX, bool& marker)
	{
		//cout << "Recursive step: (" << currentX << ", " << currentY << ", " << currentZ << ")" << endl;
		//If any of the bounds have been breached by the current coordinates, return FALSE
		if (0>currentZ || 4<currentZ || 0>currentY || 4<currentY || 0>currentX || 4<currentX)
			{
				//cout << "Bounds Check" << endl;
				return false;
			}

		//Create a string for constructed each LEGAL coordinate point in the solution path
		stringstream coordinates;

		//If the current location is the end point = coordinate (x=4,y=4,z=4) then set the marker to TRUE, submit the ending coordinate in
		//the solution path, and return true
		if (currentZ==4 && currentY==4 && currentX==4)
			{
				//Construct the ending coordinate in the solution path
				coordinates << "( " << currentX << ", " << currentY << ", " << currentZ << ")";

				//Set the boolean marker to TRUE to indicate having found the correct path
				marker = true;

				if (marker==true)
					{
						mazeCoordinates.insert(mazeCoordinates.begin(), coordinates.str());
					}

				return true;
			}

	/*	if (currentZ==0 && currentY==0 && currentX==0)
			{
				//Construct the beginning point in the solution path
				coordinates << "(" << currentX << ", " << currentY << ", " << currentZ << ")";

				//If the solution path marker is set to TRUE, then the ending point (4,4,4) was found, and
				//all of the coordinate points in between (4,4,4) and (0,0,0) have now been included into the
				//vector of solution path coordinates. Now insert the beginning point (0,0,0) into the vecotr
				//of solution path coordinates
				if (marker==true)
					{
						mazeCoordinates.insert(mazeCoordinates.begin(), coordinates.str());
					}
			}

*/
		//If the current coordinate point does not contain a value of 1, then moving there is not legal, so return FALSE
		if (maze3DCopy[currentZ][currentY][currentX]!=1)
			{
				//maze3DCopy[currentZ][currentY][currentX]=3;
				//cout << "Non valid cell" << endl;
				return false;
			}


		 //If a legal cell is found, paint the contents of the cell from 1 to 2, so that it is known to have been visited
		 maze3DCopy[currentZ][currentY][currentX]=2;


		 //Move East if possible
		 if (recursiveMove(currentZ, currentY, currentX+1, marker))
			{
				//Construct the new coordinate point for moving EAST
			 	coordinates << "(" << currentX+1 << ", " << currentY << ", " << currentZ << ")";

			 	//If the solution path marker is TRUE, insert the constructed coordinate point into the solution path vector
			 	if (marker==true)
			 		{
			 			mazeCoordinates.insert(mazeCoordinates.begin(), coordinates.str());
			 		}

				return true;
			}


		 //Move West if possible
		 if (recursiveMove(currentZ, currentY, currentX-1, marker))
			{
				 //Construct the new coordinate point for moving WEST
				coordinates << "(" << currentX-1 << ", " << currentY << ", " << currentZ << ")";

				//If the solution path marker is TRUE, insert the constructed coordinate point into the solution path vector
				if (marker==true)
					{
						mazeCoordinates.insert(mazeCoordinates.begin(), coordinates.str());
					}

				return true;
			}


		 //Move Northt if possible
		 if (recursiveMove(currentZ, currentY+1, currentX, marker))
			{
			 	//Construct the new coordinate point for moving NORTH
				coordinates << "(" << currentX << ", " << currentY+1 << ", " << currentZ << ")";

				//If the solution path marker is TRUE, insert the constructed coordinate point into the solution path vector
				if (marker==true)
					{
						mazeCoordinates.insert(mazeCoordinates.begin(), coordinates.str());
					}

				return true;
			}


		 //Move South if possible
		 if (recursiveMove(currentZ, currentY-1, currentX, marker))
			{
			 	//Construct the new coordinate point for moving SOUTH
				coordinates << "(" << currentX << ", " << currentY-1 << ", " << currentZ << ")";

				//If the solution path marker is TRUE, insert the constructed coordinate point into the solution path vector
				if (marker==true)
					{
						mazeCoordinates.insert(mazeCoordinates.begin(), coordinates.str());
					}

				return true;
			}


		 //Move Up if possible
		 if (recursiveMove(currentZ+1, currentY, currentX, marker))
			{
			 	//Construct the new coordinate point for moving UP
				coordinates << "(" << currentX << ", " << currentY << ", " << currentZ+1 << ")";

				//If the solution path marker is TRUE, insert the constructed coordinate point into the solution path vector
				if (marker==true)
					{
						mazeCoordinates.insert(mazeCoordinates.begin(), coordinates.str());
					}

				return true;
			}


		 //Move Down if possible
		 if (recursiveMove(currentZ-1, currentY, currentX, marker))
			{

			 	//Construct the new coordinate point for moving DOWN
				coordinates << "(" << currentX << ", " << currentY << ", " << currentZ-1 << ")";

				//If the solution path marker is TRUE, insert the constructed coordinate point into the solution path vector
				if (marker==true)
					{
						mazeCoordinates.insert(mazeCoordinates.begin(), coordinates.str());
					}

				return true;
			}

		//recursionCount++;

		//cout << "Recursion Count: " << recursionCount << endl;

		//cout << "Current Location: (" << currentX << ", " << currentY << ", " << currentZ << ")" << endl;


		//If movement is not possible, return false
		//cout << "Default false" << endl;
		return false;
	}

/*
 * solveMaze
 *
 * Attempts to solve the current maze and returns a solution if one is found.
 *
 * A solution to a maze is a list of coordinates for the path from the entrance to the exit
 * (or an empty vector if no solution is found). This list cannot contain duplicates, and
 * any two consecutive coordinates in the list can only differ by 1 for only one
 * coordinate. The entrance cell (0, 0, 0) and the exit cell (4, 4, 4) should be included
 * in the solution. Each string in the solution vector must be of the format "(x, y, z)",
 * where x, y, and z are the integer coordinates of a cell.
 *
 * Understand that most mazes will contain multiple solutions
 *
 * Returns:		vector<string>
 *				A solution to the current maze, or an empty vector if none exists
 */
vector<string> Pathfinder::solveMaze()
{
	mazeCoordinates.clear();

	vector<string> a;



	bool marker = false;

	//Copy the solved

	for (int z_sizeCheck = 0; z_sizeCheck<5; z_sizeCheck++)
		{
			for (int y_sizeCheck=0; y_sizeCheck<5; y_sizeCheck++)
				{
					for (int x_sizeCheck=0; x_sizeCheck<5; x_sizeCheck++)
						{
							maze3DCopy[z_sizeCheck][y_sizeCheck][x_sizeCheck]=maze3D[z_sizeCheck][y_sizeCheck][x_sizeCheck];
						}
				}
		}


	recursionCount = 0;

	if(recursiveMove(0,0,0, marker)){
		a = mazeCoordinates;
		a.insert(a.begin(),"(0, 0, 0)");
		//cout << "It finished fine." << endl;
	} else{
		//cout << "Something went wrong." << endl;
		vector<string> empty;
		a = empty;
	}



	//If vector "a" is larger than size 0, this gets removes one of the repeated (4,4,4) coordinates returned in the solution path
	if (a.size()>0)
		{
			a.pop_back();
		}
	/*
	if (a.size()==0)
		{
			cout << "Solution Path Vector is EMPTY" << endl;
		}
	*/


	/*
	string xCoord = "";
	string yCoord = "";
	string zCoord = "";

	string currentCell = "";

	//This is not working properly--It produces the right coordinates, but in the wrong order
	if (solvingResult==true)
		{
			for (int z=0; z<5; z++)
				{
					for (int y=0; y<5; y++)
						{
							for (int x=0; x<5; x++)
								{
									if (maze3DCopy[z][y][x]==2)
										{

											xCoord = x + "";
											yCoord = y + "";
											zCoord = z + "";


											switch (z)
												{
													case 0:
														zCoord = "0";

														break;

													case 1:
														zCoord = "1";

														break;

													case 2:
														zCoord = "2";

														break;

													case 3:
														zCoord = "3";

														break;

													case 4:
														zCoord = "4";

														break;
												}

											switch (y)
												{
													case 0:
														yCoord = "0";

														break;

													case 1:
														yCoord = "1";

														break;

													case 2:
														yCoord = "2";

														break;

													case 3:
														yCoord = "3";

														break;

													case 4:
														yCoord = "4";

														break;
												}

											switch (x)
												{
													case 0:
														xCoord = "0";

														break;

													case 1:
														xCoord = "1";

														break;

													case 2:
														xCoord = "2";

														break;

													case 3:
														xCoord = "3";

														break;

													case 4:
														xCoord = "4";

														break;
												}

											currentCell = "(" + xCoord + ", " + yCoord + ", " + zCoord + ") --> ";

											a.push_back(currentCell);
										}
								}
						}
				}
		}
	*/

	/*
	//cout << mazeCoordinates.size();
	for (int aIndex=0; aIndex<a.size(); aIndex++)
		{
			cout << a.at(aIndex);
		}
	*/

	//cout << "Size of Maze Coordinates vector: " << mazeCoordinates.size() << endl;

	//string startPoint
	return a;
}
//-----------------------------------------------------------------------------------------


