/*
 * ExpressionManager.cpp
 *
 *  Created on: Sep 23, 2014
 *      Author: heypono
 */

#include "ExpressionManager.h"
#include <sstream>
#include <cstdlib>
#include <stdlib.h>
#include <ctype.h>

ExpressionManager::ExpressionManager(){}
ExpressionManager::~ExpressionManager(){}

/*
* Checks whether an expression is balanced on its parentheses
*
* - The given expression will have a space between every number or operator
*
* @return true if expression is balanced
* @return false otherwise
*/



///I need to use at(i) rather than [i] for indexing the stacks

bool ExpressionManager::isBalanced(string expression)
	{
	//{ [ ) }
	//{ { [ ( ) ] } ( ) }
	//{ { ( ) [ { } ] ( [ ] ) } }


		//Variables to hold the various containers and help establish balance
		stack<string> expressionContainers;

		//Variable to monitor the number of balanced containers
		//int balancedContainers = 0;

		//Variable to monitor the number of unbalanced containers
		int unbalancedContainers = 0;

		//Variable to hold the string character currently in focus
		string currentChar;

		//Varialbe to hold the number of container parts
		int leftPartContainers = 0;
		int rightPartContainers = 0;

		//If the set of vectors has only 1 element, then it can't be balanced
		if(expression.length()==1)
			{
				return false;
			}
		else if (expression.at(0)==')' || expression.at(0)=='}' || expression.at(0)==']')
			{
				return false;
			}
		else if (expression.at(expression.length()-1)=='(' || expression.at(expression.length()-1)=='{' || expression.at(expression.length()-1)=='[')
			{
				return false;
			}

		//Create stringstream to hold expression tokens
		stringstream expressionTokens;
		expressionTokens << expression;

		//cout << "Expression: " << expression << endl;

		//Loop through string, capturing the left-part containers
		while(expressionTokens>>currentChar)
			{
				//currentChar = "";
				//currentChar = expression.substr(i,1);
				//expressionTokens >> currentChar;

				//cout<<"Current Character: " << currentChar << endl;

				//If the current element is a left-part container, capture it
				if(currentChar=="(" || currentChar=="{" || currentChar=="[")
					{
						//string currentChar = expression.substr(expression[i]);
						expressionContainers.push(currentChar);
					}

				//If the current element is a right-part container, compare it to the left-part container at the top of the stack
				else if(currentChar==")")
					{
						if (expressionContainers.size() > 0  &&  expressionContainers.top()=="(")
							{
								expressionContainers.pop();
							}
						else
							{
								unbalancedContainers++;

								//return false;
							}
					}
				else if(currentChar=="}")
					{
						if(expressionContainers.size() > 0 && expressionContainers.top()=="{")
							{
								expressionContainers.pop();
							}
						else
							{
								unbalancedContainers++;

								//return false;
							}
					}
				else if(currentChar=="]")
					{
						if(expressionContainers.size() > 0 && expressionContainers.top()=="[")
							{
								expressionContainers.pop();
							}
						else
							{
								unbalancedContainers++;

								//return false;
							}

					}
			}

		/*
		//If the top character is a left-part container and there are no more tokens to read, the expression is invalid
		if (expressionContainers.top()=="(" || expressionContainers.top()=="{" || expressionContainers.top()=="[")
			{
				return false;
			}
		*/

		if (expressionContainers.empty()==false)
			{
				return false;
			}

		//If all of the left-part containers have been compared to a right-part container, and they were all balanced, return true
		if (expressionContainers.size()==0 && unbalancedContainers==0)
			{
				return true;
			}
		else
			{
				return false;
			}
	}




bool ExpressionManager::isNumber(string expression)
	{
		int numCount = 0;
		int alpCount = 0;

		for (int i=0; i<expression.length(); i++)
			{
				if (isdigit(expression.at(i)))
					{
						numCount++;
					}

				else
					{
						alpCount++;
					}
			}

		if (numCount==expression.length())
			{
				return true;
			}
		else if (alpCount > 0)
			{
				return false;
			}

	}





bool ExpressionManager::isOperator(string expression)
	{
		string compareOps = "+-*/%";

		for (int i=0; i<expression.length(); i++)
			{
				if(compareOps.find_first_of(expression.at(i))==string::npos)
					{
						return false;
					}
			}

		return true;
	}





bool ExpressionManager::isContainer(string expression)
	{
		string compareCon = "(){}[]";

		for (int i=0; i<expression.length(); i++)
			{
				if (compareCon.find_first_of(expression.at(i))==string::npos)
					{
						return false;
					}
			}

		return true;
	}





/*
 * Converts a postfix expression into an infix expression
 * and returns the infix expression.
 *
 * - The given postfix expression will have a space between every number or operator.
 * - The returned infix expression must have a space between every number or operator.
 * - Redundant parentheses are acceptable i.e. ( ( 3 * 4 ) + 5 ).
 * - Check lab requirements for what will be considered invalid.
 *
 * return the string "invalid" if postfixExpression is not a valid postfix expression.
 * otherwise, return the correct infix expression as a string.
 */
string ExpressionManager::postfixToInfix(string postfixExpression)
	{
	cout << "Postfix Translate" << endl;
		//Copy the submitted postfix expression in order to verify that the number of arithmetic operators is acceptable
		string postfixExpressionCopy = postfixExpression;

		//cout << "here" << endl;
		stack<string> infixStack;

		//Variable to hold the translated expression
		string infixString;

		stack<string> expressionOps;

		string invalidExpression = "invalid";

		//Variable to hold the infix expression
		string expressionString;

		//Variables to help with building the infix expression
		string expressionHead;
		string expressionTail;

		//Variable to help with pulling information from the stack between right and left-part containers
		string backTrackChar;

		//Variable to help with pulling items from the expression and placing them into the stacks
		string currentChar;

		//Create stringstream to hold the submitted postfixExpression
		stringstream postfixStream;
		postfixStream << postfixExpression;

		cout << "Postfix Expression: " << postfixExpression << endl;

		//If the first item in the submitted postfix expression is an arithmetic operator, the expression is invalid
		if (isOperator(postfixExpression.substr(0,1)) || isNumber(postfixExpression.substr(postfixExpression.length()-1,1)))
			{
				return invalidExpression;
			}




		//Variable to hold comparison characters for identifying current character
		string compareNum = "0123456789";
		string compareOps = "+-*/%";
		string compareCon = "(){}[]";

		//Compare each character of the infix expression to the acceptable expression characters
		string compareCombined = " " + compareNum + compareOps + compareCon;
		for (int i=0; i<postfixExpression.length(); i++)
			{
				//Find how to properly use npos to identify a NULL character in a string
				if (compareCombined.find_first_of(postfixExpression.at(i))==string::npos)
					{
						return invalidExpression;

						//cout << "Invalid Expression" << endl;
					}
			}




		//Count the number of arithmetic operators and operands in the submitted expression
		//If the number of arithmetic operators is fewer than the number of operands-1, then the expression is invalid
		string currentCharCopy;
		stringstream postfixStreamCopy;
		postfixStreamCopy<<postfixExpressionCopy;
		int countNum=0;
		int countOps=0;
		while (postfixStreamCopy>>currentCharCopy)
			{
				if (isNumber(currentCharCopy))
					{
						countNum++;
					}
				else if (isOperator(currentCharCopy))
					{
						countOps++;
					}
				else
					{
						//cout << "This is where it's saying a VALID expression is invalid" << endl << endl;
						return invalidExpression;
					}
			}

		if (countOps!=(countNum-1))
			{
				//cout << "This is where it's saying a VALID expression is invalid" << endl << endl;
				return invalidExpression;
			}



		//Variables to help track the types of tokens that have entered
		string previousOne;
		string previousTwo;
		string previousThree;

		while (postfixStream>>currentChar)
			{


				//currentNum = 0;


				/* This isn't quite working right: 5555--- is an acceptable statement, but these statements would say it is invalid
				//Identify whether the current character is a numeric character--if it is, add it to the output stack
				if(isNumber(currentChar))
					{
						if (isNumber(previousOne) && isNumber(previousTwo))
							{
								return invalidExpression;
							}
						else
							{
								infixStack.push(currentChar);
							}
					}

				if (!isNumber(currentChar))
					{
						if (!isNumber(previousOne) && !isNumber(previousTwo) && !isNumber(previousThree))
							{
								return invalidExpression;
							}
					}
				*/

				//Add operators to the operator stack, pop operators from the stack to the infix stack as needed,
				//in order to add the new operator to the stack
				if (isOperator(currentChar) && infixStack.size()>=2)
					{
						expressionTail = infixStack.top();
						infixStack.pop();

						expressionHead = infixStack.top();
						infixStack.pop();

						expressionString = "( " + expressionHead + " " + currentChar + " " + expressionTail + " )";

						cout << "The current Expression: " << expressionString << endl << endl;

						infixStack.push (expressionString);
					}

				/*
				else if (isOperator(currentChar) && infixStack.size()<2)
					{
						expressionOps.push(currentChar);

						//cout << expressionOps.top() << " Operator just added to operator stack" << endl << endl;

						expressionString = "( " + infixStack.top() + " " + currentChar + " ";
					}
				*/

				else if (isNumber(currentChar) && expressionOps.size()==0)
					{
						infixStack.push(currentChar);
					}

				/*
				else if (isNumber(currentChar) && expressionOps.size()==1)
					{
						//expressionTail = currentChar;
						//infixStack.pop();

						//expressionHead = infixStack.top();
						//infixStack.pop();

						expressionString = infixStack.top() + currentChar + " )";

						cout << "The current Expression: " << expressionString << endl << endl;

						infixStack.push (expressionString);
					}
				*/

						/*
						if (infixStack.size()>=2)
							{
								expressionTail = infixStack.top();
								infixStack.pop();

								expressionTail = infixStack.top();
								infixStack.pop();

								expressionString = " " + expressionHead + " " + expressionOps.top() + " " + expressionTail + " ";
								infixStack.push(expressionString);
								expressionOps.pop();
							}
						*/


						//Figure out the reverse algorithm!!!!!
						//else if ()
					}

				//previousThree = previousTwo;
				//previousTwo = previousOne;
				//previousOne = currentChar;


		if (expressionOps.size()==1 && infixStack.size()==2)
			{
				expressionTail = infixStack.top();
				infixStack.pop();

				expressionHead = infixStack.top();
				infixStack.pop();

				expressionString = "" + expressionHead + " " + expressionTail + " " + expressionTail + "";
				expressionOps.pop();
			}

		else if (expressionOps.size()>1 && infixStack.size()==1)
			{
				//cout << "This is where it's saying a VALID expression is invalid" << endl << endl;
				return invalidExpression;
			}


		//Return the constructed expression, if it is valid
		return expressionString;
	}











/*
 * Converts an infix expression into a postfix expression
 * and returns the postfix expression
 *
 * - The given infix expression will have a space between every number or operator.
 * - The returned postfix expression must have a space between every number or operator.
 * - Check lab requirements for what will be considered invalid.
 *
 * return the string "invalid" if infixExpression is not a valid infix expression.
 * otherwise, return the correct postfix expression as a string.
 */
string ExpressionManager::infixToPostfix(string infixExpression)
	{
	cout << "Infix Translate" << endl;

		//Maintain order for the postfix expression
		//stack <string> postfixQeue;
		string postfixString = "";

		//Maintain order of the expression operators
		stack <string> expressionOps;

		string invalidExpression = "invalid";

		//Variable to hold comparison characters for identifying current character
		string compareNum = "0123456789";
		string compareOps = "+-*/%";
		string compareCon = "(){}[]";

		//Variable to help with pulling items from the expression and placing them into the stacks
		string currentChar;


		//Variable to hold the previous token from the expression to help with identifying valid/invalid expressions
		string previous;

		//Create stringstream to hold the expression information
		stringstream infixStream;
		infixStream << infixExpression;

		//Variable to hold the current expression through each iteration when cycling through the stacks of numbers and operators
		string currentExpression;


		if (isBalanced(infixExpression)==false)
			{
				return invalidExpression;
			}


		cout << "Infix Expression: " << infixExpression << endl << endl << endl;

		//Compare each character of the infix expression to the acceptable expression characters
		string compareCombined = " " + compareNum + compareOps + compareCon;
		for (int i=0; i<infixExpression.length(); i++)
			{
				//Find how to properly use npos to identify a NULL character in a string
				if (compareCombined.find_first_of(infixExpression.at(i))==string::npos)
					{
						return invalidExpression;

						//cout << "Invalid Expression" << endl;
					}
			}

		while (infixStream>>currentChar)
			{
				if (isOperator(currentChar)==true && isOperator(previous)==true)
					{
						return invalidExpression;

						//cout << "This is weird--hit two operators at once!";
					}

				//Identify whether the current character is a numeric character--if it is, add it to the postfix string
				if(isNumber(currentChar)==true)
					{

						postfixString = postfixString + " " + currentChar;

						cout << "Postfix Expression thus far: " << postfixString << endl;
					}

				//If the current character is a left-part container, just add it to the operator stack
				else if (currentChar=="(" || currentChar=="{" || currentChar=="[")
					{
						expressionOps.push(currentChar);
					}

				//If the current character is a divide, multiply, or modulus operator, add it to the operator stack
				else if (currentChar=="/") //|| currentChar=="*" || currentChar=="%")
					{
						while (expressionOps.size()>0 && (expressionOps.top()=="*" || expressionOps.top()=="/" || expressionOps.top()=="%"))
							{
								postfixString = postfixString + " " + expressionOps.top();

								expressionOps.pop();
							}

						expressionOps.push(currentChar);
					}

				else if (currentChar=="*")
					{
						while (expressionOps.size()>0 && expressionOps.top()=="*")
							{
								postfixString = postfixString + " " + expressionOps.top();

								expressionOps.pop();
							}

						expressionOps.push(currentChar);
					}



				//If the current character is a add or subtract operator, pop all operators from the stack onto the postfix that are of higher precedence,
				//then add the add or subtract operator to the operator stack
				else if (currentChar=="+" || currentChar=="-")
					{
						while (expressionOps.size()>0 && (expressionOps.top()=="/" || expressionOps.top()=="*" || expressionOps.top()=="%" || expressionOps.top()=="+"))
							{
								cout << expressionOps.top() << endl << endl;

								postfixString = postfixString + " " + expressionOps.top();

								cout << "Expression Operators Size: " << expressionOps.size() << endl;

								expressionOps.pop();

								cout << "postfix expression: " << postfixString << endl << endl;
							}

						expressionOps.push(currentChar);

						cout << expressionOps.top() << endl << endl;
					}



				//If the current character is a right-part parenthesis, cycle through the operator stack, popping operators from the stack onto the output until
				//finding a left-part parenthesis. If no a left-part non-parenthesis is found, or if no left-part parenthesis is found, the expression is invalid
				else if (currentChar==")")
					{
						while (expressionOps.size()>0 && expressionOps.top()!="(")
							{
								if (expressionOps.top()=="{" || expressionOps.top()=="[")
									{
										return invalidExpression;
									}
								else
									{
										postfixString = postfixString + " " + expressionOps.top();

										expressionOps.pop();

										cout << "postfix expression: " << postfixString << endl << endl;
									}
							}

						if (expressionOps.top()!="(")
							{
								return invalidExpression;
							}

						else
							{
								expressionOps.pop();
							}
					}



				//If the current character is a right-part parenthesis, cycle through the operator stack, popping operators from the stack onto the output until
				//finding a left-part parenthesis. If no a left-part non-parenthesis is found, or if no left-part parenthesis is found, the expression is invalid
				else if (currentChar=="}")
					{
						while (expressionOps.size()>0 && expressionOps.top()!="{")
							{
								if (expressionOps.top()=="(" || expressionOps.top()=="[")
									{
										return invalidExpression;
									}
								else
									{
										postfixString = postfixString + " " + expressionOps.top();

										expressionOps.pop();

										cout << "postfix expression: " << postfixString << endl << endl;
									}
							}

						if (expressionOps.top()!="{")
							{
								return invalidExpression;
							}

						else
							{
								expressionOps.pop();
							}
					}




				//If the current character is a right-part square, cycle through the operator stack, popping operators from the stack onto the output until
				//finding a left-part parenthesis. If no a left-part non-parenthesis is found, or if no left-part parenthesis is found, the expression is invalid
				else if (currentChar=="]")
					{
						while (expressionOps.size()>0 && expressionOps.top()!="[")
							{
								if (expressionOps.top()=="(" || expressionOps.top()=="{")
									{
										return invalidExpression;
									}
								else
									{
										postfixString = postfixString + " " + expressionOps.top();

										expressionOps.pop();

										cout << "postfix expression: " << postfixString << endl << endl;
									}
							}

						if (expressionOps.top()!="[")
							{
								return invalidExpression;
							}

						else
							{
								expressionOps.pop();
							}
					}
				//End of While Loop
				//End of While Loop
				//End of While Loop
				//End of While Loop
				//End of While Loop
				//End of While Loop
				//End of While Loop
				//End of While Loop
				//End of While Loop

				if (isContainer(currentChar)==false)
					{
						previous = currentChar;
					}
			}


		//If the top character is a left-part container and there are no more tokens to read, the expression is invalid
		if (expressionOps.top()=="(" || expressionOps.top()=="{" || expressionOps.top()=="[")
			{
				return invalidExpression;
			}


		if (postfixString.at(0)==' ')
			{
				postfixString = postfixString.substr(1);
			}


		//While the operators stack is not empty, pop the top operator onto the output and do this until the stack is empty
		while (expressionOps.size()>0)
			{
				postfixString = postfixString + " " + expressionOps.top();

				expressionOps.pop();

				//cout << "postfix expression: " << postfixString << endl << endl;
			}

		//If the expression has been translated, return it
		if (expressionOps.size()==0)
			{
				return postfixString;
			}
		else
			{
				return invalidExpression;
			}
	}










/*
 * Evaluates a postfix expression returns the result as a string
 *
 * - The given postfix expression will have a space between every number or operator.
 * - Check lab requirements for what will be considered invalid.
 *
 * return the string "invalid" if postfixExpression is not a valid postfix Expression
 * otherwise, return the correct evaluation as a string
 */
string ExpressionManager::postfixEvaluate(string postfixExpression)
	{
		cout << "Postfix Evaluate" << endl;
		//Convert the postfix expression into a form that is easier to evaluate
		//string infixExpression = postfixToInfix(postfixExpression);
		stringstream evaluationExpression;
		evaluationExpression << postfixExpression;

		/*
		//Stacks to help with sorting out the expression
		stack <string> expressionNum;
		stack <string> expressionOps;

		//Variable for identifying numeric characters in the expression string
		string compareNum = "0123456789";

		//Variable for identifying arithmetic operator characters in the expression string
		string compareOps = "+-%/*";
		*/

		//Variable to help with pulling items from the expression and placing them into the stacks
		string currentChar;

		//Variable to hold string "invalid" for identifying invalid expressions
		string invalidExpression = "invalid";

		//Variables to help with forming arithmetic statements
		int expressionHead = 0;
		int expressionTail = 0;

		int currentNum = 0;

		//Stacks to help with holding objects to build arithmetic statements
		stack <int> expressionNum;
		stack <string> expressionOps;

		int expressionEvaluation = 0;





		//Count the number of arithmetic operators and operands in the submitted expression
		//If the number of arithmetic operators is fewer than the number of operands-1, then the expression is invalid
		string currentCharCopy;
		stringstream postfixStreamCopy;
		postfixStreamCopy<<postfixExpression;
		int countNum=0;
		int countOps=0;
		while (postfixStreamCopy>>currentCharCopy)
			{
				if (isNumber(currentCharCopy))
					{
						countNum++;
					}
				else if (isOperator(currentCharCopy))
					{
						countOps++;
					}
				else
					{
						//cout << "This is where it's saying a VALID expression is invalid" << endl << endl;
						return invalidExpression;
					}
			}

		if (countOps!=(countNum-1))
			{
				//cout << "This is where it's saying a VALID expression is invalid" << endl << endl;
				return invalidExpression;
			}





		//Variable to keep track of the number of times pulling from the stringstream
		int numToken = 0;


		while (evaluationExpression>>currentChar)
			{

				cout << currentChar << endl;
				//If the postfix expression contained any containers, the expression must be invalid
				if (isContainer(currentChar))
					{
						cout << "Container" << endl;
						return invalidExpression;
					}


				//If the postfix expression starts with an arithmetic operator, the expression must be invalid
				if (!isNumber(currentChar) && numToken==0)
					{
						cout << "Operator" << endl;
						return invalidExpression;
					}


				//If the current character is a number, convert the numerical string into an integer
				if (isNumber(currentChar) && expressionOps.size()==0)
					{
						stringstream numStream;
						numStream << currentChar;
						numStream >> currentNum;

						expressionNum.push(currentNum);
					}

			//Add operators to the operator stack, pop operators from the stack to the infix stack as needed,
			//in order to add the new operator to the stack
			if (isOperator(currentChar) && expressionNum.size()>=2)
				{
					expressionTail = expressionNum.top();
					expressionNum.pop();

					expressionHead = expressionNum.top();
					expressionNum.pop();

					if (currentChar=="-")
						{
							expressionEvaluation = (expressionHead - expressionTail);
							expressionNum.push(expressionEvaluation);
						}
					else if (currentChar=="+")
						{
							expressionEvaluation = (expressionHead + expressionTail);
							expressionNum.push(expressionEvaluation);
						}
					else if (currentChar=="*")
						{
							expressionEvaluation = (expressionHead * expressionTail);
							expressionNum.push(expressionEvaluation);
						}
					else if (currentChar=="/")
						{
							if (expressionTail!=0)
								{
									expressionEvaluation = (expressionHead / expressionTail);
									expressionNum.push(expressionEvaluation);
								}
							else
								{
									return invalidExpression;
								}

						}
					else if (currentChar=="%")
						{
							expressionEvaluation = (expressionHead % expressionTail);
							expressionNum.push(expressionEvaluation);
						}

					cout << "Current Expression: " << expressionHead << " " << currentChar << " " << expressionTail << endl << endl;
					cout << "Current Evaluation: " << expressionEvaluation << "" << endl << endl;

					//cout << "The current Expression: " << expressionString << endl << endl;

					//infixStack.push (expressionString);
				}



			/*
			else if (isNumber(currentChar) && expressionOps.size()==0)
				{
					expressionNum.push(currentChar);
				}
			*/

			numToken++;
			}

		stringstream resultStream;
		resultStream << expressionNum.top();
		string result;
		resultStream >> result;
		return result;
	}


