/*
 * Node.h
 *
 *  Created on: Apr 2, 2015
 *      Author: heypono
 */

#ifndef NODE_H_
#define NODE_H_

#include "NodeInterface.h"

struct Node : public NodeInterface
	{
		//private:
			int data;

			int leftHeight;
			int rightHeight;

			int balance;

			Node *left;
			Node *right;


		//public:

			Node(int dataSubmit, Node *leftSubmit, Node *rightSubmit) : data(dataSubmit), leftHeight(0), rightHeight(0), left(leftSubmit) , right(rightSubmit)
				{

				};

			~Node()
				{

				};

			/*
			 * Returns the data stored in this node
			 *
			 * @return the data stored in this node.
			 */
			virtual int getData()
				{
					return data;
				};

			/*
			 * Returns the left child of this node or null if empty left child.
			 *
			 * @return the left child of this node or null if empty left child.
			 */
			virtual NodeInterface * getLeftChild()
				{
					return left;
				};

			/*
			 * Returns the right child of this node or null if empty right child.
			 *
			 * @return the right child of this node or null if empty right child.
			 */
			virtual NodeInterface * getRightChild()
				{
					return right;
				};

			/*
			 * Returns the height of this node. The height is the number of nodes
			 * along the longest path from this node to a leaf.  While a conventional
			 * interface only gives information on the functionality of a class and does
			 * not comment on how a class should be implemented, this function has been
			 * provided to point you in the right direction for your solution.  For an
			 * example on height, see page 448 of the text book.
			 *
			 * @return the height of this tree with this node as the local root.
			 */
			virtual int getHeight();


			//Gives the current Balance ( -1, 0, or 1) of the current Tree
			virtual int getBalance();
	};



#endif /* NODE_H_ */
