/*
 * AVL.cpp
 *
 *  Created on: Apr 2, 2015
 *      Author: heypono
 */


#include "AVL.h"
#include <iostream>

//Recursively look for submitted data ALREADY IN Tree
bool AVL::valueInTree (Node* recursiveSearchNode, int data)
	{
		//If the recursiveSearchNode == NULL, then the data is NOT in Tree
		if (recursiveSearchNode == NULL)
			{
				return false;
			}

		//If the submitted data == Current Node Value, then the submitted data IS in TREE
		else if (data == recursiveSearchNode->data)
			{
				return true;
			}

		//If the submitted data < Current Node Value, look LEFT
		else if (data < recursiveSearchNode->data)
			{
				//If Current Node Value's LEFT CHILD is NULL, then submitted data is NOT in TREE
				if (recursiveSearchNode->left == NULL)
					{
						return false;
					}

				//Otherwise, if Current Node Value's LEFT CHILD is NOT NULL, look for submitted data on next level (to LEFT)
				else
					{
						recursiveSearchNode = recursiveSearchNode->left;

						valueInTree (recursiveSearchNode , data);
					}
			}

		//If the submitted data > Current Node Value, look RIGHT
		else
			{
				//If Current Node Value's RIGHT CHILD is NULL, then submitted data is NOT in TREE
				if (recursiveSearchNode->right == NULL)
					{
						return false;
					}

				//Otherwise, if Current Node Value's RIGHT CHILD is NOT NULL, look for submitted data on next level (to RIGHT)
				else
					{
						recursiveSearchNode = recursiveSearchNode->right;

						valueInTree (recursiveSearchNode , data);
					}
			}
	}





bool AVL::add (int data)
	{
		cout << "Entering Add Function" << endl << endl;

		if (root == NULL)
			{
				root = new Node (data, NULL, NULL);

				return true;
			}

		else if (valueInTree (root, data) == false)
			{
				return recursiveAdd (root, root, data);
			}

		else
			{
				return false;
			}
	}

/*

bool AVL::recursiveAdd (Node* localRoot, int dataSubmit)
	{
		cout << "Entered Recursive Add function" << endl << endl;

		//If the location is EMPTY, insert a NEW NODE in that place
		if (localRoot == NULL)
			{
				cout << "Added the New Node with value: " << dataSubmit << endl << endl;

				localRoot = new Node (dataSubmit, NULL, NULL);

				increase = true;

				return true;
			}

		//If the submitted data value is LESS than the current NODE's value, move LEFT for insertion
		else if (dataSubmit < localRoot->data)
			{
				cout << "Moving to the LEFT to add the new Node" << endl << endl;

				//Return Value is set to be the result of ATTEMPTING to insert submitted value to LEFT
				bool returnValue = recursiveAdd (localRoot->left, dataSubmit);

				//IF VALUE HAS BEEN INSERTED:
				if (increase == true)
					{
						//Identify the CURRENT BALANCE of the localRoot's TREE
						switch (localRoot->getBalance())
							{
								//If the TREE was BALANCED BEFORE inserting the NEW NODE, the TREE is now UNBALANCED to the LEFT
								case 0:

									localRoot->balance = -1;

									//Increase the localRoot's LEFT SUBTREE HEIGHT
									localRoot->leftHeight++;

									break;

								//If the TREE was UNBALANCED to the RIGHT BEFORE inserting the NEW NODE, the TREE is now BALANCED
								case 1:

									localRoot->balance = 0;

									localRoot->leftHeight++;
									//Because inserting the NEW NODE only served to BALANCE the TREE, the HEIGHT DID NOT INCREASE
									increase = false;

									break;

								//If the TREE was UNBALANCED to the LEFT BEFORE inserting the NEW NODE, the TREE is CRITICALLY UNBALANCED and must be ROTATED
								case -1:

									//Because the TREE is CRITICALLY UNBALANCED, it must be rotated (LEFT in this case)
									rebalanceLeft (localRoot);
//function rebalanceLeft on ABOVE LINE NEEDS to be WRITTEN
									//After rotating the TREE, the HEIGHT is UNCHANGED from BEFORE the insertion, so the HEIGHT DID NOT INCREASE
									increase = false;

									break;
							}
					}

				return returnValue;
			}
		*/

bool AVL::recursiveAdd (Node* localRoot, Node* anchorNode, int dataSubmit)
	{
		cout << "Entered Recursive Add function" << endl << endl;

		//If the location is EMPTY, insert a NEW NODE in that place
		if (localRoot == NULL)
			{
				cout << "Added the New Node with value: " << dataSubmit << endl << endl;

				localRoot = new Node (dataSubmit, NULL, NULL);

				if (dataSubmit < anchorNode->data)
					{
						anchorNode->left = localRoot;

						//anchorNode->leftHeight++;
					}

				if (dataSubmit > anchorNode->data)
					{
						anchorNode->right = localRoot;

						//anchorNode->rightHeight++;
					}

				increase = true;

				return true;
			}

		//If the submitted data value is LESS than the current NODE's value, move LEFT for insertion
		else if (dataSubmit < localRoot->data)
			{
				cout << "Moving to the LEFT to add the new Node" << endl << endl;

				//Return Value is set to be the result of ATTEMPTING to insert submitted value to LEFT
				bool returnValue = recursiveAdd (localRoot->left, localRoot, dataSubmit);

				cout << "Returned from adding the value: " << dataSubmit << "   to the LEFT subtree" << endl << endl;

				//IF VALUE HAS BEEN INSERTED:
				if (increase == true)
					{
						cout << "Local Root: " << localRoot->data << "   has balance: " << localRoot->getBalance() << endl << endl;
						//Identify the CURRENT BALANCE of the localRoot's TREE
						switch (localRoot->getBalance())
							{
								//If the TREE was BALANCED BEFORE inserting the NEW NODE, the TREE is now UNBALANCED to the LEFT
								case 0:

									localRoot->balance = -1;

									//Increase the localRoot's LEFT SUBTREE HEIGHT
									localRoot->leftHeight++;

									break;

								//If the TREE was UNBALANCED to the RIGHT BEFORE inserting the NEW NODE, the TREE is now BALANCED
								case 1:

									localRoot->balance = 0;

									localRoot->leftHeight++;
									//Because inserting the NEW NODE only served to BALANCE the TREE, the HEIGHT DID NOT INCREASE
									increase = false;

									break;

								//If the TREE was UNBALANCED to the LEFT BEFORE inserting the NEW NODE, the TREE is CRITICALLY UNBALANCED and must be ROTATED
								case -1:

									//Because the TREE is CRITICALLY UNBALANCED, it must be rotated (LEFT in this case)
									rebalanceLeft (localRoot);
//function rebalanceLeft on ABOVE LINE NEEDS to be WRITTEN
									//After rotating the TREE, the HEIGHT is UNCHANGED from BEFORE the insertion, so the HEIGHT DID NOT INCREASE
									increase = false;

									break;
							}
					}

				return returnValue;
			}


		//If the submitted data value is GREATER than the current NODE's value, move RIGHT for insertion
		else if (dataSubmit > localRoot->data)
			{
				cout << "Moving to the RIGHT to add the new Node" << endl << endl;

				bool returnValue = recursiveAdd (localRoot->right, localRoot, dataSubmit);

				cout << "Returned from adding the value: " << dataSubmit << "   to the RIGHT subtree" << endl << endl;

				cout << "Current Local Root is: " << localRoot->data << endl << endl;

				cout << "Current value of 'increase' is: " << increase << endl << endl;

				if (increase == true)
					{
						cout << "Local Root: " << localRoot->data << "   has balance: " << localRoot->getBalance() << endl << endl;

						switch (localRoot->getBalance())
							{
								case 0:

									localRoot->balance = 1;

									localRoot->rightHeight++;

									break;

								case 1:

									rebalanceRight (localRoot);
//function rebalanceRight on ABOVE LINE NEEDS to be WRITTEN
									increase = false;

									break;

								case -1:

									localRoot->balance = 0;

									localRoot->rightHeight++;

									increase = false;

									break;

							}
					}

				return returnValue;
			}





		else
			{
				increase = false;

				return false;
			}
	}








void AVL::rebalanceLeft(Node* localRoot)
	{
		Node* leftChild = localRoot->left;

		if (leftChild->getBalance() == 1)
			{
				Node* leftRightChild = leftChild->right;


				//How could this situation ever occur?
				if (leftRightChild->getBalance() == -1)
					{
						leftChild->rightHeight = leftRightChild->left->getHeight();
						leftChild->leftHeight;

						leftRightChild->rightHeight;
						leftRightChild->leftHeight = leftChild->getHeight();

						//The LOCAL Root's RIGHT HEIGHT remains unchanged;
						localRoot->rightHeight;
						localRoot->leftHeight = leftRightChild->right->getHeight();
					}



				else if (leftRightChild->getBalance() == 0)
					{
						leftChild->rightHeight = leftRightChild->left->getHeight();
						leftChild->leftHeight;

						leftRightChild->rightHeight = localRoot->rightHeight++;
						leftRightChild->leftHeight = leftChild->getHeight();

						localRoot->rightHeight;
						localRoot->leftHeight = leftRightChild->right->getHeight();
					}



				else
					{
						leftChild->rightHeight = leftRightChild->left->getHeight();
						leftChild->leftHeight;

						leftRightChild->rightHeight = localRoot->rightHeight++;
						leftRightChild->leftHeight = leftChild->getHeight();

						localRoot->rightHeight;
						localRoot->leftHeight = leftRightChild->right->getHeight();
					}

				//Perform Left Rotation
				rotateLeft (localRoot->left);
//Include the rotateLeft function from the BOOK

			}

		//In the Left-Left Case, both the leftChild and localRoot will be BALANCED following the rotation
		else //Left-Left Case
			{
				leftChild->rightHeight = leftChild->getHeight();
				leftChild->leftHeight;

				localRoot->rightHeight;
				localRoot->leftHeight = localRoot->rightHeight;
			}

		//Finally, rotate RIGHT
		rotateRight (localRoot);
//Include the rotateRight function from the BOOK
	}

















void AVL::rebalanceRight(Node* localRoot)
	{
		Node* rightChild = localRoot->right;

		/*
		if (rightChild->getBalance() == -1)
			{
				Node* rightLeftChild = rightChild->left;


				if (rightLeftChild->getBalance() == -1)
					{
						rightChild->leftHeight = rightLeftChild->right->getHeight();
						rightChild->rightHeight;

						rightLeftChild->leftHeight;
						rightLeftChild->rightHeight = rightChild->getHeight();

						//The LOCAL Root's RIGHT HEIGHT remains unchanged;
						localRoot->leftHeight;
						localRoot->rightHeight = rightLeftChild->left->getHeight();
					}


				else if (rightLeftChild->getBalance() == 0)
					{
						rightChild->leftHeight = rightLeftChild->right->getHeight();
						rightChild->rightHeight;

						rightLeftChild->leftHeight = localRoot->leftHeight++;
						rightLeftChild->rightHeight = rightChild->getHeight();

						localRoot->leftHeight;
						localRoot->rightHeight = rightLeftChild->left->getHeight();
					}


				/*
				else
					{
						rightChild->leftHeight = rightLeftChild->right->getHeight();
						rightChild->rightHeight;

						rightLeftChild->leftHeight = localRoot->leftHeight++;
						rightLeftChild->rightHeight = rightChild->getHeight();

						localRoot->leftHeight;
						localRoot->rightHeight = rightLeftChild->left->getHeight();
					}


				//Perform Left Rotation
				rotateRight (localRoot->right);
//Include the rotateLeft function from the BOOK

			}



		//In the Left-Left Case, both the leftChild and localRoot will be BALANCED following the rotation
		else //Left-Left Case
			{
				rightChild->leftHeight = rightChild->getHeight();
				rightChild->rightHeight;

				localRoot->leftHeight;
				localRoot->rightHeight = localRoot->leftHeight;
			}

		//Finally, rotate RIGHT
		rotateLeft (localRoot);
//Include the rotateRight function from the BOOK

 */
	}


























void AVL::rotateLeft (Node* localRoot)
	{
		Node* temporary = localRoot->right;

		localRoot->right = temporary->left;

		temporary->left = localRoot;

		localRoot = temporary;
	}


void AVL::rotateRight (Node* localRoot)
	{
		Node* temporary = localRoot->left;

		localRoot->left = temporary->right;

		temporary->right = localRoot;

		localRoot = temporary;
	}



bool AVL::remove (int data)
	{
		if (valueInTree (root, data) == true)
			{
				if (root->left == NULL && root->right == NULL)
					{
						delete root;

						root = NULL;

						return true;
					}
			}
	}
