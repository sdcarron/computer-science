/*
 * Node.cpp
 *
 *  Created on: Apr 2, 2015
 *      Author: heypono
 */


#include "Node.h"


int Node::getHeight()
	{
		if (leftHeight == 0 && rightHeight == 0)
			{
				return 0;
			}

		else if (leftHeight != rightHeight)
			{
				if (leftHeight > rightHeight)
					{
						return leftHeight + 1;
					}

				else
					{
						return rightHeight + 1;
					}
			}
	}



int Node::getBalance()
	{
		balance = rightHeight - leftHeight;

		return balance;
	}


