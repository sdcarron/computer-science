/*
 * AVL.h
 *
 *  Created on: Apr 2, 2015
 *      Author: heypono
 */

#ifndef AVL_H_
#define AVL_H_

#include "AVLInterface.h"
#include "Node.h"

class AVL : public AVLInterface
	{
		private:
			Node* root;
			bool increase;

		public:
			AVL () : root (NULL)
				{

				};

			~AVL ()
				{

				};

			bool recursiveAdd (Node* localRoot, Node* anchorNode, int dataSubmit);

			void rebalanceLeft (Node* localRoot);

			void rebalanceRight (Node* localRoot);

			void rotateLeft (Node* localRoot);

			void rotateRight (Node* localRoot);

			bool valueInTree (Node* resursiveSearchNode, int data);



			//Please note that the class that implements this interface must be made
			//of objects which implement the NodeInterface

			/*
			 * Returns the root node for this tree
			 *
			 * @return the root node for this tree.
			 */
			virtual NodeInterface * getRootNode()
				{
					return root;
				};

			/*
			 * Attempts to add the given int to the AVL tree
			 * Rebalances the tree if data is successfully added
			 *
			 * @return true if added
			 * @return false if unsuccessful (i.e. the int is already in tree)
			 */
			virtual bool add(int data);

			/*
			 * Attempts to remove the given int from the AVL tree
			 * Rebalances the tree if data is successfully removed
			 *
			 * @return true if successfully removed
			 * @return false if remove is unsuccessful(i.e. the int is not in the tree)
			 */
			virtual bool remove(int data);
	};



#endif /* AVL_H_ */
