/*
 * QS.cpp
 *
 *  Created on: Mar 25, 2015
 *      Author: heypono
 */

#include "QS.h"

//srand(time(NULL));


/*
 * sortAll()
 *
 * Sorts elements of the array.  After this method is called, every
 * element in the array is less than or equal to the following element.
 *
 * Does nothing if the array is empty.
 */
void QS::sortAll()
	{
		int leftSubmit = 0;
		int rightSubmit = capacity - 1;
		//int pivotSubmit = (leftSubmit + rightSubmit) / 2;

		/*
		while (pivotIndex == leftRandom || pivotIndex == rightRandom || leftRandom == rightRandom || leftRandom > pivotIndex || leftRandom > rightRandom || pivotIndex > rightRandom || (rightRandom - leftRandom) < 2)
			{

			}
		*/
		//cout << "Printing out Array BEFORE Attempting to Sort" << endl;
		//cout << getArraySix() << endl;

		recursiveSort (leftSubmit, rightSubmit/*, pivotSubmit*/);
	}

string QS::getArraySix ()
	{
		string concatString;

		string arrayDisplay;

		for (int i=0; i <= capacity - 1; i++)
			{
				stringstream concatValue;

				concatValue << valueSequence[i];
				//cout <<"HELLO"<< endl;
				concatValue >> concatString;
				if (i == 0)
					{
						arrayDisplay = concatString;
					}

				else
					{
						arrayDisplay = arrayDisplay + "," + concatString;
					}
			}

		return arrayDisplay;
	}




void QS::recursiveSort (int leftSubmit, int rightSubmit/*, int pivotSubmit*/)
	{
		//bool leftSort = false;
		//bool rightSort = false;
		//bool totalSort = false;

		//int initialPivot;
		//int pivotSubmit;
		//int step = 0;



		/*
		if (abs(leftSubmit == rightSubmit))
			{
				return;
			}


		else if (abs(rightSubmit - leftSubmit) == 1)
			{
				if (valueSequence[leftSubmit] > valueSequence[rightSubmit])
					{
						int swapTemp1 = valueSequence[rightSubmit];
						int swapTemp2 = valueSequence[leftSubmit];

						valueSequence[leftSubmit] = swapTemp1;
						valueSequence[rightSubmit] = swapTemp2;

						return;
					}
			}

		else if (abs(rightSubmit - leftSubmit) == 2)
			{
				medianOfThree (leftSubmit, rightSubmit);

				return;
			}

		else
			{
				int pivotRecurseLeft = medianOfThree (leftSubmit, pivotSubmit);

				recursiveSort (leftSubmit, pivotRecurseLeft, pivotRecurseLeft);

				int pivotRecurseRight = medianOfThree (pivotSubmit, rightSubmit);

				recursiveSort (pivotRecurseRight, rightSubmit, pivotRecurseRight);
			}

		*/

		if (rightSubmit - leftSubmit > 1)
			{
				//return;

				//partition (leftSubmit, rightSubmit, pivotSubmit);

				int pivotRecurse = medianOfThree (leftSubmit, rightSubmit);



				pivotRecurse = partition (leftSubmit, rightSubmit, pivotRecurse);

				//leftSubmit++;

				//rightSubmit--;

				recursiveSort (leftSubmit, pivotRecurse);

				recursiveSort (pivotRecurse + 1, rightSubmit);
			}

		/*
		else if (rightSubmit - leftSubmit == 1)
			{

				int swapTemp1 = valueSequence[rightSubmit];
				int swapTemp2 = valueSequence[leftSubmit];

				valueSequence[leftSubmit] = swapTemp1;
				valueSequence[rightSubmit] = swapTemp2;

				return;
			}

		else if (rightSubmit - leftSubmit == 2)
			{
				medianOfThree (leftSubmit, rightSubmit);

				return;
			}



				//partition (leftSubmit, rightSubmit, pivotSubmit);

				//int pivotRecurse = medianOfThree (leftSubmit, rightSubmit);



				int partLocation = partition (leftSubmit, rightSubmit, pivotSubmit);

				//leftSubmit++;

				//rightSubmit--;

				recursiveSort (leftSubmit, partLocation - 1, 1);

				recursiveSort (partLocation + 1, rightSubmit, 2);
		*/

		/*

				//cout << "Printing Array At Start of TOTAL SORT" << endl;

				//cout << getArraySix() << endl << endl;

				pivotSubmit = medianOfThree (leftSubmit, rightSubmit);

				partition (leftSubmit, rightSubmit, pivotSubmit);

				cout << "After FIRST partition the Array looks like: " << endl;

				cout << getArraySix() << endl << endl;


				if ((rightSubmit - leftSubmit) >= 2)
					{
						if (step == 0)
							{
								pivotInitial = medianOfThree (leftSubmit, rightSubmit);

								pivotSubmit = pivotInitial;

								cout << "Printing Array At Start of TOTAL SORT" << endl;

								cout << getArraySix() << endl << endl;

								partition (leftSubmit, rightSubmit, pivotSubmit);

								cout << "After FIRST partition the Array looks like: " << endl;

								cout << getArraySix() << endl << endl;

								step = 1;

								recursiveSort (leftSubmit, rightSubmit, step);
							}

						else if (step != 0)
							{
								if (leftSort == false && (rightSubmit - leftSubmit) >= 2)
									{
										cout << "Sorting LEFT But NOT At the SMALLEST LEFT SUB" << endl << endl;

										rightSubmit--;

										pivotSubmit = medianOfThree (leftSubmit , rightSubmit);

										partition (leftSubmit, rightSubmit, pivotSubmit);

										recursiveSort (leftSubmit, rightSubmit, step);

									}


								else if (leftSort == false && (rightSubmit - leftSubmit) == 2)
									{
										cout << "Sorting LEFT At the SMALLEST LEFT SUB" << endl << endl;

										pivotSubmit = medianOfThree (leftSubmit, rightSubmit);

										partition (leftSubmit, rightSubmit, pivotSubmit);

										leftSort = true;

										step = 2;

										//return leftSort;
									}


								else if (leftSort == true && step == 2)
									{
										cout << "Sorting RIGHT" << endl << endl;
										rightSubmit = capacity - 1;

										leftSubmit = pivotInitial + 1;

										pivotSubmit = medianOfThree (leftSubmit, rightSubmit);

										partition (leftSubmit, rightSubmit, pivotSubmit);

										step = 3;

										recursiveSort (leftSubmit, rightSubmit, step);
									}


								else if (leftSort == true && step == 3 && (rightSubmit - leftSubmit) > 2)
									{
										cout << "Sorting RIGHT At the SMALLEST RIGHT SUB" << endl << endl;

										leftSubmit++;

										pivotSubmit = medianOfThree (leftSubmit, rightSubmit);

										partition (leftSubmit, rightSubmit, pivotSubmit);

										recursiveSort (leftSubmit, rightSubmit, step);


									}


								else if (leftSort == true && step == 3 && (rightSubmit - leftSubmit) == 2)
									{
										pivotSubmit = medianOfThree (leftSubmit, rightSubmit);

										partition (leftSubmit, rightSubmit, pivotSubmit);

										rightSort = true;

										return true;
									}

							}
					}



		else if (leftSort == true && rightSort == true)
			{
				return true;
			}

		else
			{
				return false;
			}
		*/

	}



/*
 * medianOfThree()
 *
 * Performs median-of-three pivot selection from among the values in
 * the array between the two given indices. Median-of-three pivot
 * selection will sort the first, middle, and last elements in a given
 * array with respect to each other. After this method is called,
 * data[first] <= data[middle] <= data[last], where middle =
 * (first + last)/2. The middle index will be the pivot value returned.
 *
 * Returns -1 if the array is empty, if either of the given integers
 * is out of bounds, or if the first integer is not less than the second
 * integer.
 *
 * @param left
 * 		the left boundary for the subarray from which to find a pivot
 * @param right
 * 		the right boundary for the subarray from which to find a pivot
 * @return
 *		the index of the pivot; -1 if provided with invalid input
 */
int QS::medianOfThree(int left, int right)
	{

		if (capacity == 0 || left >= right || left < 0 || right > (capacity - 1))
			{
				return -1;
			}

		else
			{
				int middle = (left + right)/2;

				int swapTemp1;
				int swapTemp2;
				int swapTemp3;

				if (valueSequence[middle] < valueSequence[left])
					{
						swapTemp1 = valueSequence[middle];

						swapTemp2 = valueSequence[left];

						valueSequence[middle] = swapTemp2;
						valueSequence[left] = swapTemp1;
					}

				if (valueSequence[right] < valueSequence[middle])
					{
						swapTemp1 = valueSequence[right];

						swapTemp2 = valueSequence[middle];

						valueSequence[right] = swapTemp2;
						valueSequence[middle] = swapTemp1;
					}

				if (valueSequence[right] < valueSequence[left])
					{
						swapTemp1 = valueSequence[right];

						swapTemp2 = valueSequence[left];

						valueSequence[right] = swapTemp2;
						valueSequence[left] = swapTemp1;
					}


				return middle;
			}
	}

/*
 * Partitions a subarray around a pivot value selected according to
 * median-of-three pivot selection.
 *
 * The values which are smaller than the pivot should be placed to the left
 * of the pivot; the values which are larger than the pivot should be placed
 * to the right of the pivot.
 *
 * Returns -1 if the array is null, if either of the given integers is out of
 * bounds, or if the first integer is not less than the second integer, or if the
 * pivot is not between the two boundaries.
 *
 * @param left
 * 		the left boundary for the subarray to partition
 * @param right
 * 		the right boundary for the subarray to partition
 * @param pivotIndex
 * 		the index of the pivot in the subarray
 * @return
 *		the pivot's ending index after the partition completes; -1 if
 * 		provided with bad input
 */
int QS::partition(int left, int right, int pivotIndex)
	{
		//cout << "Submitted Values: " << endl << endl;
		//cout << "Left: " << left << endl;
		//cout << "Right: " << right << endl;
		//cout << "Pivot: " << pivotIndex << endl;

		//If ANY of the submitted values are OUT OF RANGE, return -1
		if (capacity == 0 || left < 0 || right > capacity - 1 || (pivotIndex < 0 && pivotIndex > (capacity - 1)) || left >= right || pivotIndex >= right || (right - left) < 2)
			{
				return -1;
			}

		//Otherwise, place the pivotValue at the beginning of the Array, and TRAVERSE and PARTITION
		else
			{

					//cout << "Printing the Array BEFORE starting Partition: " << endl << endl;

					//cout << getArraySix() << endl;

					//cout << getArray();


				//Variables to help with temporarily locating the pivot value out of the way (at the beginning of Array) for partitioning
				int swapTemp1;
				int swapTemp2;

				//The pivotValue will be moved to the beginning of Array, so it is held by swapTemp1 (it's MOVING DOWN)
				//The initial beginning value of the Array will be MOVING UP, so it is held by swapTemp2
				//swapTemp1 = valueSequence[pivotIndex];

				//cout << "assigned swapTemp1 to be: " << swapTemp1 << "   At position [" endl;
				//swapTemp2 = valueSequence[left];

				//Move the Array elements
				//valueSequence[left] = swapTemp1;
				//valueSequence[pivotIndex] = swapTemp2;

				//Travers and PARTITION
				int up = left + 1;
				//cout << "assigned Up to be: " << valueSequence[up] << "   At position [" << up << "]" << endl;

				int down = right;
				//cout << "assigned Down to be: " << valueSequence[down] << "   At position [" << down << "]" << endl;


				int pivotValue = valueSequence[pivotIndex];
				//cout << "assigned pivotValue to be: " << valueSequence[pivotIndex] << "   At position [" << pivotIndex << "]" << endl;

				//Place the PIVOT VALUE at the START of Array
				swapTemp1 = valueSequence[pivotIndex];
				swapTemp2 = valueSequence[left];

				valueSequence[left] = swapTemp1;
				valueSequence[pivotIndex] = swapTemp2;

				//Look for values to relocate RELATIVE to the PIVOT VALUE
				do
					{
						//Increment UP until finding location of a VALUE that is LARGER than PIVOT VALUE, as long as UP is LESS THAN the RIGHT INDEX
						while ( (pivotValue > valueSequence[up]) && up < right - 1)
							{
								//cout << "Moving UP the array from position [" << up << "] to position[" << up+1 << "]" << endl;
								up++;
							}

						//Decrement DOWN until finding location of a VALUE that is SMALLER than PIVOT VALUE, as long as DOWN is GREATER THAN the LEFT INDEX
						while ( (pivotValue <= valueSequence[down]) && down > left)
							{
								//cout << "Moving DOWN the array from position [" << down << "] to position[" << down-1 << "]" << endl;
								down--;
							}

						//If UP is LEFT of DOWN, within Array, POSSIBLY SWAP the values
						if (up < down)
							{
								//If the VALUES located at UP and DOWN are both EQUAL to the PIVOT VALUE, then DO NOT SWAP them
								if (valueSequence[up] == pivotValue && pivotValue == valueSequence[down])
									{
									}

								//Otherwise, SWAP the VALUES located at UP and DOWN
								else
									{

										//cout << "Swapping the UP and DOWN Values inside Array" << endl;

										//cout << "Pivot Value is : " << pivotValue << endl;

										//cout << "UP is the value: " << valueSequence[up] << "   At position [" << up << "]" << endl;
										//cout << "DOWN is the value: " << valueSequence[down] << "   At position [" << down << "]" << endl;

										swapTemp1 = valueSequence[down];
										swapTemp2 = valueSequence[up];


										valueSequence[up] = swapTemp1;
										//cout << "swapTemp2 which has the value of UP-index Value is: " << swapTemp2 << endl;

										valueSequence[down] = swapTemp2;
										//cout << "swapTemp1 which has the value of DOWN-index Value is: " << swapTemp1 << endl;

										//cout << "Finished swapping the values" << endl;
									}
							}

					} while (up < down);

				//cout << "Done Partitioning" << endl;

				bool locatedPivotAfterPartition = false;
				int location = 0;

				if (pivotValue >= valueSequence[down])
					{
						//cout << "Setting the PIVOT VALUE in its PROPER location AFTER PARTITION" << endl;

						//After SWAPPING all VALUES AROUND the PIVOT VALUE (so "values < pivot" are on the left and "values > pivot" are on right),
						//relocate PIVOT VALUE to its PROPER location

						//cout << "Value to replace PIVOT VALUE at the START of Array is: " << valueSequence[down] << endl;
						//cout << "It is CURRENTLY located at INDEX: " << down << endl;
						swapTemp1 = valueSequence[down];

						//cout << "PIVOT VALUE is: " << pivotValue << " or " << valueSequence[left] << endl;
						//cout << "It is CURRENTLY located at INDEX: " << 0 << " or " << left << endl;
						swapTemp2 = valueSequence[left];

						//cout << "Set the PIVOT VALUE into its PROPER location SUCCESSFULLY" << endl << endl;;

						valueSequence[left] = swapTemp1;
						valueSequence[down] = swapTemp2;
					}

				//cout << "Printing the Array AFTER Partitioning: " << getArraySix() << endl << endl;

				//Once PIVOT VALUE is placed in its PROPER location, IDENTIFY where it is PROPERLY located
				while (locatedPivotAfterPartition == false)
					{
						//Return the PROPER location of PIVOT VALUE
						if (valueSequence[location] == pivotValue)
							{
								//cout << "Found the PROPER location of PIVOT VALUE, and it is: " << location << endl;
								return location;
							}

						else
							{
								location++;
							}
					}

				/*
				swapTemp1 = valueSequence[pivotIndex];
				swapTemp2 = valueSequence[left];

				valueSequence[pivotIndex] = swapTemp2;
				valueSequence[left] = swapTemp1;
				*/
			}
	}

/*
 * Gets the array of values and puts them into a string. For example: if my array
 * looked like {5,7,2,9,0}, then the string to be returned would look like "5,7,2,9,0"
 * with no trailing comma.
 *
 * Returns null, if the array is null or empty.
 *
 * @return
 *		the string representation of the current array
 */
string QS::getArray()
	{
		string concatString;

		string arrayDisplay;

		for (int i=0; i < insertLocation; i++)
			{
				stringstream concatValue;

				concatValue << valueSequence[i];
				//cout <<"HELLO"<< endl;
				concatValue >> concatString;
				if (i == 0)
					{
						arrayDisplay = concatString;
					}

				else
					{
						arrayDisplay = arrayDisplay + "," + concatString;
					}
			}

		return arrayDisplay;
	}

/*
 * Gets the size of the current array.
 *
 * @return
 * 		the current size
 */
int QS::getSize()
	{
		return capacity;
	}

/*
 * Adds the given value to the array.
 */
void QS::addToArray(int value)
	{
		/*if ( !( valueSequence.empty() ))
			{

			}


		if ( valueSequence[capacity - 1] != NULL )
			{
				int* tempStretch [capacity * 2];

				for (int i = 0; i < capacity; i++)
					{
						tempStretch [i] = valueSequence[i];
					}

				valueSequence = tempStretch;

				capacity = capacity * 2;

				delete[] tempStretch;
			}

		*/

		//If the Array is already full, DO NOT insert the submitted value AND NOTIFY that value was NOT inserted
		if (insertLocation == capacity)
			{
				cout << "Array was already full--unable to insert the desired value at this time" << endl << endl;

				return;
			}

		//Otherwise, insert the submitted value at the current insertLocation, then increment insertLocation
		else
			{
				valueSequence[insertLocation] = value;

				insertLocation++;

				return;
			}
	}

/*
 * Creates an array with the given size.
 *
 * Returns false if the given value is non-positive, true otherwise.
 *
 * @param
 *		size of array
 * @return
 *		true if the array was created, false otherwise
 */
bool QS::createArray(int size)
	{
		if (size <= 0)
			{
				return false;
			}

		else
			{
				valueSequence = new int[size];

				capacity = size;

				//cout << "Submitted Size: " << size << endl << endl;

				//cout << "Capacity: " << capacity << endl << endl;

				//This is initialized in the Class Header, so it doesn't need to be initialized here--the value is ONLY ADJUSTED when inserting into the Array
				//insertLocation = 0;

				return true;
			}
	}

/*
 * Clears the array.
 */
void QS::clear()
	{
		capacity = 0;
		insertLocation = 0;

		delete[] valueSequence;
	}


