/*
 * QS.h
 *
 *  Created on: Mar 25, 2015
 *      Author: heypono
 */

#ifndef QS_H_
#define QS_H_

#include "QSInterface.h"
#include <array>
#include <sstream>
#include <time.h>
#include <stdlib.h>

class QS : public QSInterface
	{
		private:
			int* valueSequence = NULL;

			int left = 0;
			int pivot = 0;
			int right = 0;

			int capacity = 0;
			int insertLocation = 0;

			//These Variables are used for the recursiveSort section
			//int pivotInitial = 0;
			//int pivotSubmit = 0;

			//bool leftSort = false;
			//bool rightSort = false;
			//bool totalSort = false;
		public:
			QS()// : public QSInterface()
				{
				}
			~QS()// : public ~QSInterface()
				{
					clear();
				}

			void recursiveSort(int leftSubmit, int rightSubmit/*, int step*/);

			string getArraySix ();

			/*
			 * sortAll()
			 *
			 * Sorts elements of the array.  After this method is called, every
			 * element in the array is less than or equal to the following element.
			 *
			 * Does nothing if the array is empty.
			 */
			virtual void sortAll();

			/*
			 * medianOfThree()
			 *
			 * Performs median-of-three pivot selection from among the values in
			 * the array between the two given indices. Median-of-three pivot
			 * selection will sort the first, middle, and last elements in a given
			 * array with respect to each other. After this method is called,
			 * data[first] <= data[middle] <= data[last], where middle =
			 * (first + last)/2. The middle index will be the pivot value returned.
			 *
			 * Returns -1 if the array is empty, if either of the given integers
			 * is out of bounds, or if the first integer is not less than the second
			 * integer.
			 *
			 * @param left
			 * 		the left boundary for the subarray from which to find a pivot
			 * @param right
			 * 		the right boundary for the subarray from which to find a pivot
			 * @return
			 *		the index of the pivot; -1 if provided with invalid input
			 */
			virtual int medianOfThree(int left, int right);

			/*
			 * Partitions a subarray around a pivot value selected according to
			 * median-of-three pivot selection.
			 *
			 * The values which are smaller than the pivot should be placed to the left
			 * of the pivot; the values which are larger than the pivot should be placed
			 * to the right of the pivot.
			 *
			 * Returns -1 if the array is null, if either of the given integers is out of
			 * bounds, or if the first integer is not less than the second integer, or if the
			 * pivot is not between the two boundaries.
			 *
			 * @param left
			 * 		the left boundary for the subarray to partition
			 * @param right
			 * 		the right boundary for the subarray to partition
			 * @param pivotIndex
			 * 		the index of the pivot in the subarray
			 * @return
			 *		the pivot's ending index after the partition completes; -1 if
			 * 		provided with bad input
			 */
			virtual int partition(int left, int right, int pivotIndex);

			/*
			 * Gets the array of values and puts them into a string. For example: if my array
			 * looked like {5,7,2,9,0}, then the string to be returned would look like "5,7,2,9,0"
			 * with no trailing comma.
			 *
			 * Returns null, if the array is null or empty.
			 *
			 * @return
			 *		the string representation of the current array
			 */
			virtual string getArray();

			/*
			 * Gets the size of the current array.
			 *
			 * @return
			 * 		the current size
			 */
			virtual int getSize();

			/*
			 * Adds the given value to the array.
			 */
			virtual void addToArray(int value);

			/*
			 * Creates an array with the given size.
			 *
			 * Returns false if the given value is non-positive, true otherwise.
			 *
			 * @param
			 *		size of array
			 * @return
			 *		true if the array was created, false otherwise
			 */
			virtual bool createArray(int size);

			/*
			 * Clears the array.
			 */
			virtual void clear();
	};

#endif /* QS_H_ */
