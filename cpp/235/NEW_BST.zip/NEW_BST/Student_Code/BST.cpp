/*
 * BST.cpp
 *
 *  Created on: Mar 10, 2015
 *      Author: heypono
 */



#include "BST.h"

/*
BST::BST()
	{
		root = NULL;
	}

BST::~BST()
	{

	}
*/



//Please note that the class that implements this interface must be made
//of objects which implement the NodeInterface

/*
* Returns the root node for this tree
*
* @return the root node for this tree.
*/

/*
NodeInterface * BST::getRootNode()
	{
		if (root != NULL)
			{
				return root;
			}

		else
			{
				return NULL;
			}
	}
*/







//Perform an PREORDER Traversal Printing of Tree
void BST::printTree (Node* recursivePrintNode)
	{
		//Print Current Node Value
		stringstream currentNode;
		string currentNodeDisplay;

		currentNode << recursivePrintNode->data;

		currentNode >> currentNodeDisplay;

		cout << currentNodeDisplay << endl << endl;

		//If Current Node Value's LEFT and RIGHT children are NULL, return
		if (recursivePrintNode->leftChild == NULL && recursivePrintNode->rightChild == NULL)
			{
				cout << "Hit Leaf Node" << endl << endl;

				return;
			}

		//If possible, move LEFT to Next Node
		if (recursivePrintNode->leftChild != NULL)
			{
				cout << "Moving Left" << endl << endl;
				//recursivePrintNode = recursivePrintNode->leftChild;

				printTree (recursivePrintNode->leftChild);

				//return;
			}

		//Otherwise, if possible, move RIGHT to Next Node
		if (recursivePrintNode->rightChild != NULL)
			{
				cout << "Moving Right" << endl << endl;
				//recursivePrintNode = recursivePrintNode->rightChild;

				printTree (recursivePrintNode->rightChild);

				//return;
			}

		return;

	}







//Recursively look for submitted data ALREADY IN Tree
bool BST::valueInTree (Node* recursiveSearchNode, int data)
	{
		//If the recursiveSearchNode == NULL, then the data is NOT in Tree
		if (recursiveSearchNode == NULL)
			{
				return false;
			}

		//If the submitted data == Current Node Value, then the submitted data IS in TREE
		else if (data == recursiveSearchNode->data)
			{
				return true;
			}

		//If the submitted data < Current Node Value, look LEFT
		else if (data < recursiveSearchNode->data)
			{
				//If Current Node Value's LEFT CHILD is NULL, then submitted data is NOT in TREE
				if (recursiveSearchNode->leftChild == NULL)
					{
						return false;
					}

				//Otherwise, if Current Node Value's LEFT CHILD is NOT NULL, look for submitted data on next level (to LEFT)
				else
					{
						recursiveSearchNode = recursiveSearchNode->leftChild;

						valueInTree (recursiveSearchNode , data);
					}
			}

		//If the submitted data > Current Node Value, look RIGHT
		else
			{
				//If Current Node Value's RIGHT CHILD is NULL, then submitted data is NOT in TREE
				if (recursiveSearchNode->rightChild == NULL)
					{
						return false;
					}

				//Otherwise, if Current Node Value's RIGHT CHILD is NOT NULL, look for submitted data on next level (to RIGHT)
				else
					{
						recursiveSearchNode = recursiveSearchNode->rightChild;

						valueInTree (recursiveSearchNode , data);
					}
			}
	}









//Recursively Traverse the Tree in order to place the data in the correct location
bool BST::recursiveInsert(Node* recursiveInsertNode, int data)
	{
		//If the submitted data < Current Node Value, try to insert it LEFT
		if (data < recursiveInsertNode->data)
			{
				//If Current Node Value's LEFT CHILD is NULL, insert submitted data in that location
				if (recursiveInsertNode->leftChild == NULL)
					{
						recursiveInsertNode->leftChild = new Node (data , NULL , NULL);

						count++;

						return true;
					}

				//Otherwise, MOVE LEFT and try to insert the submitted data at the next level
				else
					{
						recursiveInsertNode = recursiveInsertNode->leftChild;

						recursiveInsert (recursiveInsertNode , data);
					}
			}

		//If the submitted data > Current Node Value, try to insert it RIGHT
		else
			{
				//If Current Node Value's RIGHT CHILD is NULL, insert submitted data in that location
				if (recursiveInsertNode->rightChild == NULL)
					{
						recursiveInsertNode->rightChild = new Node (data , NULL , NULL);

						count++;

						return true;
					}

				//Otherwise, MOVE RIGHT and try to insert the submitted data at the next level
				else
					{
						recursiveInsertNode = recursiveInsertNode->rightChild;

						recursiveInsert (recursiveInsertNode , data);
					}
			}
	}









/*
* Attempts to add the given int to the BST tree
*
* @return true if added
* @return false if unsuccessful (i.e. the int is already in tree)
*/
bool BST::add(int data)
	{
		//cout << "Entered ADD in BST" << endl;

		//cout << "Attempting to add value: " << data << endl;

		//If submitted data is NOT in TREE, traverse the Tree to find correct insertion location
		if (valueInTree (root , data) == false)
			{
				//cout << "Value is NOT already in Tree" << endl;

				//If Root is NULL, insert the data as ROOT
				if (root == NULL)
					{
						//cout << "Adding Value as ROOT" << endl;


						root = new Node (data , NULL , NULL);

						//cout << "Set Value as NEW Root" << endl;

						count++;

						//cout << "Incremented NODE Count" << endl;

						return true;

					}


				//Otherwise, Root is NOT NULL and the Tree must be Traversed RECURSIVELY in order to insert the data in correct location
				else
					{
						//cout << "Adding Value somewhere in Tree" << endl;


						return recursiveInsert (root , data);

					}
			}

		//Otherwise, submitted data IS in Tree
		else
			{
				//cout << "Value IS already in Tree" << endl;

				return false;
			}
	}




/*
Node* BST::findInorderReplace(Node* recursiveRemoveNode)
	{
		//If the Node being REMOVED has LEFT Child, move LEFT and then go AS FAR RIGHT AS POSSIBLE
		if (recursiveRemoveNode->leftChild != NULL)
			{
				Node* inorderReplace = recursiveRemoveNode->leftChild;

				while (inorderReplace->rightChild != NULL)
					{
						inorderReplace = inorderReplace->rightChild;
					}

				return inorderReplace;
			}

		//Otherwise, if the Node being REMOVED does NOT have a LEFT Child, but it has a RIGHT Child, move RIGHT and then go AS FAR LEFT AS POSSIBLE
		else if (recursiveRemoveNode->rightChild != NULL)
			{
				Node* inorderReplace = recursiveRemoveNode->rightChild;

				while (inorderReplace->leftChild != NULL)
					{
						inorderReplace = inorderReplace->leftChild;
					}

				return inorderReplace;
			}

		//Otherwise, the Node being REMOVED has NO replacement
		else
			{
				return NULL;
			}
	}

*/



//This seems to work correctly for ANY situation EXCEPT for when I have only 1 value in the TREE
//Recursive remove
bool BST::recursiveRemove (Node* recursiveRemoveNode , Node* anchorNode , int data)
	{



		//If the Current Node being TESTED for Removal is Root, initiate the ANCHOR NODE
		if (recursiveRemoveNode == root && count > 1)
			{
				anchorNode = root;
			}





		//If submitted data == Current Node Value, REMOVE current Node
		if (recursiveRemoveNode->data == data)
			{

				/*
				 * This was SUPPOSED to remove the LAST REMAINING NODE FROM THE TREE,
				 * BUT it always throws a Segmentation Fault (it was replaced with the SINGLE NODE REMOVAL in the Remove Function
				 */
				//If the Node being REMOVED is a LEAF Node, set POINTERS TO IT to NULL				 */
				if (recursiveRemoveNode->leftChild == NULL && recursiveRemoveNode->rightChild == NULL)
					{
						//If the Node being REMOVEd is the ONLY Node in Tree,
						if (recursiveRemoveNode->data == root->data)
							{
								//cout << "Removing the ONLY NODE in Tree (BST Remove Function)" << endl << endl;

								//cout << "Setting Left Child to NULL" << endl;

										//anchorNode->leftChild = NULL;

								//cout << "Setting Right Child to NULL" << endl;

										//anchorNode->rightChild = NULL;

								//cout << "Setting Anchor Node to NULL" << endl;

										//anchorNode = NULL;

								//cout << "Setting Root to NULL" << endl;

								//root = NULL;

								//delete root;
							}

						//If the Node being Removed is LEFT Child of the Anchor Node
						else if (recursiveRemoveNode->data < anchorNode->data)
							{
								anchorNode->leftChild = NULL;
							}

						//Otherwise, the Node being Removed is Right Child of the Anchor Node
						else if (recursiveRemoveNode->data > anchorNode->data)
							{
								anchorNode->rightChild = NULL;
							}

						if (root != NULL)
							{
								//cout << "Deleting the Submitted Node Value (" << recursiveRemoveNode->data << ") "<< endl;
								delete recursiveRemoveNode;
							}


						count--;


						return true;
					}


				//If the Node being Removed has ONLY a LEFT Child, then replace it with the LEFT Child
				else if (recursiveRemoveNode->leftChild != NULL && recursiveRemoveNode->rightChild == NULL)
					{
						//The Replacement Node is the LEFT Child of the Node being REMOVED
						Node* nonInorderReplace = recursiveRemoveNode->leftChild;

						//If the Node being Removed is ROOT, then the NEW Root will be the Replacement Node
						if (recursiveRemoveNode == root)
							{
								root = nonInorderReplace;
							}

						//Otherwise, set the Replacement Node to be the CORRECT Child of Anchor Node
						else
							{
								if (anchorNode->data < recursiveRemoveNode->data)
									{
										anchorNode->rightChild = nonInorderReplace;
									}

								else
									{
										anchorNode->leftChild = nonInorderReplace;
									}
							}

						//Delete the Node being Removed and Decrement the Tree Count
						delete recursiveRemoveNode;

						count--;

						return true;
					}


				//If the Node being Removed has ONLY a RIGHT Child, then replace it with the RIGHT Child
				else if (recursiveRemoveNode->rightChild != NULL && recursiveRemoveNode->leftChild == NULL)
					{
						//The Replacement Node is the RIGHT Child of the Node being REMOVED
						Node* nonInorderReplace = recursiveRemoveNode->rightChild;

						//If the Node being Removed is ROOT, then the NEW Root will be the Replacement Node
						if (recursiveRemoveNode == root)
							{
								root = nonInorderReplace;
							}

						//Otherwise, set the Replacement Node to be the CORRECT Child of Anchor Node
						else
							{
								if (anchorNode->data < recursiveRemoveNode->data)
									{
										anchorNode->rightChild = nonInorderReplace;
									}

								else
									{
										anchorNode->leftChild = nonInorderReplace;
									}
							}

						//Delete the Node being Removed and Decrement the Tree Count
						delete recursiveRemoveNode;

						count--;

						return true;
					}

				//If the Node being REMOVED has LEFT Child, move LEFT and then go AS FAR RIGHT AS POSSIBLE
				else if (recursiveRemoveNode->leftChild != NULL)
					{
						//Variables to help retain any information FOLLOWING the Removal Node's INORDER Predecessor
						Node* inorderReplace = recursiveRemoveNode->leftChild;
						Node* inorderReplacePrev = inorderReplace;

						//Move as far RIGHT as possible from the Node to IMMEDIATE LEFT from Removal Node
						while (inorderReplace->rightChild != NULL)
							{
								inorderReplacePrev = inorderReplace;

								inorderReplace = inorderReplace->rightChild;
							}

						//DID NOT MOVE RIGHT AT ALL
						//If Moving RIGHT was NOT POSSIBLE
						if (inorderReplace == inorderReplacePrev)
							{
								//Retain Removal Node's RIGHT Subtree
								inorderReplace->rightChild = recursiveRemoveNode->rightChild;

								//If Removal Node is ROOT, make the INORDER PREDECESSOR the new Root
								if (recursiveRemoveNode == root)
									{
										root = inorderReplace;
									}

								//Otherwise, if Removal Node is NOT ROOT, decide which Subtree of the Node that PRECEDED Removal Node starts with Removal Node's INORDER PREDECESSOR
								else
									{
										if (anchorNode->data < inorderReplace->data)
											{
												anchorNode->rightChild = inorderReplace;
											}

										else
											{
												anchorNode->leftChild = inorderReplace;
											}
									}

								delete recursiveRemoveNode;

								count--;

								return true;
							}

						//MOVED RIGHT AS FAR AS POSSIBLE
						//INORDER Replacement for Removal Node has NO LEFT Subtree
						else if (inorderReplace->leftChild == NULL)
							{
								//Node PRECEDING the Removal Node's INORDER PREDECESSOR must now have a NULL Right Child
								inorderReplacePrev->rightChild = NULL;

								//cout << "Inorder Replace Prev: " << inorderReplacePrev->data << endl;
								//cout << "Inorder Replace Prev Right Child: " << inorderReplacePrev->rightChild->data << endl;

								//Retain Removal Node's Left AND Right Subtrees
								inorderReplace->leftChild = recursiveRemoveNode->leftChild;

								inorderReplace->rightChild = recursiveRemoveNode->rightChild;

								//If Removal Node is ROOT, make the INORDER PREDECESSOR the new Root
								if (recursiveRemoveNode == root)
									{
										root = inorderReplace;
									}

								//Otherwise, if Removal Node is NOT ROOT, decide which Subtree of the Node that PRECEDED Removal Node starts with Removal Node's INORDER PREDECESSOR
								else
									{
										if (anchorNode->data < inorderReplace->data)
											{
												anchorNode->rightChild = inorderReplace;
											}

										else
											{
												anchorNode->leftChild = inorderReplace;
											}
									}

								delete recursiveRemoveNode;

								count--;

								return true;
							}

						//MOVED RIGHT AS FAR AS POSSIBLE
						//INORDER Replacement for Removal Node HAS a Left Subtree
						else
							{
								//Node PRECEDING the Removal Node's INORDER PREDECESSOR must have a Right Child that is Replacement Node's LEFT CHILD
								inorderReplacePrev->rightChild = inorderReplace->leftChild;

								//Retain Removal Node's Left AND Right Subtrees
								inorderReplace->leftChild = recursiveRemoveNode->leftChild;

								inorderReplace->rightChild = recursiveRemoveNode->rightChild;

								//If Removal Node is ROOT, make the INORDER PREDECESSOR the new Root
								if (recursiveRemoveNode == root)
									{
										root = inorderReplace;
									}

								//Otherwise, if Removal Node is NOT ROOT, decide which Subtree of the Node that PRECEDED Removal Node starts with Removal Node's INORDER PREDECESSOR
								else
									{
										if (anchorNode->data < inorderReplace->data)
											{
												anchorNode->rightChild = inorderReplace;
											}

										else
											{
												anchorNode->leftChild = inorderReplace;
											}
									}

								delete recursiveRemoveNode;

								count--;

								return true;
							}

						//return inorderReplace;
					}






				//Otherwise, if the Node being REMOVED does NOT have a LEFT Child, but it has a RIGHT Child, move RIGHT and then go AS FAR LEFT AS POSSIBLE
				else if (recursiveRemoveNode->rightChild != NULL)
					{
						//Variables to help retain any information FOLLOWING the Removal Node's INORDER Predecessor
						Node* inorderReplace = recursiveRemoveNode->rightChild;
						Node* inorderReplacePrev = inorderReplace;

						//Move as far LEFT as possible from the Node to IMMEDIATE RIGHT from Removal Node
						while (inorderReplace->leftChild != NULL)
							{
								inorderReplacePrev = inorderReplace;

								inorderReplace = inorderReplace->leftChild;
							}

						//DID NOT MOVE LEFT AT ALL
						//If Moving LEFT was NOT POSSIBLE
						if (inorderReplace == inorderReplacePrev)
							{
								//Retain Removal Node's LEFT Subtree
								inorderReplace->leftChild = recursiveRemoveNode->leftChild;

								//If Removal Node is ROOT, make the INORDER PREDECESSOR the new Root
								if (recursiveRemoveNode == root)
									{
										root = inorderReplace;
									}

								//Otherwise, if Removal Node is NOT ROOT, decide which Subtree of the Node that PRECEDED Removal Node starts with Removal Node's INORDER PREDECESSOR
								else
									{
										if (anchorNode->data < inorderReplace->data)
											{
												anchorNode->rightChild = inorderReplace;
											}

										else
											{
												anchorNode->leftChild = inorderReplace;
											}
									}

								delete recursiveRemoveNode;

								count--;

								return true;
							}

						//MOVED LEFT AS FAR AS POSSIBLE
						//INORDER Replacement for Removal Node has NO RIGHT Subtree
						else if (inorderReplace->rightChild == NULL)
							{
								//Node PRECEDING the Removal Node's INORDER PREDECESSOR must now have a NULL LEFT Child
								inorderReplacePrev->leftChild = NULL;

								//cout << "Inorder Replace Prev: " << inorderReplacePrev->data << endl;
								//cout << "Inorder Replace Prev Right Child: " << inorderReplacePrev->rightChild->data << endl;

								//Retain Removal Node's Left AND Right Subtrees
								inorderReplace->leftChild = recursiveRemoveNode->leftChild;

								inorderReplace->rightChild = recursiveRemoveNode->rightChild;

								//If Removal Node is ROOT, make the INORDER PREDECESSOR the new Root
								if (recursiveRemoveNode == root)
									{
										root = inorderReplace;
									}

								//Otherwise, if Removal Node is NOT ROOT, decide which Subtree of the Node that PRECEDED Removal Node starts with Removal Node's INORDER PREDECESSOR
								else
									{
										if (anchorNode->data < inorderReplace->data)
											{
												anchorNode->rightChild = inorderReplace;
											}

										else
											{
												anchorNode->leftChild = inorderReplace;
											}
									}

								delete recursiveRemoveNode;

								count--;

								return true;
							}

						//MOVED LEFT AS FAR AS POSSIBLE
						//INORDER Replacement for Removal Node HAS a Right Subtree
						else
							{
								//Node PRECEDING the Removal Node's INORDER PREDECESSOR must have a Left Child that is Replacement Node's RIGHT CHILD
								inorderReplacePrev->leftChild = inorderReplace->rightChild;

								//Retain Removal Node's Left AND Right Subtrees
								inorderReplace->leftChild = recursiveRemoveNode->leftChild;

								inorderReplace->rightChild = recursiveRemoveNode->rightChild;

								//If Removal Node is ROOT, make the INORDER PREDECESSOR the new Root
								if (recursiveRemoveNode == root)
									{
										root = inorderReplace;
									}

								//Otherwise, if Removal Node is NOT ROOT, decide which Subtree of the Node that PRECEDED Removal Node starts with Removal Node's INORDER PREDECESSOR
								else
									{
										if (anchorNode->data < inorderReplace->data)
											{
												anchorNode->rightChild = inorderReplace;
											}

										else
											{
												anchorNode->leftChild = inorderReplace;
											}
									}

								delete recursiveRemoveNode;

								count--;

								return true;
							}

						//return inorderReplace;
					}

			}





		//If submitted data < Current Node Value, Move LEFT to find correct Node to REMOVE
		else if (data < recursiveRemoveNode->data)
			{
				anchorNode = recursiveRemoveNode;

				recursiveRemoveNode = recursiveRemoveNode->leftChild;

				recursiveRemove (recursiveRemoveNode , anchorNode , data);
			}

		//If submitted data > Current Node Value, Move RIGHT to find correct Node to REMOVE
		else
			{
				anchorNode = recursiveRemoveNode;

				recursiveRemoveNode = recursiveRemoveNode->rightChild;

				recursiveRemove (recursiveRemoveNode , anchorNode , data);
			}
	}





/*
* Attempts to remove the given int from the BST tree
*
* @return true if successfully removed
* @return false if remove is unsuccessful(i.e. the int is not in the tree)
*/
bool BST::remove(int data)
	{
		//cout << "Entered REMOVE in BST" << endl;

		//If submitted data IS in Tree, traverse the Tree to REMOVE the correct Node
		if (valueInTree(root , data) == true)
			{
				//Recursively locate and REMOVE the correct Node
				if (count == 1)
					{
						delete root;

						root = NULL;

						count--;

						//cout << "Count: " << count << endl;

						return true;
					}

				if (count >1)
					{
						return recursiveRemove (root , NULL , data);
					}
			}
		//return true;

		//Otherwise, submitted data is NOT in Tree
		else
			{
				//cout << "Value is NOT in Tree" << endl;

				return false;
			}
	}








/*
* Removes all nodes from the tree, resulting in an empty tree.
*/
void BST::clear()
	{
		while (count > 0 && root != NULL)
			{
				remove(root->data);
			}
	}

