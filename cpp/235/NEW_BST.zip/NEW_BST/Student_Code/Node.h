/*
 * Node.h
 *
 *  Created on: Mar 7, 2015
 *      Author: heypono
 */

#ifndef NODE_H_
#define NODE_H_

#include "NodeInterface.h"
//#include <int>

//class Node : public NodeInterface
struct Node : public NodeInterface
	{
		//protected:
			int data;
			Node *leftChild;
			Node *rightChild;
			//Node *parent;

		//public:
			Node(int dataIn , Node *leftChildIn , Node *rightChildIn /*, Node *parentIn*/) : data(dataIn) , leftChild(leftChildIn) , rightChild(rightChildIn) /*, parent(parentIn)*/
				{

				};

			~Node()
				{

				};




			/*
			* Returns the data that is stored in this node
			*
			* @return the data that is stored in this node.
			*/
			virtual int getData();

			/*
			* Returns the left child of this node or null if it doesn't have one.
			*
			* @return the left child of this node or null if it doesn't have one.
			*/
			virtual NodeInterface * getLeftChild();

			/*
			* Returns the right child of this node or null if it doesn't have one.
			*
			* @return the right child of this node or null if it doesn't have one.
			*/
			virtual NodeInterface * getRightChild();
	};





#endif /* NODE_H_ */
