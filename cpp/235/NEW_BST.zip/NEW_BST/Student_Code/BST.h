/*
 * BST.h
 *
 *  Created on: Mar 7, 2015
 *      Author: heypono
 */

#ifndef BST_H_
#define BST_H_


#include "BSTInterface.h"
#include "Node.h"
#include <sstream>
#include <iostream>
#include <string>


class BST : public BSTInterface
	{
		protected:
			Node* root;
			int count;

		public:
			BST() : root(NULL) , count(0)
				{

				};

			~BST()
				{

				};

			Node* getRoot ()
				{
					return root;
				}


			void printTree (Node* recursivePrintNode);



			bool valueInTree (Node* recursiveSearchNode , int data);



			bool recursiveInsert(Node* recursiveInsertNode , int data);



			bool recursiveRemove (Node* recursiveRemoveNode , Node* anchorNode , int data);



			Node* findInorderReplace(Node* recursiveRemoveNode);




			//Please note that the class that implements this interface must be made
			//of objects which implement the NodeInterface

			/*
			* Returns the root node for this tree
			*
			* @return the root node for this tree.
			*/
			virtual NodeInterface * getRootNode()
				{
					if (root != NULL)
						{
							return root;
						}

					else
						{
							return NULL;
						}
				};


			/*
			* Attempts to add the given int to the BST tree
			*
			* @return true if added
			* @return false if unsuccessful (i.e. the int is already in tree)
			*/
			virtual bool add(int data);

			/*
			* Attempts to remove the given int from the BST tree
			*
			* @return true if successfully removed
			* @return false if remove is unsuccessful(i.e. the int is not in the tree)
			*/
			virtual bool remove(int data);

			/*
			* Removes all nodes from the tree, resulting in an empty tree.
			*/
			virtual void clear();
	};


#endif /* BST_H_ */
