/*
 * Main.cpp
 *
 *  Created on: Mar 10, 2015
 *      Author: heypono
 */

#include "BST.h"
#include <iostream>

int userResponse;
int insertValue;
int removeValue;

BST testTree;

void menu();
void addToBST();
void printBST();
void removeBST();
void clearBST();
void quitBST();

int main()
	{
		menu();
	}





void menu()
	{
		while (userResponse != 5)
			{
				cout << "Main Menu" << endl;
				cout << "Enter what you want to do: (Only responses of 1 - 5 are VALID)" << endl << endl;
				cout << "Enter 1 to Add to BST: " << endl;
				cout << "Enter 2 to Print BST: " << endl;
				cout << "Enter 3 to Remove from BST: " << endl;
				cout << "Enter 4 to CLEAR BST: " << endl;
				cout << "Enter 5 to Quit: " << endl;

				cin >> userResponse;

				while (userResponse != 1 && userResponse != 2 && userResponse != 3 && userResponse != 4 && userResponse != 5)
					{
						cout << "Enter what you want to do: (Only responses of 1 - 5 are VALID)" << endl << endl;
						cout << "Enter 1 to Add to BST: " << endl;
						cout << "Enter 2 to Print BST: " << endl;
						cout << "Enter 3 to Remove from BST: " << endl;
						cout << "Enter 4 to CLEAR BST: " << endl;
						cout << "Enter 5 to Quit: " << endl;

						cin >> userResponse;
					}

				if (userResponse == 1)
					{
						addToBST();
					}

				else if (userResponse == 2)
					{
						printBST();
					}

				else if (userResponse == 3)
					{
						removeBST();
					}

				else if (userResponse == 4)
					{
						clearBST();
					}

				else
					{
						quitBST();
					}
			}
	}





void addToBST()
	{
		cout << "Enter a X > 0 to add: " << endl;

		cin >> insertValue;

		testTree.add(insertValue);

		cout << "Added the value into the TREE (in MAIN function)" << endl;

		return;
	}





void printBST()
	{
		if (testTree.getRoot() != NULL)
			{
				testTree.printTree(testTree.getRoot());
			}

		else
			{
				cout << "Tree is EMPTY" << endl;
				cout << "Returning to Main Menu" << endl << endl;
			}
	}





void removeBST()
	{
		cout << "Enter the DATA value you want to remove: " << endl;

		cin >> removeValue;

		testTree.remove(removeValue);

		cout << "Verifying Removal" << endl;

		if (testTree.getRoot() != NULL)
			{

				cout << "Root was NOT NULL" << endl;

				if (testTree.valueInTree(testTree.getRoot() , removeValue)==false)
					{
						cout << "Removed the value (" << removeValue << ") from the TREE (in MAIN function)" << endl;
					}
			}

		else
			{
				cout << "ROOT was Removed" << endl;
			}

		return;
	}





void clearBST()
	{
		if (testTree.getRoot() != NULL)
			{
				testTree.clear();
			}

		else
			{
				cout << "Tree is EMPTY (clear function)" << endl;
				cout << "Returning to Main Menu" << endl << endl;
			}
	}





void quitBST()
	{

	}

