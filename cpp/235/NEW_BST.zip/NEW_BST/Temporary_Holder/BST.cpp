/*
 * BST.cpp
 *
 *  Created on: Mar 9, 2015
 *      Author: heypono
 */



#include "BST.h"


BST::BST() : root(NULL)
	{

	}

BST::~BST()
	{

	}





/*
* Attempts to add the given int to the BST tree
*
* @return true if added
* @return false if unsuccessful (i.e. the int is already in tree)
*/
bool add(int data)
	{
		if (root == NULL)
			{

			}
	}

/*
* Attempts to remove the given int from the BST tree
*
* @return true if successfully removed
* @return false if remove is unsuccessful(i.e. the int is not in the tree)
*/
bool remove(int data)
	{

	}

/*
* Removes all nodes from the tree, resulting in an empty tree.
*/
void clear()
	{

	}
