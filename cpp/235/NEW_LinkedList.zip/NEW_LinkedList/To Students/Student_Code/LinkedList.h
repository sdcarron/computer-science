/*
 * LinkedList.h
 *
 *  Created on: Feb 11, 2015
 *      Author: heypono
 */

#ifndef LINKEDLIST_H_
#define LINKEDLIST_H_
#include "LinkedListInterface.h"
#include "Node.h"
#include <stdexcept>
//#include <cstdlib>//"NULL" is not recognized without including a library that defines "NULL" with #include (cstdlib is one library that defines it)

#include <iostream>

//using namespace std;

template <class typeT>

class LinkedList : public LinkedListInterface <typeT>
{
	private:
		Node<typeT>* head;
		Node<typeT>* tail;
		Node<typeT>* current;

		int numNodes;

	public:
		LinkedList(void) : head(NULL) , tail(NULL) , current(NULL) , numNodes(0)
			{
			};

		~LinkedList(void)
			{
				clear();

				head = NULL;
				tail = NULL;
				current = NULL;

				numNodes = 0;
			};

		void printList()
			{
				if (head != NULL)
					{
						current = head;

						while (current->next != NULL)
							{
								cout << current->data << " " << endl;

								current = current->next;
							}

						if (current->next == NULL)
							{
								cout << current->data << endl << endl;
							}
					}
			}

		bool valueInList(typeT value)
			{
				//cout << "Hit valueINLIST" << endl << endl;

				if (head == NULL)
					{
						cout << "Value is NOT already in list" << endl << endl;

						//current = NULL;
						return false;
					}


				//Node<typeT>* current = head;
				current = head;

				while (current->next != NULL)
					{
						if (current->data == value)
							{
								cout << "Hit value BEFORE end of list" << endl << endl;
								return true;
							}
						else
							{
								current = current->next;
							}
					}



				if (current->next == NULL)
					{
						if (current->data == value)
							{
								cout << "Hit value AT end of list" << endl << endl;

								return true;
							}

						else
							{
								cout << "Hit end of list, DID NOT find value" << endl << endl;
								return false;
							}
					}
			};

		/*
			insertHead

			A node with the given value should be inserted at the beginning of the list.

			Do not allow duplicate values in the list.
		 */
		void insertHead(typeT value)
			{
				if (head == NULL)
					{
						cout << "Inserting Head in EMPTY List" << endl << endl;

						head = new Node<typeT>(value, NULL , NULL);
						tail = head;

						numNodes++;

						cout << "Printing LIST AFTER adding new element: " << endl << endl;

						printList();
					}

				else if (head != NULL)// && valueInList(value) == false)
					{
						cout << "Inserting Head in NON EMPTY List" << endl << endl;
						cout << "Printing LIST BEFORE trying to add new element: " << endl << endl;

						printList();

						if (valueInList(value) == false)
							{
								cout << "Attempting to insert a node with value: " << value << "   at the HEAD" << endl << endl;

								Node<typeT>* nodeHead = new Node<typeT>(value , head , NULL);

								cout << "New Node's value: " << nodeHead->data << endl << endl;

								//if (head != NULL)
									//{
										head->prev = nodeHead;
									//}

								cout << "Successfully Assigned New Node as the PREVIOUS for the current Head" << endl << endl;

								head = nodeHead;

								cout << "Successfully Assigned New Node as the NEW Head" << endl << endl;
								//delete N;

								cout << "New Node DATA: " << head->data << "     New Node NEXT PTR: " << head->next->data << endl << endl;

								//freshInsert->setNext(head);
								//head = freshInsert;

								//delete freshInsert;
								//freshInsert = NULL;

								numNodes++;
							}

						cout << "Printing LIST AFTER trying to add new element: " << endl << endl;

						printList();
					}

				else
					{
						cout << "Value was already in list" << endl;
					}
			};

		/*
			insertTail

			A node with the given value should be inserted at the end of the list.

			Do not allow duplicate values in the list.
		 */
		void insertTail(typeT value)
			{
				if (tail == NULL)
					{
						cout << "Inserting Tail in EMPTY List" << endl << endl;

						tail = new Node<typeT>(value , NULL , NULL);
						head = tail;

						numNodes++;

						cout << "Printing List AFTER adding new element: " << endl << endl;

						printList();
					}

				else if (tail != NULL)// && valueInList(value) == false)
					{
						cout << "Inserting Tail in NON EMPTY List" << endl << endl;
						cout << "Printing List BEFORE trying to add new element: " << endl << endl;

						printList();

						if (valueInList(value) == false)
							{
								cout << "Attempting to insert a node with value: " << value << "   at the TAIL" << endl << endl;

								Node<typeT>* nodeTail = new Node<typeT>(value , NULL , tail);

								cout << "New Node's VALUE: " << nodeTail->data << endl << endl;

								//if (tail != NULL)
								//{
									//
									tail->next = nodeTail;
								//}

								cout << "Successfully Assigned NEW Node as the NEXT for the current Tail" << endl << endl;

								tail = nodeTail;

								cout << "Successfully Assigned NEW Node as the NEW Tail" << endl << endl;
								//delete N;

								//cout << "New Node DATA: " << tail->data << "     New Node NEXT PTR: " << tail->next->data << endl << endl;

								//freshInsert->setNext(head);
								//head = freshInsert;

								//delete freshInsert;
								//freshInsert = NULL;

								numNodes++;
							}

						cout << "Printing List AFTER trying to add new element: " << endl << endl;

						printList();
					}

				else
					{
						cout << "Value was already in list" << endl;
					}
			};

		/*
			insertAfter

			A node with the given value should be inserted immediately after the
			node whose value is equal to insertionNode.

			A node should only be added if the node whose value is equal to
			insertionNode is in the list. Do not allow duplicate values in the list.
		 */
		void insertAfter(typeT value, typeT insertionNode)
			{
				/*
				if (head == NULL)
					{
						insertHead(value);
					}
				*/
				cout << "Hit INSERT AFTER" << endl << endl;

				if (valueInList(insertionNode) == true && valueInList(value) == false)
					{
						current = head;

						while (current->data != insertionNode)
							{
								current = current->next;
							}

						/*
						if (current->next == NULL)
							{
								insertTail(value);

								return;
							}


						if (current->prev == NULL)
							{
								insertHead(value);

								return;
							}
						*/


						if (current->data == insertionNode)
							{
								if (current->next == NULL)
									{
										insertTail(value);

										return;
									}

								else
									{
										Node<typeT>* insertNode = new Node<typeT> (value , NULL , NULL);

										Node<typeT>* tempNode = current->next;

										insertNode->next = tempNode;
										current->next = insertNode;

										tempNode->prev = insertNode;
										insertNode->prev = current;

										//delete N;

										numNodes++;

										return;
									}
							}
						//current = NULL;
					}
			};

		/*
			remove

			The node with the given value should be removed from the list.

			The list may or may not include a node with the given value.
		 */
		void remove(typeT value)
			{
				if (valueInList(value) == true && numNodes > 0)
					{
						//The Node to be Removed is at the HEAD
						if (head->data == value )//&& head != NULL)
							{
								//cout << "Removing HEAD" << endl << endl;

								//cout << "Printing List BEFORE Removing HEAD: " << endl << endl;

								//printList();

								Node<typeT>* headRemove = head;

								//cout << "Successfully Assigned Head to be Removed" << endl << endl;

								if (head->next != NULL)
									{
										head = headRemove->next;
										head->prev = NULL;
									}


								else
									{
										head = NULL;
										//head->prev = NULL;
										//head->next = NULL;

										tail = NULL;
										//tail->prev = NULL;
										//tail->next = NULL;
									}


								//cout << "Successfully RE-Assigned Current Head to Node FOLLOWING Head to be Removed" << endl << endl;

								//cout << "Successfully Assigned NEW Current Head's PREVIOUS Pointer to NULL" << endl << endl;

								delete headRemove;

								numNodes--;

								//cout << "Printing List AFTER Removing Head: " << endl << endl;

								//printList();

								//cout << "Successfully Removed HEAD" << endl << endl;

								return;
							}


						//The Node to be Removed is at the TAIL
						else if (tail->data == value)
							{
								//cout << "Removing TAIL" << endl << endl;

								Node<typeT>* tailRemove = tail;

								if (tail->prev != NULL)
									{
										tail = tailRemove->prev;
										tail->next = NULL;
									}


								else
									{
										head = NULL;
										tail = NULL;
									}


								delete tailRemove;

								numNodes--;

								//cout << "Successfully Removed TAIL" << endl << endl;

								return;
							}



						//Otherwise the Node to be Removed is in the MIDDLE of the list or at the TAIL
						else
							{
								//cout << "Node to Remove is in MIDDLE of List" << endl << endl;

								current = head;

								//cout << "Searching for the Node to be Removed" << endl << endl;

								while (current->next->data != value)
									{
										current = current->next;
									}

								//cout << "Found Node to be Removed AND now creating TEMPORARY Pointer to that Node" << endl << endl;

								//cout << "Node to be Removed: " << current->next->data << endl << endl;

								//cout << "Node Value Passed INTO this function: " << value << endl << endl;

								//cout << "Printing List to Know the relationships AROUND Node to be removed: " << endl << endl;

								//printList();

								//MY Code is breaking Right AFTER this line... WHY?
								//cout << "Declaring a Temporary Pointer to Point at TARGET Node, which FOLLOWS Current Node" << endl << endl;

								//The program doesn't even REACH this line... WHY?
								//cout << "Target Node Value: " << current->next->data << endl << endl;

								Node<typeT>* midRemove = current->next;

								//cout << "Target Node Value: " << midRemove->data << endl << endl;



								//cout << "Beginning to Assign Pointers to Point AROUND the Node to be removed: " << endl << endl;

								current->next = current->next->next;

								//cout << "Node BEFORE the TARGET Node now points to: " << current->next->data << endl;

								current->next->prev = current;

								//cout << "Node AFTER the TARGET Node now points to: " << current->next->prev << endl << endl;

								//cout << "Severing the Pointers AROUND the Node to be Removed" << endl << endl;

								//midPrev->next = midNext;
								//midNext->prev = midPrev;

								//cout << "Successfully Severed Pointers AROUND the Node to be Removed" << endl << endl;

								delete midRemove;

								//current = NULL;

								numNodes--;

								cout << "Node Successfully Removed and Node Count decremented" << endl << endl;
							}
					}

				cout << "Remove Test. Number of Nodes now: " << numNodes << endl << endl;
			};

		/*
			clear

			Remove all nodes from the list.
		 */
		void clear()
			{

				while(head!=NULL){remove(head->data);}

				/*
				//If Head is NOT NULL, the List is NOT EMPTY, so Nodes can be Removed
				if (head!=NULL && numNodes > 0)
					{
						current = head;

						//Remove ALL Nodes from the Head to the Tail
						while (current->next != NULL)
							{
								Node<typeT>* nodeRemove = current;

								current = current->next;

								delete nodeRemove;

								numNodes--;
							}

						//Remove the Tail
						if (current->next == NULL)
							{
								//Node<typeT>* nodeRemove = current;

								//current = current->next;

								delete current;
								current = NULL;
								head = NULL;
								tail = NULL;

								numNodes--;
							}

					}
				*/

				cout << "Clear Test. Number of Nodes now: " << numNodes << endl << endl;


			};

		/*
			at

			Returns the value of the node at the given index. The list begins at
			index 0.

			If the given index is out of range of the list, throw an out of range exception.
		 */
		typeT at(int index)
			{
				//If Head is NULL or Index < 0, the Index is OUT OF RANGE
				if (head == NULL || index < 0)
					{
						throw std::out_of_range ("The index is out of range: Is the list EMPTY? Is the Index < 0?");
					}

				//Otherwise, TRAVERSE List until Index is reached OR END of List is reached BEFORE reaching Index
				else
					{
						int location = 0;

						current = head;

						while (location < index && current->next != NULL)
							{
								current = current->next;
								location++;
							}

						if (location == index)
							{
								//current = NULL;

								return current->data;
							}

						else
							{
								throw std::out_of_range ("The index is out of range: The submitted index is greater than the number of elements in the list.");
							}
					}
			};

		/*
			size

			Returns the number of nodes in the list.
		 */
		int size()
			{
				cout << "Size: " << numNodes << endl << endl;

				if (numNodes < 0)
					{
						numNodes = 0;
					}

						return numNodes;
			};
};



#endif /* LINKEDLIST_H_ */
