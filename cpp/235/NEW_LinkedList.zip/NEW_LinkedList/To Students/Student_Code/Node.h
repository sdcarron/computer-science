/*
 * Node.h
 *
 *  Created on: Feb 11, 2015
 *      Author: heypono
 */

#ifndef NODE_H_
#define NODE_H_
#include "LinkedList.h"

using namespace std;

template <class typeT>
//class Node
struct Node
	{
		//private:
			typeT data;

			Node *next;
			Node *prev;

		//public:
			Node (typeT dataIn , Node *nextIn , Node *prevIn) : data(dataIn) , next(nextIn) , prev(prevIn)
				{};

		/*
			~Node()
				{};

			void setNext (Node* nextNode)
				{
					next = nextNode;
				};

			void setPrev (Node* prevNode)
				{
					prev = prevNode;
				};

			Node* getNext ()
				{
					return next;
				};

			typeT getData ()
				{
					return data;
				};
		*/
	};




#endif /* NODE_H_ */
