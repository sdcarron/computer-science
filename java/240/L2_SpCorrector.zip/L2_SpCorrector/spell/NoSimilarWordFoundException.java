package spell;

//Without the "extends Exception" this produces an error stating:
//error: incompatible types: NoSimilarWordFoundException cannot be converted to Throwable
//	public static void main(String[] args) throws NoSimilarWordFoundException, IOException {
//	                                              ^
//NoSimilarWordFoundException.java:14: error: constructor Object in class Object cannot be applied to given types;
  //  super (message);
  //  ^
  //required: no arguments
//found: String
  //reason: actual and formal argument lists differ in length
//2 errors

public class NoSimilarWordFoundException extends Exception
{
  public NoSimilarWordFoundException ()
  {
    super ();
  }

  public NoSimilarWordFoundException (String message)
  {
    super (message);
  }
}
