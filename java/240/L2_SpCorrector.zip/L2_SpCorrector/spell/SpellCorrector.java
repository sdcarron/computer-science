package spell;

import java.util.Scanner;
import java.io.FileReader;

import java.io.File;

import java.io.IOException;

public class SpellCorrector implements ISpellCorrector
{
	public SpellCorrector ()
	{

	}


	public void useDictionary (String dictionaryFileName) throws IOException
	{
		try
		{
			File inFile = new File (dictionaryFileName);

			Scanner inReader = new Scanner (new FileReader (inFile));

			System.out.println ("Created the Scanner with the input file inside SpellCorrector");
		}

		catch (IOException fileCannotBeRead)
		{
			System.out.println ("File could not be read.");
		}
	}

	public String suggestSimilarWord (String inputWord) throws NoSimilarWordFoundException
	{
		String outputSuggestion = "";
		return outputSuggestion;
	}
}
