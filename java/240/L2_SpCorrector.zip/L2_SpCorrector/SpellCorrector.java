package spell2;

import java.util.Scanner;
import java.io.FileReader;
import java.io.File;

public class SpellCorrector implements ISpellCorrector
{
	public SpellCorrector ()
	{

	}


	public void useDictionary (String dictionaryFilename) throws IOException
	{
		try
		{
			File inFile = new File (dictionaryFileName);

			Scanner inReader = new Scanner (new FileReader (infile));

			System.out.println ("Created the Scanner with the input file inside SpellCorrector");
		}

		catch (IOException fileCannotBeRead)
		{
			System.out.println ("File could not be read.");
		}
	}

	public String suggestSimilarWord (String inputWord) throws NoSimilarWordFoundException
	{

	}
}
