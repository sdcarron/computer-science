package handle;



import java.io.*;
import java.net.*;
import com.sun.net.httpserver.*;

import com.google.gson.*;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

import model.User;
import request.LoadRequest;
import request.LoginRequest;
import request.RegisterRequest;

/**
 * Created by Steve on 3/4/2017.
 */
public class Coder
{
    private Gson d_Gson = new Gson ();

    public Coder ()
    {
    }




    public RegisterRequest decodeRegister (String registerRequestBodyString)
    {
        RegisterRequest registerRequest = new RegisterRequest ();

        try
        {
            registerRequest = d_Gson.fromJson (registerRequestBodyString, RegisterRequest.class);
        }

        catch (JsonSyntaxException e)
        {
            e.printStackTrace ();

            registerRequest.setEmail (null);
            registerRequest.setFirstName (null);
            registerRequest.setLastName (null);
            registerRequest.setUserName (null);
            registerRequest.setPassword (null);
            registerRequest.setGender (null);
        }

        return registerRequest;
        //return new RegisterRequest ();
    }




    public LoginRequest decodeLogin (String loginRequestBodyString)
    {
        LoginRequest loginRequest = new LoginRequest ();

        try
        {
            loginRequest = d_Gson.fromJson (loginRequestBodyString, LoginRequest.class);
        }

        catch (JsonSyntaxException e)
        {
            e.printStackTrace ();

            loginRequest.setPassword (null);
            loginRequest.setUserName (null);
        }

        return loginRequest;
    }



    public LoadRequest decodeLoad (String loadRequestBodyString)
    {
        LoadRequest loadRequest = new LoadRequest ();

        try
        {
            loadRequest = d_Gson.fromJson (loadRequestBodyString, LoadRequest.class);
        }

        catch (JsonSyntaxException e)
        {
            e.printStackTrace ();

            //loadRequest = new LoadRequest ();

            loadRequest.setUsers (null);
            loadRequest.setPersons (null);
            loadRequest.setEvents (null);
        }

        return loadRequest;
    }




    public String encodeResult (Object resultObject)
    {
        return d_Gson.toJson (resultObject);
    }
}
