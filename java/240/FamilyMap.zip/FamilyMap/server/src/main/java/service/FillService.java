package service;

import java.util.ArrayList;

import dao.DatabaseDAO;
import model.DataGenerator;
import model.Event;
import model.Person;
import model.User;
import request.FillRequest;
import result.FillResult;

/**
 * This class processes the FillRequest from the Server and submits it to the DAO
 */
public class FillService
{

  private DatabaseDAO fillDatabaseDAO = new DatabaseDAO();



  /**
   * This will take care of generating new ancestral data when a RegisterRequest is received
   */
  private DataGenerator generator = new DataGenerator ();


  /**
   * These will contain the data that is returned from the DataGenerator once the ancestral data has been generated
   * The data will THEN be passed to the appropriate DAOs
   */
  private User generatedUser = new User();
  private ArrayList<Person> generatedPersons = new ArrayList<>();
  private ArrayList<Event> generatedEvents = new ArrayList<> ();



  public FillService ()
  {
    //fillDatabaseDAO.openConnection ();
  }




  public void setPersons (ArrayList<Person> generatedPersons_submit)
  {
    this.generatedPersons = generatedPersons_submit;
  }



  public void setEvents (ArrayList<Event> generatedEvents_submit)
  {
    this.generatedEvents = generatedEvents_submit;
  }


  /**
   * Submit the FillRequest to DataGenerator which will pass it onto the DAOs
   * @param fillRequest_submit The FillRequest object
   * @return Message indicating success or failure
     */
  public FillResult fill (FillRequest fillRequest_submit)
  {
    fillDatabaseDAO.openConnection ();

    FillResult requestResult = new FillResult ();

    //Insert the generated Person and Event data into the database
    int[] insertedPersonEventCounts = fillDatabaseDAO.fillDatabase (fillRequest_submit.getUserName (), this.generatedPersons, this.generatedEvents);

    fillDatabaseDAO.closeConnection ();

    //requestResult.setPersonCount (insertedPersonEventCounts [0]);
    //requestResult.setEventCount (insertedPersonEventCounts [1]);
    requestResult.setSuccessMessage (insertedPersonEventCounts [0], insertedPersonEventCounts [1]);


    return requestResult;
  }
}
