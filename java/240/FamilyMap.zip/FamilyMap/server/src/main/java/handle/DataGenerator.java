package handle;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;
import java.util.UUID;

import model.Event;
import model.Location;
import model.LocationData;
import model.Person;
import model.User;
import request.RegisterRequest;

import com.google.gson.Gson;
import com.google.gson.Gson.*;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;
import com.google.gson.stream.JsonReader;

/**
 * Created by Steve on 3/4/2017.
 */
public class DataGenerator {
    private String[] m_FirstNames = {"Peter", "Christopher", "John", "Jordan", "Jared", "David", "Paul", "Jamie", "Graham",
            "Benjamin", "Phillip", "Gregory", "Ethan", "Ian", "Jackson", "Carson", "Howard", "Michael",
            "Sean", "Coty", "Jude", "Stephen"};

    private String maleFirstName = "";

    private String[] f_FirstNames = {"Shawna", "Courtni", "Deborah", "Susan", "Sunny", "Lorraine", "Carley", "Haley", "Alyssa",
            "Hannah", "Emily", "Bethany", "Rebecca", "Stacie", "Kari", "Amanda", "Abigail", "Melissa"};

    private String femaleFirstName = "";


    private String[] LastNames = {"Carron", "Cote", "Lovejoy", "Morgan", "Ward", "Stoddard", "Price", "Madsen", "Mitchell"};

    private String lastName = "";


    private String[] events = {"Birth", "Christening", "Baptism", "Death", "Marriage"};

    private String[] countries = {"USA", "England", "France", "Scotland", "Ireland", "Wales"};
    private String[] cities = {"Jefferson City", "Seattle", "Tacoma", "Denver", "London", "Paris", "Dublin", "Manti",
            "Salt Lake City", "Washington D.C."};





    private String descendantUserName = "";
    private int numGenerations;
    //private int generationCounter = 0;


    private Random randomIndexGenerator = new Random();
    private int randomIndex;


    private Person tempGenMale = null;
    private Person tempGenFemale = null;
    private Event tempGenEventMale = null;
    private Event tempGenEventFemale = null;


    private ArrayList<Person> generatedPersons = new ArrayList<>();
    private ArrayList<Event> generatedEvents = new ArrayList<>();

    private ArrayList<Person> generatedPersons2 = new ArrayList<>();
    private ArrayList<Event> generatedEvents2 = new ArrayList<>();


    //_______________________________________________________
    private String f_nameFile = "json" + File.separator + "fnames.json";
    private String m_nameFile = "json" + File.separator + "mnames.json";
    private String s_nameFile = "json" + File.separator + "snames.json";
    private String locationFile = "json" + File.separator + "locations.json";


    private LocationData locationData = null;
    private Location[] data = null;
    private Gson l_Gson = new Gson ();




    private Scanner generatorReader;
    private StringBuilder generatorBuilder = new StringBuilder();


    public DataGenerator ()
    {

        try
        {
            JsonReader reader = new JsonReader(new FileReader(locationFile));

            //String jsonString = reader.toString ();

            locationData = l_Gson.fromJson (reader, LocationData.class);

            data = locationData.getData ();
        }

        catch (FileNotFoundException e)
        {
            e.printStackTrace ();
        }

    }






    public void setDescendantUserName(String descendantUserName_submit) {
        this.descendantUserName = descendantUserName_submit;
    }


    public void generatePersons(int numGenerations_submit) {


        for (int i = 0; i < ((int) Math.pow(2, numGenerations_submit) - 1); i++) {
            randomIndex = randomIndexGenerator.nextInt(m_FirstNames.length);
            maleFirstName = m_FirstNames[randomIndex];

            randomIndex = randomIndexGenerator.nextInt(LastNames.length);
            lastName = LastNames[randomIndex];


            tempGenMale = createPerson(maleFirstName, lastName, "m");
            generatedPersons.add(tempGenMale);


            tempGenEventMale = createEvent(tempGenMale);
            generatedEvents.add(tempGenEventMale);


            randomIndex = randomIndexGenerator.nextInt(f_FirstNames.length);
            femaleFirstName = f_FirstNames[randomIndex];

            randomIndex = randomIndexGenerator.nextInt(LastNames.length);
            lastName = LastNames[randomIndex];

            tempGenFemale = createPerson(femaleFirstName, lastName, "f");
            generatedPersons.add(tempGenFemale);


            tempGenEventFemale = createEvent(tempGenFemale);
            generatedEvents.add(tempGenEventFemale);
        }
    }


    public void setNumGenerations(int numGenerations_submit) {
        this.numGenerations = numGenerations_submit;
    }


    public ArrayList<Person> getPersons2() {
        return this.generatedPersons2;
    }

    public ArrayList<Event> getEvents2()
    {
        return this.generatedEvents2;
    }



    public void generatePersons2 (Person currentChild, Event currentBirth, int generationCounter)
    {


        if (generationCounter > numGenerations)
        {
            return;
        }



        randomIndex = randomIndexGenerator.nextInt (m_FirstNames.length);
        maleFirstName = m_FirstNames [randomIndex];

        //randomIndex = randomIndexGenerator.nextInt (LastNames.length);
        //lastName = LastNames [randomIndex];


        Person currentFather = createPerson (maleFirstName, currentChild.getLastName (), "m");


        randomIndex = randomIndexGenerator.nextInt (data.length);
        Location fatherBirthBaptismLocation = data [randomIndex];
        Event fatherBirth = createBirth (currentFather, currentBirth.getYear () - 27, fatherBirthBaptismLocation);
        Event fatherBaptism = createBaptism (currentFather, currentBirth.getYear () - 19, fatherBirthBaptismLocation);

        randomIndex = randomIndexGenerator.nextInt (data.length);
        Location fatherMarriageLocation = data [randomIndex];
        Event fatherMarriage = createMarriage (currentFather, currentBirth.getYear () - 4, fatherMarriageLocation);
        //Location fatherMarriageLocation = locations[randomIndex];

        generatedEvents2.add (fatherBirth);
        generatedEvents2.add (fatherBaptism);
        generatedEvents2.add (fatherMarriage);

        generatePersons2 (currentFather, fatherBirth, generationCounter + 1);








        randomIndex = randomIndexGenerator.nextInt (f_FirstNames.length);
        femaleFirstName = f_FirstNames [randomIndex];

        randomIndex = randomIndexGenerator.nextInt (LastNames.length);
        lastName = LastNames [randomIndex];

        Person currentMother = createPerson (femaleFirstName, lastName, "f");

        randomIndex = randomIndexGenerator.nextInt (data.length);
        Location motherBirthBaptismLocation = data [randomIndex];
        Event motherBirth = createBirth (currentMother, currentBirth.getYear () - 24, motherBirthBaptismLocation);
        Event motherBaptism = createBaptism (currentMother, currentBirth.getYear () - 16, motherBirthBaptismLocation);



        Event motherMarriage = createMarriage (currentMother, currentBirth.getYear () - 4, fatherMarriageLocation);
        generatedEvents2.add (motherBirth);
        generatedEvents2.add (motherBaptism);
        generatedEvents2.add (motherMarriage);

        generatePersons2 (currentMother, motherBirth, generationCounter + 1);




        currentChild.setFather (currentFather.getPersonID ());
        currentChild.setMother (currentMother.getPersonID ());

        currentFather.setSpouse (currentMother.getPersonID ());
        currentMother.setSpouse (currentFather.getPersonID ());

        generatedPersons2.add (currentFather);
        generatedPersons2.add (currentMother);


    }




    private Event createBirth (Person currentOwner, int eventYear, Location eventLocation)
    {
        Event currentBirth = new Event ();
        currentBirth.setEventID (UUID.randomUUID ().toString ());
        currentBirth.setDescendant(descendantUserName);
        currentBirth.setYear (eventYear);
        currentBirth.setOwner(currentOwner.getPersonID ());
        currentBirth.setType (events [0]);


        currentBirth.setCity (eventLocation.getCity ());
        currentBirth.setCountry (eventLocation.getCountry ());
        currentBirth.setLatitude (eventLocation.getLatitude ());
        currentBirth.setLongitude (eventLocation.getLongitude ());

        return currentBirth;
    }

    private Event createBaptism (Person currentOwner, int eventYear, Location eventLocation)
    {
        Event currentBaptism = new Event ();
        currentBaptism.setEventID (UUID.randomUUID ().toString ());
        currentBaptism.setYear (eventYear);
        currentBaptism.setDescendant (descendantUserName);
        currentBaptism.setOwner (currentOwner.getPersonID ());
        currentBaptism.setType (events [2]);

        currentBaptism.setCity (eventLocation.getCity ());
        currentBaptism.setCountry (eventLocation.getCountry ());
        currentBaptism.setLatitude (eventLocation.getLatitude ());
        currentBaptism.setLongitude (eventLocation.getLongitude ());

        return currentBaptism;
    }

    private Event createMarriage (Person currentOwner, int eventYear, Location eventLocation)
    {
        Event currentMarriage = new Event ();
        currentMarriage.setEventID (UUID.randomUUID ().toString ());
        currentMarriage.setYear (eventYear);
        currentMarriage.setDescendant (descendantUserName);
        currentMarriage.setOwner (currentOwner.getPersonID ());
        currentMarriage.setType (events [4]);

        currentMarriage.setCity (eventLocation.getCity ());
        currentMarriage.setCountry (eventLocation.getCountry ());
        currentMarriage.setLatitude (eventLocation.getLatitude ());
        currentMarriage.setLongitude (eventLocation.getLongitude ());

        return currentMarriage;
    }




    private Person createPerson (String firstName_submit, String lastName_submit, String gender_submit)
    {
        String generatedPersonID = UUID.randomUUID ().toString ();

        Person generatedPerson = new Person ();
        generatedPerson.setPersonID (generatedPersonID);

        generatedPerson.setDescendant (this.descendantUserName);

        generatedPerson.setFirstName (firstName_submit);
        generatedPerson.setLastName (lastName_submit);

        generatedPerson.setGender (gender_submit);

        return generatedPerson;
    }





    private Event createEvent (Person tempGenPerson_submit)
    {
        String generatedEventID = UUID.randomUUID ().toString ();

        Event generatedEvent = new Event ();
        generatedEvent.setEventID (generatedEventID);

        generatedEvent.setOwner (tempGenPerson_submit.getPersonID ());

        generatedEvent.setDescendant (this.descendantUserName);


        double randomLatitude = randomIndexGenerator.nextGaussian () * (90.0);
        double randomLongitude = randomIndexGenerator.nextGaussian () * (180.0);
        generatedEvent.setLatitude (randomLatitude);
        generatedEvent.setLongitude (randomLongitude);


        randomIndex = randomIndexGenerator.nextInt (events.length);
        String randomType = events [randomIndex];
        generatedEvent.setType (randomType);


        randomIndex = randomIndexGenerator.nextInt (countries.length);
        String randomCountry = countries [randomIndex];

        randomIndex = randomIndexGenerator.nextInt (cities.length);
        String randomCity = cities [randomIndex];

        generatedEvent.setCountry (randomCountry);
        generatedEvent.setCity (randomCity);



        //Here I will generate the year for the current Event that is being created
        int placeholder = 2000;
        generatedEvent.setYear (placeholder);

        return generatedEvent;
    }





    public User generateRegisterUser (RegisterRequest registerRequest)
    {
        User registerUser = new User ();

        registerUser.setUserName (registerRequest.getUserName ());
        registerUser.setEmail (registerRequest.getEmail ());
        registerUser.setPassword (registerRequest.getPassword ());
        registerUser.setFirstName (registerRequest.getFirstName ());
        registerUser.setLastName (registerRequest.getLastName ());
        registerUser.setGender (registerRequest.getGender ());
        registerUser.setPersonID (UUID.randomUUID ().toString ());

        return registerUser;
    }





    public Person generateRegisterPerson (RegisterRequest registerRequest)
    {
        Person registerPerson = new Person ();

        //Is a registered User his/her own descendant?
        //registerPerson.setDescendant ("");
        registerPerson.setFirstName (registerRequest.getFirstName ());
        registerPerson.setLastName (registerRequest.getLastName ());
        registerPerson.setGender (registerRequest.getGender ());
        //registerPerson.setPersonID (UUID.randomUUID ().toString ());

        return registerPerson;
    }






    public ArrayList<Event> getEvents ()
    {
        return generatedEvents;
    }

    public ArrayList<Person> getPersons ()
    {
        return generatedPersons;
    }
}
