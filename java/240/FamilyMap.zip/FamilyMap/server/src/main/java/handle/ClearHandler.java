package handle;

import java.io.*;
import java.net.*;
import com.sun.net.httpserver.*;

import request.ClearRequest;
import result.ClearResult;
import service.ClearService;

/**
 * Created by Steve on 3/3/2017.
 */
public class ClearHandler implements HttpHandler
{
    private Coder clearCoder = new Coder ();

    public ClearHandler ()
    {}

    @Override
    public void handle (HttpExchange exchange)
    {


        if (exchange.getRequestMethod ().toLowerCase ().equals ("post"))
        {
            ClearRequest clearRequest = new ClearRequest ();

            ClearService clearRequestService = new ClearService();



            ClearResult clearResult = clearRequestService.clearDatabase (clearRequest);



            String responseData = encodeProcess (clearResult);

            responseProcess (responseData, exchange);
        }
    }





    public String encodeProcess (ClearResult clearResult)
    {
        String responseData = clearCoder.encodeResult (clearResult);

        return responseData;
    }




    private void responseProcess (String responseData, HttpExchange exchange)
    {
        try
        {
            exchange.sendResponseHeaders (HttpURLConnection.HTTP_OK, 0);



            OutputStream responseBody = exchange.getResponseBody ();

            writeResponse (responseData, responseBody);

            responseBody.close ();
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }
    }




    private void writeResponse (String responseData, OutputStream responseBody) throws IOException
    {
        OutputStreamWriter responseWriter = new OutputStreamWriter (responseBody);

        responseWriter.write (responseData);

        responseWriter.flush ();
    }
}
