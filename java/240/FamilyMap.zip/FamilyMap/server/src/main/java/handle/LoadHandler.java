package handle;



import java.io.*;
import java.net.*;
import java.util.Scanner;

import com.sun.net.httpserver.*;

import request.LoadRequest;
import result.LoadResult;
import service.LoadService;


/**
 * Created by Steve on 3/3/2017.
 */
public class LoadHandler implements HttpHandler
{
    Coder loadCoder = new Coder ();

    public LoadHandler ()
    {}

    @Override
    public void handle (HttpExchange exchange)
    {
        if (exchange.getRequestMethod ().toLowerCase().equals ("post"))
        {
            System.out.println ("Entered the Load Handler");

            /*
            InputStream requestBodyStream = exchange.getRequestBody ();

            Scanner inReader = new Scanner(requestBodyStream);

            StringBuilder requestBodyBuilder = new StringBuilder ();


            while (inReader.hasNextLine ())
            {
                requestBodyBuilder.append (inReader.nextLine ());
            }


            LoadRequest loadRequest = loadCoder.decodeLoad (requestBodyBuilder.toString ());
            */
            LoadRequest loadRequest = decodeProcess (exchange);

            LoadService loadService = new LoadService();
            LoadResult loadResult = loadService.load (loadRequest);



            String responseData = encodeProcess (loadResult);

            responseProcess (responseData, exchange);
        }
    }





    private LoadRequest decodeProcess (HttpExchange exchange)
    {
        InputStream requestBodyStream = exchange.getRequestBody ();

        Scanner inReader = new Scanner(requestBodyStream);

        StringBuilder requestBodyBuilder = new StringBuilder ();


        while (inReader.hasNextLine ())
        {
            requestBodyBuilder.append (inReader.nextLine ());
        }


        LoadRequest loadRequest = loadCoder.decodeLoad (requestBodyBuilder.toString ());

        return loadRequest;
    }




    private String encodeProcess (LoadResult loadResult)
    {
        String loadResultString = loadCoder.encodeResult (loadResult);

        return loadResultString;
    }




    private void responseProcess (String responseData, HttpExchange exchange)
    {
        try
        {
            exchange.sendResponseHeaders (HttpURLConnection.HTTP_OK, 0);



            OutputStream responseBody = exchange.getResponseBody ();

            writeResponse (responseData, responseBody);

            responseBody.close ();
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }
    }




    private void writeResponse (String responseData, OutputStream responseBody) throws IOException
    {
        OutputStreamWriter responseWriter = new OutputStreamWriter (responseBody);

        responseWriter.write (responseData);

        responseWriter.flush ();
    }
}
