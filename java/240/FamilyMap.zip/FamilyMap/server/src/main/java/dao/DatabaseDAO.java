package dao;

import model.AuthToken;
import model.Event;
import model.Person;
import model.User;
import request.LoadRequest;
import result.ClearResult;
import result.EventResult;
import result.FillResult;
import result.LoadResult;
import result.PersonResult;
import result.RegisterResult;


import java.sql.*;
import java.util.ArrayList;
import java.util.UUID;

/**
 * The DatabaseDAO class will house the SINGLE connection to the database, which will be shared by
 * DatabaseDAO and all of the other DAO classes which are contained WITHIN DatabaseDAO
 */
public class DatabaseDAO
{
    //These values are used to establish the database connection
    String dbFamilyMapName = "FamilyMap.sqlite";
    String connectionURL = "jdbc:sqlite:" + dbFamilyMapName;

    //The database connection is initially null
    Connection connection;




    //These will be used for the various specific interactions with the Database once/if connection is established
    AuthTokenDAO authDAO = new AuthTokenDAO ();
    EventDAO eventDAO = new EventDAO ();
    PersonDAO personDAO = new PersonDAO ();
    UserDAO userDAO = new UserDAO ();

    /**
     * In the DatabaseDAO constructor, load the drivers from the java database library
     * Then try to establish a connection to the database
     * If a connection is successfully established, create the 4 Database Tables, if they do not already exist
     */
  public DatabaseDAO ()
  {
      //Load the JDBC java database drivers
      /*
      try
      {
          final String driver = "org.sqlite.JDBC";
          Class.forName (driver);
      }

      catch(ClassNotFoundException e)
      {
          System.out.println ("Error: Class was not found");

          e.printStackTrace ();
      }
           */

      //
      try
      {
          //Attempt to establish connection with the database
          //connection = DriverManager.getConnection (connectionURL);

          //Set AutoCommit to false to help with cases of needing to rollback transactions, etc
         // connection.setAutoCommit (false);
          openConnection ();




          Statement stmtTableBatch = connection.createStatement ();


          //PreparedStatement stmtAuthTokenTable = null;
          String sqlAuthTokenTable = "create table if not exists AuthToken (a_authID text not null primary key, a_username text not null);";
          //stmtAuthTokenTable = connection.prepareStatement (sqlAuthTokenTable);
          //stmt.executeUpdate ();
          stmtTableBatch.addBatch (sqlAuthTokenTable);


          //PreparedStatement stmt = null;
          String sqlUserTable = "create table if not exists User (u_username text not null primary key, u_password text not null, u_email text not null, u_firstname text not null, u_lastname text not null, u_personID text not null);";
          //stmt = connection.prepareStatement (sqlUserTable);
          //stmt.executeUpdate ();
          stmtTableBatch.addBatch (sqlUserTable);



          String sqlEventTable = "create table if not exists Event (e_eventID text not null primary key, e_username text not null, e_personID text not null, e_latitude real not null, e_longitude real not null, e_country text not null, e_city text not null, e_type text not null, e_year integer not null);";
          stmtTableBatch.addBatch (sqlEventTable);
          //stmt.executeUpdate ();

          //connection.commit ();

          String sqlPersonTable = "create table if not exists Person (p_personID text not null primary key, p_firstname text not null, p_lastname text not null, p_gender text not null, p_username text not null, p_fatherID text, p_motherID text, p_spouseID text);";
          stmtTableBatch.addBatch (sqlPersonTable);
          //stmt.executeUpdate ();

          //connection.commit ();

          stmtTableBatch.executeBatch ();

          /*
          if (stmtTableBatch == null)
          {
              System.out.println ("PreparedStatement 'stmt' is null");
          }

          int preparedStatementExecutionResult = stmtTableBatch.executeUpdate ();

          if (preparedStatementExecutionResult == 1)
          {
              System.out.println ("AuthToken Database Table created succesfully");
          }

          else
          {
              System.out.println ("AuthToken Database Table FAILED to create");

              System.out.println ("PreparedStatement execution result: stmt.executeUpdate () == " + preparedStatementExecutionResult);
          }
          */


          //Commit the SQL execution
          //connection.commit ();
          closeConnection ();

          //Close the Database connection
          //connection.close ();
      }

      catch (SQLException e)
      {
        System.out.println ("Connection failed to establish");
      }

      /*
      finally
      {

          try
          {
              connection.close ();
          }
          catch (SQLException e)
          {
              e.printStackTrace ();
          }

      }
      */
  }


    public void createTables ()
    {
        try
        {
            Statement stmtTableBatch = connection.createStatement();


            //PreparedStatement stmtAuthTokenTable = null;
            String sqlAuthTokenTable = "create table if not exists AuthToken (a_authID text not null primary key, a_username text not null);";
            //stmtAuthTokenTable = connection.prepareStatement (sqlAuthTokenTable);
            //stmt.executeUpdate ();
            stmtTableBatch.addBatch(sqlAuthTokenTable);


            //PreparedStatement stmt = null;
            String sqlUserTable = "create table if not exists User (u_username text not null primary key, u_password text not null, u_email text not null, u_firstname text not null, u_lastname text not null, u_personID text not null);";
            //stmt = connection.prepareStatement (sqlUserTable);
            //stmt.executeUpdate ();
            stmtTableBatch.addBatch(sqlUserTable);


            String sqlEventTable = "create table if not exists Event (e_eventID text not null primary key, e_username text not null, e_personID text not null, e_latitude real not null, e_longitude real not null, e_country text not null, e_city text not null, e_type text not null, e_year integer not null);";
            stmtTableBatch.addBatch(sqlEventTable);
            //stmt.executeUpdate ();

            //connection.commit ();

            String sqlPersonTable = "create table if not exists Person (p_personID text not null primary key, p_firstname text not null, p_lastname text not null, p_gender text not null, p_username text not null, p_fatherID text, p_motherID text, p_spouseID text);";
            stmtTableBatch.addBatch(sqlPersonTable);
            //stmt.executeUpdate ();

            //connection.commit ();

            stmtTableBatch.executeBatch();
        }

        catch (SQLException e)
        {
            e.printStackTrace ();

            System.out.println ("CreateTables Database");
        }
    }





    public boolean closeConnection ()
    {
        boolean connectionCloseStatus = false;

        try
        {
            connection.commit ();

            connection.close ();

            connection = null;

            connectionCloseStatus = true;
        }

        catch (SQLException e)
        {
            System.out.println ("Close Database Connection Unsuccessful");
        }

        return connectionCloseStatus;
    }






    public void openConnection ()
    {
        System.out.println ("Entered the DatabaseDAO openConnection");

        try
        {
            final String driver = "org.sqlite.JDBC";
            Class.forName (driver);
        }

        catch(ClassNotFoundException e)
        {
            System.out.println ("Error: Class was not found");

            e.printStackTrace ();
        }


        try
        {
            //Attempt to establish connection with the database
            connection = DriverManager.getConnection(connectionURL);

            //Set AutoCommit to false to help with cases of needing to rollback transactions, etc
            connection.setAutoCommit(false);

            System.out.println ("Looks like the openConnection function successfully called in DatabaseDAO");
        }

        catch (SQLException e)
        {
            System.out.println ("Connection Failed to Open in DatabaseDAO openConnection");
        }
    }







    public AuthTokenDAO dbGetAuthDAO ()
    {
        return authDAO;
    }

    public EventDAO dbGetEventDAO ()
    {
        return eventDAO;
    }

    public PersonDAO dbGetPersonDAO ()
    {
        return personDAO;
    }

    public UserDAO dbGetUserDAO ()
    {
        return userDAO;
    }


    /**
     * This method will clear ALL information form the Database
     * @return Object with message of either SUCCESS or an Error
     */
  public boolean clearDatabase ()
  {
      boolean databaseClearStatus = false;

      //openConnection ();

      try
      {
          Statement clearStatement = connection.createStatement ();

          String sqlEventTableDrop = "drop table if exists Event;";
          String sqlAuthTokenTableDrop = "drop table if exists AuthToken;";
          String sqlPersonTableDrop = "drop table if exists Person;";
          String sqlUserTableDrop = "drop table if exists User;";

          clearStatement.execute (sqlEventTableDrop);
          clearStatement.execute (sqlAuthTokenTableDrop);
          clearStatement.execute (sqlPersonTableDrop);
          clearStatement.execute (sqlUserTableDrop);

          //connection.commit ();

          System.out.println ("Clear Database: datbase clear successful");

          databaseClearStatus = true;
      }

      catch (SQLException e)
      {
          e.printStackTrace ();

          System.out.println ("Clear Database: sql execution failed");
      }

    //closeConnection ();

    return databaseClearStatus;
  }







    /**
     * This method will FILL the Database ancestral information for the submitted USERNAME
     * @param generatedPersons_submit ArrayList of Person objects to be inserted into databse
     * @param generatedEvents_submit ArrayList of Event objects to be inserted into database
     * @return Object with message of either SUCCESS or an Error
     */
  public int[] fillDatabase (String username_submit, ArrayList<Person> generatedPersons_submit, ArrayList<Event> generatedEvents_submit)
  {
      personDAO.deletePersons (username_submit);
      eventDAO.deleteEvents (username_submit);

      int insertedPersonCount = 0;
      int insertedEventCount = 0;

      for (int i=0; i<generatedPersons_submit.size (); i++)
      {
          if (personDAO.createPerson (generatedPersons_submit.get (i)) == true)
          {
              insertedPersonCount++;
          }
      }

      for (int j=0; j<generatedEvents_submit.size (); j++)
      {
          if (eventDAO.createEvent (generatedEvents_submit.get (j)) == true)
          {
              insertedEventCount++;
          }
      }

      int[] insertedPersonEventCounts = {insertedPersonCount, insertedEventCount};

      return insertedPersonEventCounts;
  }

    /**
     * This method will FILL the Database ancestral information for the submitted USERNAME
     * @param userName_submit USERNAME to generate/insert ancestral data for
     * @return Object with message of either SUCCESS or an Error
     */
  public FillResult fillDatabase (String userName_submit)
  {
    return new FillResult ();
  }



    /**
     * This method will FILL the Database ancestral information for the submitted USERNAME
     * @param loadUser User Objects with information for data to be loaded into the Database
     * @param loadPerson Person Objects with information for data to be laoded into the Database
     * Wparam loadEvent Event Objects with information for data to be loaded into the Database
     * @return Object with message of either SUCCESS or an Error
     */
  public int[] loadDatabase (ArrayList<User> loadUser, ArrayList<Person> loadPerson, ArrayList<Event> loadEvent)
  {
      clearDatabase ();

      //need to create tables again right here
      createTables ();

      int loadUserCount = 0;
      int loadPersonCount = 0;
      int loadEventCount = 0;

      for (int i=0; i<loadUser.size (); i++)
      {
          if (userDAO.createUser (loadUser.get (i)) == true)
          {
              loadUserCount++;
          }
      }

      for (int j=0; j<loadPerson.size (); j++)
      {
          if (personDAO.createPerson (loadPerson.get (j)) == true)
          {
              loadPersonCount++;
          }
      }

      for (int k=0; k<loadEvent.size (); k++)
      {
          if (eventDAO.createEvent (loadEvent.get (k)) == true)
          {
              loadEventCount++;
          }
      }


      int[] loadUserPersonEventCounts = {loadUserCount, loadPersonCount, loadEventCount};



    return loadUserPersonEventCounts;
  }


    /**
     * This class interacts with the Database as an Authentication Token Service
     */
  public class AuthTokenDAO
  {
      /**
       * The Authentication Token to be manipulated with respect to the Database begins as null
       */
    private AuthToken currentAuthToken = null;


      /**
       * @param currentAuthToken_submit Constructor receives an Authentication Token argument
       */
    public AuthTokenDAO (AuthToken currentAuthToken_submit)
    {
      this.currentAuthToken = currentAuthToken_submit;
    }

      /**
       * Constructor receives NO argument
       */
    public AuthTokenDAO ()
    {

    }




    public AuthToken getCurrentAuthToken ()
    {
      return this.currentAuthToken;
    }

    public void setCurrentAuthToken (AuthToken currentAuthToken_submit)
    {
        if (currentAuthToken_submit != null)
        {
            this.currentAuthToken = currentAuthToken_submit;
        }

    }


      /**
       * Creates the CURRENT Authentication Token within the Database
       * @return Message indicating success or failure
       */
    public boolean createAuthToken (String a_username, AuthToken authToken_submit)
    {
        String createDatabaseAuthTokenString = "";
        boolean createDatabaseAuthTokenBool = false;

        try
        {
            String sqlUserNamePresent = "select * from User where u_username = '" + a_username + "';";

            Statement usernamePresent = connection.createStatement ();
            ResultSet usernameVerifyRS = usernamePresent.executeQuery (sqlUserNamePresent);

            if (usernameVerifyRS.toString ().length () > 0)
            {
                String authtokenID = authToken_submit.getAuthID ();

                String sqlAuthTokenCreate= "insert into AuthToken values (? ,?);";

                PreparedStatement authtokenCreate = connection.prepareStatement (sqlAuthTokenCreate);


                authtokenCreate.setString (1, authtokenID);
                authtokenCreate.setString (2, a_username);
                authtokenCreate.addBatch ();


                //connection.setAutoCommit (false);
                authtokenCreate.executeBatch ();
                //connection.setAutoCommit (true);

                createDatabaseAuthTokenBool = true;
                System.out.println ("Create Database AuthToken Successful for authID = " + authtokenID + " and a_username = " + a_username);
            }
        }

        catch (SQLException e)
        {
            System.out.println ("Create AuthToken: Create AuthToken failed for a_username = " + a_username);

            e.printStackTrace ();
        }


        //return createDatabaseAuthTokenString;
        return createDatabaseAuthTokenBool;
    }







      public boolean verifyAuthToken (String authID_string)
      {
          boolean verifyDatabaseAuthTokenBool = false;

          try
          {
              String sqlVerifyAuthToken = "select a_authID from AuthToken where a_authID = '" + authID_string + "';";

              Statement verifyAuthToken = connection.createStatement ();

              ResultSet verifyAuthTokenResultSet = verifyAuthToken.executeQuery (sqlVerifyAuthToken);

              if (verifyAuthTokenResultSet.getString ("a_authID").length () > 0)
              {
                  verifyDatabaseAuthTokenBool = true;

                  System.out.println ("Verify Database AuthToken  Successful for authID = " + authID_string);
              }
          }

          catch (SQLException e)
          {
              e.printStackTrace ();

              System.out.println ("Verify AuthToken: SQL execution failed for authID = " + authID_string);
          }

          return verifyDatabaseAuthTokenBool;
      }

      /**
       * Deletes the CURRENT Authentication Token from the Database
       * @return Message indicating the success or failure
       */
    public boolean deleteAuthToken ()
    {
        boolean deleteDatabaseAuthTokenBool = false;

        try
        {
            String sqlDeleteAuthToken = "delete from AuthToken where a_authID = '" + this.currentAuthToken.getAuthID().toString () + "';";

            Statement deleteAuthToken = connection.createStatement ();

            deleteAuthToken.execute (sqlDeleteAuthToken);

            deleteDatabaseAuthTokenBool = true;
        }

        catch (SQLException e)
        {
            e.printStackTrace ();

            System.out.println ("Delete AuthToken: SQL execution failed");
        }

        return deleteDatabaseAuthTokenBool;
    }


      /**
       * This retrieves the desired AuthToken that is linked to the submitted username
       * @param a_authIDString This is the AuthTokenID that is linked to the desired AuthToken
       * @return This is the most recently created AuthToken that is associated with the submitted username
       */
      public String getUserName (String a_authIDString)
      {
          //AuthToken usernameAuthToken = null;
          String username = "";

          try
          {
              String sqlGetAuthToken = "select a_username from AuthToken where a_authID ='" + a_authIDString + "';";

              Statement getAuthToken = connection.createStatement ();

              ResultSet usernameAuthIDResultSet = getAuthToken.executeQuery (sqlGetAuthToken);

              username = usernameAuthIDResultSet.getString ("a_username");

              //UUID usernameAuthID = UUID.fromString (usernameAuthIDString);
              //usernameAuthToken = new AuthToken (usernameAuthID);
          }

          catch (SQLException e)
          {
              e.printStackTrace ();

              System.out.println ("GetUserName AuthToken: SQL execution failed");
          }

          return username;
      }
  }






    /**
     * This class interacts with the Database as an Event Service
     */
  public class EventDAO
  {
      /**
       * The Event begins as null
       */
    private Event currentEvent = null;


      /**
       * The constructor is given an Event argument
       * @param currentEvent_submit The Event that is to be manipulated with respect to the Database
       */
    public EventDAO (Event currentEvent_submit)
    {
      this.currentEvent = currentEvent_submit;

        /*
        try
        {
            connection = DriverManager.getConnection (connectionURL);
        }
        catch(SQLException e)
        {
            e.printStackTrace ();

            System.out.println ("Create Event: Connection failed to establish");
        }
        */
    }

      /**
       * The constructor expects no argument
       */
    public EventDAO ()
    {
        /*
        try
        {
            connection = DriverManager.getConnection (connectionURL);
        }
        catch(SQLException e)
        {
            e.printStackTrace ();

            System.out.println ("Create Event: Connection failed to establish");
        }
        */
    }




    public Event getCurrentEvent ()
    {
      return this.currentEvent;
    }

    public void setCurrentEvent (Event currentEvent_submit)
    {
        if (currentEvent_submit != null)
        {
            this.currentEvent = currentEvent_submit;
        }
    }


      /**
       * Creates the CURRENT Event within the Database
       * @return Message indicating success or failure
       */
    public boolean createEvent (Event createEvent_submit)
    {
        boolean createDatabaseEventBool = false;
        String createDatabaseEventString = "";

        //The authID comes from the EventRequest object, not the Event object
        String authID = "";

        String eventID = createEvent_submit.getEventID ();
        String eventUserName = createEvent_submit.getDescendant ();
        String eventPersonID = createEvent_submit.getOwner ();
        double eventLatitude = createEvent_submit.getLatitude ();
        double eventLongitude = createEvent_submit.getLongitude ();
        String eventCountry = createEvent_submit.getCountry ();
        String eventCity = createEvent_submit.getCity ();
        String eventType = createEvent_submit.getType ();
        int eventYear = createEvent_submit.getYear ();


        if (eventID == null)
        {
            //createDatabaseEventResult.setMessageIndex (1);
        }

        else if (authID == null)
        {
            //createDatabaseEventResult.setMessageIndex (0);
        }

        else if (eventCountry == null || eventCity == null || eventType == null)
        {
            //createDatabaseEventResult.setMessageIndex (2);
        }

        else
        {
            String sqlEventCreate = "insert into Event values (?, ?, ?, ?, ?, ?, ?, ?, ?);";


            PreparedStatement eventCreate = null;

            try
            {
                eventCreate = connection.prepareStatement (sqlEventCreate);

                eventCreate.setString (1, eventID.toString ());
                eventCreate.setString (2, eventUserName);
                eventCreate.setString (3, eventPersonID);
                eventCreate.setDouble (4, eventLatitude);
                eventCreate.setDouble (5, eventLongitude);
                eventCreate.setString (6, eventCountry);
                eventCreate.setString (7, eventCity);
                eventCreate.setString (8, eventType);
                eventCreate.setInt (9, eventYear);

                //eventCreate.addBatch ();

                //connection.setAutoCommit (false);
                //eventCreate.executeBatch ();
                //connection.setAutoCommit (true);

                eventCreate.execute ();

                createDatabaseEventBool = true;

                //System.out.println ("Create Database Event Successful for eventID: " + this.currentEvent.getEventID ().toString ());
                /*
                if (eventCreate.executeBatch ())
                {
                    connection.commit ();

                    createDatabaseEventString = "Create Database Event Successful";
                    //createDatabaseEventResult.setMessageIndex (2);
                }

                else
                {
                    System.out.println ("eventCreate.executeUpdate () returned 0");
                }
                */
            }
            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("Create Event: SQL execution failed");
            }

            /*
            finally
            {
                try
                {
                    connection.close ();
                }
                catch (SQLException e)
                {
                    e.printStackTrace ();
                }

            }
            */

        }

        return createDatabaseEventBool;
    }

      /**
       * Deletes the CURRENT Event from the Database
       * @return Message indicating success or failure
       */
    public boolean deleteEvents (String e_username)
    {
        boolean deleteDatabaseEventBool = false;
        String deleteDatabaseEventString = "";

        try
        {
            String sqlEventDelete = "delete from Event where e_username =?;";

            PreparedStatement eventDelete = connection.prepareStatement (sqlEventDelete);

            eventDelete.setString (1, e_username);

            eventDelete.execute ();




            deleteDatabaseEventBool = true;

            System.out.println ("Delete Database Event successful for e_username = " + e_username);

            eventDelete.close ();

            //System.out.println ("Delete Event: successfully deleted event where e_username = " + e_username);
        }

        catch (SQLException e)
        {
            e.printStackTrace ();

            System.out.println ("Delete Event: Failed to delete Event where e_username = " + e_username);
        }





      return deleteDatabaseEventBool;
    }


      /**
       * This retrieves ALL Event information linked to a given username
       * @param e_username Username linked to the desired Event information
       * @return ArrayList of Event Objects that were linked to the submitted username
       */
      public ArrayList <Event> getEvents (String e_username)
      {
          ArrayList<Event> getEventsResultList = new ArrayList<> ();

          try
          {
              String sqlSelectEventsAll = "select * from Event where e_username ='" + e_username + "';";

              Statement selectEventsAll = connection.createStatement ();

              ResultSet selectEventsAllResultSet = selectEventsAll.executeQuery (sqlSelectEventsAll);

              while (selectEventsAllResultSet.next ())
              {
                    String eventIDString = selectEventsAllResultSet.getString ("e_eventID");
                    String descendantUserName = selectEventsAllResultSet.getString ("e_username");
                    String ownerPersonIDString = selectEventsAllResultSet.getString ("e_personID");
                    double latitude = selectEventsAllResultSet.getDouble ("e_latitude");
                    double longitude = selectEventsAllResultSet.getDouble ("e_longitude");
                    String country = selectEventsAllResultSet.getString ("e_country");
                    String city = selectEventsAllResultSet.getString ("e_city");
                    String type = selectEventsAllResultSet.getString ("e_type");
                    int year = selectEventsAllResultSet.getInt ("e_year");

                    //UUID eventID = UUID.fromString (eventIDString);
                    //UUID personID = UUID.fromString (ownerPersonIDString);

                    Event currentResultEvent = new Event (eventIDString, descendantUserName, ownerPersonIDString, latitude, longitude, country, city, type, year);


                    getEventsResultList.add (currentResultEvent);
              }
          }

          catch (SQLException e)
          {
              e.printStackTrace ();

              System.out.println ("GetEvents EventDAO: SQL execution failed");
          }


          return getEventsResultList;
      }


      /**
       * This retrieves the Event linked to the desired eventID
       * @param e_eventID This is the eventID that is linked to the desired Event object
       * @return This is the desired Event object
       */
      public Event getEvent (String e_eventID)
      {
          Event getEventResult = null;

          try
          {
                String sqlSelectEventSpecific = "select * from Event where e_eventID ='" + e_eventID + "';";

                Statement selectEventSpecific = connection.createStatement ();

                ResultSet selectEventSpecificResultSet = selectEventSpecific.executeQuery (sqlSelectEventSpecific);

                String eventIDString = selectEventSpecificResultSet.getString ("e_eventID");
                String descendantUserName = selectEventSpecificResultSet.getString ("e_username");
                String ownerPersonIDString = selectEventSpecificResultSet.getString ("e_personID");
                double latitude = selectEventSpecificResultSet.getDouble ("e_latitude");
                double longitude = selectEventSpecificResultSet.getDouble ("e_longitude");
                String country = selectEventSpecificResultSet.getString ("e_country");
                String city = selectEventSpecificResultSet.getString ("e_city");
                String type = selectEventSpecificResultSet.getString ("e_type");
                int year = selectEventSpecificResultSet.getInt ("e_year");


                //UUID eventID = UUID.fromString (eventIDString);
                //UUID ownerPersonID = UUID.fromString (ownerPersonIDString);

                getEventResult = new Event (eventIDString, descendantUserName, ownerPersonIDString, latitude, longitude, country, city, type, year);


          }

          catch (SQLException e)
          {
              e.printStackTrace ();

              System.out.println ("GetEvent EventDAO: SQL execution failed");
          }

          return getEventResult;
      }






      public Event getBirthEvent (String e_personID)
      {
          Event getEventResult = null;

          try
          {
              String sqlSelectEventSpecific = "select * from Event where e_personID ='" + e_personID + "' and e_type = 'Birth';";

              Statement selectEventSpecific = connection.createStatement ();

              ResultSet selectEventSpecificResultSet = selectEventSpecific.executeQuery (sqlSelectEventSpecific);


              if (selectEventSpecificResultSet.next ())
              {
                  String eventIDString = selectEventSpecificResultSet.getString ("e_eventID");
                  String descendantUserName = selectEventSpecificResultSet.getString ("e_username");
                  String ownerPersonIDString = selectEventSpecificResultSet.getString ("e_personID");
                  double latitude = selectEventSpecificResultSet.getDouble ("e_latitude");
                  double longitude = selectEventSpecificResultSet.getDouble ("e_longitude");
                  String country = selectEventSpecificResultSet.getString ("e_country");
                  String city = selectEventSpecificResultSet.getString ("e_city");
                  String type = selectEventSpecificResultSet.getString ("e_type");
                  int year = selectEventSpecificResultSet.getInt ("e_year");


                  //UUID eventID = UUID.fromString (eventIDString);
                  //UUID ownerPersonID = UUID.fromString (ownerPersonIDString);

                  getEventResult = new Event (eventIDString, descendantUserName, ownerPersonIDString, latitude, longitude, country, city, type, year);
              }

          }

          catch (SQLException e)
          {
              e.printStackTrace ();

              System.out.println ("GetBirthEvent EventDAO: SQL execution failed");
          }

          return getEventResult;
      }
  }












    /**
     * This class interacts with the Database as a Person service
     */
    public class PersonDAO
    {
        /**
         * The Person object to be manipulated with respect to the Database begins as null
         */
        private Person currentPerson = null;


        /**
         * The constructor expects a Person object argument
         * @param currentPerson_submit The Person object to be manipulated with respect to the Database
         */
        public PersonDAO (Person currentPerson_submit)
        {
            this.currentPerson = currentPerson_submit;

            /*
            try
            {
                connection = DriverManager.getConnection (connectionURL);
            }
            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("Create Person: Connection failed to establish");
            }
            */
        }

        /**
         * The constructor expects no argument
         */
        public PersonDAO ()
        {
            /*
            try
            {
                connection = DriverManager.getConnection (connectionURL);
            }
            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("Create Person: Connection failed to establish");
            }
            */
        }




        public Person getCurrentPerson ()
        {
            return this.currentPerson;
        }

        public void setCurrentPerson (Person currentPerson_submit)
        {
            if (currentPerson_submit != null)
            {
                this.currentPerson = currentPerson_submit;
            }
        }


        /**
         * Creates the CURRENT Person object within the Database
         * @return Message indicating success or failure
         */
        public boolean createPerson (Person createPerson_submit)
        {
            boolean createDatabasePersonBool = false;
            String createDatabasePersonString = "";

            String personID = createPerson_submit.getPersonID ();
            String personDescendantUserName = createPerson_submit.getDescendant ();
            String personFirstName = createPerson_submit.getFirstName ();
            String personLastName = createPerson_submit.getLastName ();
            String personGender = createPerson_submit.getGender ();

            String personFatherID = "";
            String personMotherID = "";
            String personSpouseID = "";

            if (createPerson_submit.getFather () != null)
            {
                personFatherID = createPerson_submit.getFather ();
            }

            if (createPerson_submit.getMother () != null)
            {
                personMotherID = createPerson_submit.getMother ();
            }

            if (createPerson_submit.getSpouse () != null)
            {
                personSpouseID = createPerson_submit.getSpouse ();
            }


            String sqlPersonCreate = "insert into Person values (?, ?, ?, ?, ?, ?, ?, ?);";

            PreparedStatement personCreate = null;

            try
            {
                personCreate = connection.prepareStatement (sqlPersonCreate);

                personCreate.setString (1, personID);
                personCreate.setString (2, personFirstName);
                personCreate.setString (3, personLastName);
                personCreate.setString (4, personGender);
                personCreate.setString (5, personDescendantUserName);
                personCreate.setString (6, personFatherID);
                personCreate.setString (7, personMotherID);
                personCreate.setString (8, personSpouseID);

                //personCreate.addBatch ();

                //connection.setAutoCommit (false);
                //personCreate.executeBatch ();
                //connection.setAutoCommit (true);
                personCreate.execute ();

                createDatabasePersonBool = true;

                System.out.println ("Create Database Person Successful for personID = " + createPerson_submit.getPersonID () + " with firstname = " + createPerson_submit.getFirstName () + " and lastname = " + createPerson_submit.getLastName ());
                /*
                if (personCreate.executeUpdate () != 0)
                {
                    createDatabasePersonString = "Create Database Person Successful";
                }
                */
            }

            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("Create Person: SQL execution failed");
            }

            /*
            finally
            {
                try
                {
                    connection.close ();
                }
                catch (SQLException e)
                {
                    e.printStackTrace ();
                }
            }
            */

            return createDatabasePersonBool;
        }

        /**
         * Deletes the CURRENT Person object from the Database
         * @return Message indicating success or failure
         */
        public boolean deletePersons (String user_name)
        {
            boolean deleteDatabasePersonBool = false;
            String deleteDatabasePersonString = "";

            try
            {
                Statement personDelete = connection.createStatement ();

                String sqlPersonDelete = "delete from Person where p_username = '" + user_name + "';";

                personDelete.executeUpdate (sqlPersonDelete);

                deleteDatabasePersonBool = true;

                System.out.println ("Delete Database Person successful for p_username = " + user_name);

                //System.out.println ("Delete Person: successfully deleted Person where p_username = " + user_name);
            }

            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("Delete Person: Failed to delete Person where p_username = " + user_name);
            }

            return deleteDatabasePersonBool;
        }


        /**
         * This retrieves the Person data linked to the desired username
         * @param p_username Username linked to the desired Person data
         * @return ArrayList that holds Person objects witht the desired Person data
         */
        public ArrayList <Person> getPersons (String p_username)
        {
            ArrayList getPersonsResultList = new ArrayList<> ();

            try
            {
                String sqlSelectPersonsAll = "select * from Person where p_username = '" + p_username + "';";

                Statement selectPersonsAll = connection.createStatement ();

                ResultSet selectPersonsAllResultSet = selectPersonsAll.executeQuery (sqlSelectPersonsAll);

                while (selectPersonsAllResultSet.next ())
                {
                    String personIDString = selectPersonsAllResultSet.getString ("p_personID");
                    String firstName = selectPersonsAllResultSet.getString ("p_firstname");
                    String lastName = selectPersonsAllResultSet.getString ("p_lastname");
                    String gender = selectPersonsAllResultSet.getString ("p_gender");
                    String descendantUserName = selectPersonsAllResultSet.getString ("p_username");
                    String fatherIDString = selectPersonsAllResultSet.getString ("p_fatherID");
                    String motherIDString = selectPersonsAllResultSet.getString ("p_motherID");
                    String spouseIDString = selectPersonsAllResultSet.getString ("p_spouseID");


                    //UUID personID = UUID.fromString (personIDString);
                    //UUID fatherID = UUID.fromString (fatherIDString);
                    //UUID motherID = UUID.fromString (motherIDString);
                    //UUID spouseID = UUID.fromString (spouseIDString);

                    Person currentResultPerson = new Person (personIDString, firstName, lastName, gender, descendantUserName, fatherIDString, motherIDString, spouseIDString);

                    getPersonsResultList.add (currentResultPerson);
                }
            }

            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("GetPersons PersonDAO: SQL execution failed");
            }

            return getPersonsResultList;
        }


        /**
         * This gets the Person linked to the desired personID
         * @param p_personID This is the personID that represents the desired Person object
         * @return The desired Person object
         */
        public Person getPerson (String p_personID)
        {
            Person getPersonResult = null;

            try
            {
                String sqlSelectPersonSpecific = "select * from Person where p_personID = '" + p_personID + "';";

                Statement selectPersonSpecific = connection.createStatement ();

                ResultSet selectPersonSpecificResultSet = selectPersonSpecific.executeQuery (sqlSelectPersonSpecific);

                String personIDString = selectPersonSpecificResultSet.getString ("p_personID");
                String firstName = selectPersonSpecificResultSet.getString ("p_firstname");
                String lastName = selectPersonSpecificResultSet.getString ("p_lastname");
                String gender = selectPersonSpecificResultSet.getString ("p_gender");
                String descendantUserName = selectPersonSpecificResultSet.getString ("p_username");
                String fatherIDString = selectPersonSpecificResultSet.getString ("p_fatherID");
                String motherIDString = selectPersonSpecificResultSet.getString ("p_motherID");
                String spouseIDString = selectPersonSpecificResultSet.getString ("p_spouseID");


                //UUID personID = UUID.fromString (personIDString);
                //UUID fatherID = UUID.fromString (fatherIDString);
                //UUID motherID = UUID.fromString (motherIDString);
                //UUID spouseID = UUID.fromString (spouseIDString);

                getPersonResult = new Person (personIDString, firstName, lastName, gender, descendantUserName, fatherIDString, motherIDString, spouseIDString);
            }

            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("GetPerson PersonDAO: SQL execution failed");
            }

            return getPersonResult;
        }
    }












    /**
     * This class interacts with the Database as a User service
     */
    public class UserDAO
    {
        /**
         * The User to be manipulated with respect to the Database begins as null
         */
        private User currentUser = null;


        /**
         * The constructor expects a User object argument
         * @param currentUser_submit The User to be manipulated with respect to the Database
         */
        public UserDAO (User currentUser_submit)
        {

            this.currentUser = currentUser_submit;

            /*
            try
            {
                connection = DriverManager.getConnection (connectionURL);
            }
            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("Create User: Connection failed to establish");
            }
            */
        }

        /**
         * The constructor expects no User object argument
         */
        public UserDAO ()
        {
            /*
            try
            {
                connection = DriverManager.getConnection (connectionURL);
            }
            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("Create User: Connection failed to establish");
            }
            */
        }




        public User getCurrentUser ()
        {
            return this.currentUser;
        }

        public void setCurrentUser (User currentUser_submit)
        {
            if (currentUser_submit != null)
            {
                this.currentUser = currentUser_submit;
            }
        }


        /**
         * Creates the CURRENT User object within the Database
         * @return Message indicating success or failure
         */
        public boolean createUser (User createUser_submit)
        {
            boolean createDatabaseUserBool = false;
            String createDatabaseUserString = "";

            String userName = createUser_submit.getUserName ();
            String userPassword = createUser_submit.getPassword ();
            String userEmail = createUser_submit.getEmail ();
            String userFirstName = createUser_submit.getFirstName ();
            String userLastName = createUser_submit.getLastName ();
            String userPersonID = createUser_submit.getPersonID ().toString ();


            String sqlUserCreate = "insert into User values (?, ?, ?, ?, ?, ?);";

            PreparedStatement userCreate = null;

            try
            {
                userCreate = connection.prepareStatement (sqlUserCreate);

                userCreate.setString (1, userName);
                userCreate.setString (2, userPassword);
                userCreate.setString (3, userEmail);
                userCreate.setString (4, userFirstName);
                userCreate.setString (5, userLastName);
                userCreate.setString (6, userPersonID);

                userCreate.addBatch ();


                //connection.setAutoCommit (false);
                userCreate.executeBatch ();
                //connection.setAutoCommit (true);

                createDatabaseUserBool = true;

                System.out.println ("Create Database User Successful for username = " + createUser_submit.getUserName () + " with firstname = " + createUser_submit.getFirstName () + " and lastname = " + createUser_submit.getLastName ());
            }

            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("Create User: SQL execution failed");
            }

            /*
            finally
            {
                try
                {
                    connection.close ();
                }
                catch (SQLException e)
                {
                    e.printStackTrace ();
                }
            }
            */
            return createDatabaseUserBool;
        }

        /**
         * Retrieves the CURRENT User object from the Database
         * @return Mesasge indicating success or failure
         */
        public boolean verifyUser (String username_submit)
        {
            boolean verifyDatabaseUsernameBool = false;

            try
            {
                System.out.println ("Trying to verify username: " + username_submit + "inside UserDAO");

                String sqlVerifyUsername = "select * from User where u_username = '" + username_submit + "';";

                System.out.println ("Trying to set up connection for verifying username");

                Statement verifyUsername = connection.createStatement ();

                System.out.println ("Set up connection for verifying username");

                ResultSet verifyUsernameResultSet = verifyUsername.executeQuery (sqlVerifyUsername);

                if (verifyUsernameResultSet.next () == false)
                {
                    return verifyDatabaseUsernameBool;
                }

                if (verifyUsernameResultSet.getString ("u_username").length () > 0)
                {
                    verifyDatabaseUsernameBool = true;

                    System.out.println ("Verify Username (UserDAO) Successful for username = " + username_submit);
                }
            }

            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("Verify Username (UserDAO): SQL failed for username = " + username_submit);
            }


            return verifyDatabaseUsernameBool;
        }







        public boolean verifyUserPassword (String username_submit, String password_submit)
        {
            boolean verifyUserPasswordBool = false;

            try
            {
                String sqlVerifyUserPassword = "select u_password from User where u_username = '" + username_submit + "';";

                Statement verifyUserPassword = connection.createStatement ();

                ResultSet verifyUserPasswordResultSet = verifyUserPassword.executeQuery (sqlVerifyUserPassword);

                if (verifyUserPasswordResultSet.getString ("u_password").equals (password_submit))
                {
                    verifyUserPasswordBool = true;

                    System.out.println ("Verify User Password: Verification Successful for username = " + username_submit + " and password = " + password_submit);
                }
            }

            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("Verify User Password: SQL execution failed for username = " + username_submit + " and password = " + password_submit);
            }


            return verifyUserPasswordBool;
        }






        public String selectUserPersonID (String username_submit)
        {
            String selectUserPersonIDString = "";

            try
            {
                String sqlSelectUserPersonID = "select * from User where u_username = '" + username_submit + "';";

                Statement selectUserPersonID = connection.createStatement ();

                ResultSet selectUserPersonIDResultSet = selectUserPersonID.executeQuery (sqlSelectUserPersonID);

                if (selectUserPersonIDResultSet.getString ("u_personID").length () > 0)
                {
                    selectUserPersonIDString = selectUserPersonIDResultSet.getString ("u_personID");
                }
            }

            catch (SQLException e)
            {
                e.printStackTrace ();

                System.out.println ("Select User PersonID: SQL execution failed for username = " + username_submit);
            }

            return selectUserPersonIDString;
        }
    }
}
