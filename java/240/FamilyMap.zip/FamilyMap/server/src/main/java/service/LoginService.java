package service;

import java.util.UUID;

import dao.DatabaseDAO;
import dao.DatabaseDAO.AuthTokenDAO;
import dao.DatabaseDAO.UserDAO;

import model.AuthToken;
import request.LoginRequest;
import result.LoginResult;

/**
 * This class processes the LoginRequest from the Server and submits it to the DAO
 */
public class LoginService
{

  DatabaseDAO loginDatabaseDAO = new DatabaseDAO ();
  AuthTokenDAO a_loginDatabaseDAO = loginDatabaseDAO.dbGetAuthDAO ();
  UserDAO u_loginDatabaseDAO = loginDatabaseDAO.dbGetUserDAO ();

  public LoginService ()
  {

  }


  /**
   * Submit the LoginRequest object to the DAO
   * @param loginRequest_submit The LoginRequest object
   * @return Message indicating success or failure
     */
  public LoginResult login (LoginRequest loginRequest_submit)
  {
    loginDatabaseDAO.openConnection ();

    String loginAuthIDString = UUID.randomUUID ().toString ();
    AuthToken loginAuthToken = new AuthToken (loginAuthIDString);


    a_loginDatabaseDAO.createAuthToken (loginRequest_submit.getUserName (), loginAuthToken);


    String loginUserPersonID = u_loginDatabaseDAO.selectUserPersonID (loginRequest_submit.getUserName ());

    loginDatabaseDAO.closeConnection ();

    LoginResult requestResult = new LoginResult (loginAuthIDString, loginRequest_submit.getUserName (), loginUserPersonID);



    return requestResult;
  }
}
