package service;

import dao.DatabaseDAO;
import request.ClearRequest;
import result.ClearResult;

/**
 * This class processes the ClearRequest from the Server and submits it to the DAO
 */
public class ClearService
{
  DatabaseDAO clearDatabaseDAO = new DatabaseDAO ();



  public ClearService ()
  {

  }


  /**
   * Submit the ClearRequest object to the DAO
   * @param clearRequest_submit The ClearRequest object to be sent to the DAO
   * @return Message indicating success or failure
     */
  public ClearResult clearDatabase (ClearRequest clearRequest_submit)
  {
    clearDatabaseDAO.openConnection ();

    boolean clearDatabaseStatus = clearDatabaseDAO.clearDatabase ();

    clearDatabaseDAO.closeConnection ();

    ClearResult requestResult = new ClearResult ();

    if (clearDatabaseStatus == true)
    {
      String successMessage = "Clear successful.";

      requestResult.setSuccessMessage (successMessage);
    }

    else
    {
      String errorMessage = "Clear unsuccessful.";

      requestResult.setErrorMessage (errorMessage);
    }

    return requestResult;
  }
}
