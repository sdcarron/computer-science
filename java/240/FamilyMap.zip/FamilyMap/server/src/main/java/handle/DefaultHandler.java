package handle;


import java.io.*;
import java.net.*;
import java.util.Scanner;

import com.sun.net.httpserver.*;
/**
 * Created by Steve on 3/1/2017.
 */
public class DefaultHandler implements HttpHandler
{
    @Override
    public void handle (HttpExchange exchange)
    {
        boolean success = false;

        System.out.println ("Entered the Default Handler");

        Scanner inReader;

        StringBuilder responseData = new StringBuilder ();

        try
        {
            if (exchange.getRequestMethod ().toLowerCase ().equals ("get"))
            {



                //Headers requestHeaders = exchange.getRequestHeaders ();

                /* Checking for Authorization will be important for the 'person', 'event', and 'login'
                if (requestHeaders.containsKey ("Authorization"))
                {
                    String authToken = requestHeaders.getFirst ("Authorization");


                }
                */

                //String responseData = "";
                String defaultURI = exchange.getRequestURI ().toString ();

                String responseFileName = "HTML";

                if (defaultURI.equals ("/"))
                {
                    responseFileName += File.separator + "index.html";
                }

                else
                {
                    String[] uriArray = defaultURI.split ("/");

                    for (int i=0; i<uriArray.length; i++)
                    {
                        responseFileName += File.separator + uriArray[i] ;
                    }
                }

                exchange.sendResponseHeaders (HttpURLConnection.HTTP_OK, 0);



                inReader = new Scanner(new BufferedInputStream (new FileInputStream (responseFileName)));

                //responseData = new StringBuilder ();

                while (inReader.hasNextLine ())
                {
                    responseData.append (inReader.nextLine () + "\n");
                }



                OutputStream responseBody = exchange.getResponseBody ();

                writeResponse (responseData.toString (), responseBody);

                responseBody.close ();

                success = true;
            }


            if (!success)
            {
                exchange.sendResponseHeaders (HttpURLConnection.HTTP_BAD_REQUEST, 0);
                exchange.getResponseBody ().close ();

                System.out.println ("Too bad. So sad. File Does Not Exist :*(");
            }
        }

        catch (IOException e)
        {
            //e.printStackTrace ();
            //Serve up the 404 page
            try
            {
                inReader = new Scanner(new BufferedInputStream(new FileInputStream("HTML/404.html")));

                while (inReader.hasNextLine ())
                {
                    responseData.append (inReader.nextLine ());
                }

                //exchange.sendResponseHeaders (HttpURLConnection.HTTP_OK, 0);

                OutputStream responseBody = exchange.getResponseBody ();

                writeResponse (responseData.toString (), responseBody);

                responseBody.close ();
            }

            catch (FileNotFoundException f)
            {

            }

            catch (IOException i)
            {

            }


            System.out.println ("Handle DefaultHandler: Response file access failed");
        }
    }





    private void writeResponse (String responseData, OutputStream responseBody) throws IOException
    {
        OutputStreamWriter responseWriter = new OutputStreamWriter (responseBody);

        responseWriter.write (responseData);

        responseWriter.flush ();
    }
}
