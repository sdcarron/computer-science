package dao;

import org.junit.*;

import java.util.UUID;

import model.AuthToken;
import model.Event;
import model.Person;
import model.User;

import static org.junit.Assert.*;

/**
 * Created by Steve on 2/18/2017.
 */
public class testDatabase {

    Event mostRecentCreatedEvent = new Event ();
    Person mostRecentCreatedPerson = new Person ();
    User mostRecentCreatedUser = new User ();

    @Test
    public void testDatabaseFunctions() {
        System.out.println("Hello World!");
    }


    @Test
    public void testDatabaseCreate ()
    {
        DatabaseDAO testDAO = new DatabaseDAO ();
    }

    @Test
    public void testDatabaseClear ()
    {
        DatabaseDAO testDAO = new DatabaseDAO ();

        testDAO.clearDatabase ();
    }


    @Test
    public void testDatabaseAuthTokenCreate ()
    {
        DatabaseDAO testDAO = new DatabaseDAO ();

        System.out.println ("Set the testDAO");

        DatabaseDAO.AuthTokenDAO testAuthTokenDAO = testDAO.authDAO;

        System.out.println ("Set the testAuthTokenDAO");

        String testAuthTokenSeriousID = UUID.randomUUID ().toString ();
        System.out.println ("Set the testAuthTokenSeriousID");
        AuthToken testAuthTokenSerious = new AuthToken ();
        System.out.println ("Created a new AuthToken Object called testAuthTokenSerious");
        testAuthTokenSerious.setAuthID (testAuthTokenSeriousID);
        System.out.println ("Set the authID of the AuthToken Object to be testAuthTokenSeriousID");

        testAuthTokenDAO.setCurrentAuthToken (testAuthTokenSerious);
        System.out.println ("Set the CURRENT AuthToken object of the testAuthTokenDAO to be testAuthTokenSerious (the new AuthToken Object");

        System.out.println ("Create New AuthToken Result: " + testAuthTokenDAO.createAuthToken ("a_username = sdc123", testAuthTokenSerious) + "\n\n");
    }


    @Test
    public void testDatabaseEventCreate ()
    {

        DatabaseDAO testDAO = new DatabaseDAO ();

        DatabaseDAO.EventDAO testEventDAO = testDAO.eventDAO;

        /*
        User testUserEmpty = new User ();
        Person testPersonEmpty = new Person();
        Event testEventEmpty = new Event ();
        testEventDAO.setCurrentEvent (testEventEmpty);

        System.out.println ("Create New Event Result: " + testEventDAO.createEvent () + "\n\n");

        /*
        User testUserNull = null;
        Event testEventNull = null;
        testEventDAO.setCurrentEvent (testEventNull);

        System.out.println ("Create New Event Result: " + testEventDAO.createEvent () + "\n\n");
        */

        String testUserSeriousID = UUID.randomUUID ().toString ();
        User testUserSerious = new User ("u_name=sdc123", "p_word=123456", "email=sdc123@gmail.com", "f_name=Steve", "l_name=Carron", "gender=m", testUserSeriousID);

        String testPersonSeriousID = UUID.randomUUID ().toString ();
        Person testPersonSerious = new Person (testPersonSeriousID, "f_name=Mike", "l_name=Peterson", "gender=m", testUserSerious.getUserName (), null, null, null);

        String testEventSeriousID = UUID.randomUUID ().toString ();
        Event testEventSerious = new Event (testEventSeriousID, testUserSerious.getUserName (), testPersonSerious.getPersonID (), 123, 34, "USA", "Yorkshire", "e_type=Death(Skydiving)", 1023);
        //testEventDAO.setCurrentEvent (testEventSerious);

        String altTestEventID_1 = UUID.randomUUID ().toString ();
        Event testEventAltUserName_1 = new Event (altTestEventID_1, "u_name=pbjXYZ", testPersonSerious.getPersonID (), 567, 8910, "Brazil", "Rio", "Birth", 1999);

        String altTestEventID_2 = UUID.randomUUID ().toString ();
        Event testEventAltUserName_2 = new Event (altTestEventID_2, "u_name=007", testPersonSerious.getPersonID (), 912, 3456, "China", "HK", "Marriage", 2056);
        /*
        mostRecentCreatedEvent.setEventID(testEventSeriousID);
        mostRecentCreatedEvent.setDescendant (testUserSerious.getUserName ());
        mostRecentCreatedEvent.setOwner (testPersonSerious.getPersonID ());
        mostRecentCreatedEvent.setLatitude (123);
        mostRecentCreatedEvent.setLongitude (34);
        mostRecentCreatedEvent.setCountry ("USA");
        mostRecentCreatedEvent.setCity ("Yorkshire");
        mostRecentCreatedEvent.setType ("e_type=Death(Skydiving)");
        mostRecentCreatedEvent.setYear (1023);
        */

        //System.out.println ("Create New Event Result: " + testEventDAO.createEvent (testEventSerious) + "\n\n");
        Assert.assertTrue (testEventDAO.createEvent (testEventSerious) == true);

        //System.out.println ("Create New Event Result: " + testEventDAO.createEvent (testEventAltUserName_1) + "\n\n");
        Assert.assertTrue (testEventDAO.createEvent (testEventAltUserName_1) == true);

        //System.out.println ("Create New Event Result: " + testEventDAO.createEvent (testEventAltUserName_2) + "\n\n");
        Assert.assertTrue (testEventDAO.createEvent (testEventAltUserName_2) == true);


        Assert.assertTrue (testEventDAO.getEvent (testEventSeriousID) != null);

        Assert.assertTrue (testEventDAO.getEvents (testUserSerious.getUserName ()) != null);

        Assert.assertTrue (testEventDAO.deleteEvents (testUserSeriousID) == true);



        //System.out.println ("Trying to delete event with id: " + mostRecentCreatedEvent.getEventID ().toString () + "\n\n");


        //testEventDAO.setCurrentEvent (mostRecentCreatedEvent);
        //testEventDAO.deleteEvent ();


        testDAO.closeConnection ();

        testDAO.closeConnection ();
    }

    @Test
    public void TestDatabaseEventDelete ()
    {

    }







    @Test
    public void TestDatabasePersonCreate ()
    {
        DatabaseDAO testDAO = new DatabaseDAO ();
        DatabaseDAO.PersonDAO testPersonDAO = testDAO.personDAO;

        String testUserSeriousID = UUID.randomUUID ().toString ();
        User testUserSerious = new User ("u_name=sdc123", "p_word=123456", "email=sdc123@gmail.com", "f_name=Steve", "l_name=Carron", "gender=m", testUserSeriousID);

        String testPersonSeriousID = UUID.randomUUID ().toString ();
        Person testPersonSerious = new Person (testPersonSeriousID, "f_name=Mike", "l_name=Peterson", "gender=m", testUserSerious.getUserName (), null, null, null);

        testPersonDAO.setCurrentPerson (testPersonSerious);

        //System.out.println ("Create New Person Result: " + testPersonDAO.createPerson (testPersonSerious) + "\n\n");
        Assert.assertTrue (testPersonDAO.createPerson (testPersonSerious) == true);

        Assert.assertTrue (testPersonDAO.getPerson (testPersonSeriousID) != null);

        Assert.assertTrue (testPersonDAO.getPersons (testUserSerious.getUserName ()) != null);

        Assert.assertTrue (testPersonDAO.deletePersons (testUserSerious.getUserName ()) == true);
    }

    @Test
    public void TestDatabasePersonDelete ()
    {

    }







    @Test
    public void TestDatabaseUserCreate ()
    {
        DatabaseDAO testDAO = new DatabaseDAO ();
        DatabaseDAO.UserDAO testUserDAO = testDAO.userDAO;

        String testUserRandomUserName = UUID.randomUUID ().toString ();
        String testUserSeriousID = UUID.randomUUID ().toString ();
        //User testUserSerious = new User ("a_username = sdc123", "p_word=123456", "email=sdc123@gmail.com", "f_name=Steve", "l_name=Carron", "gender=m", testUserSeriousID);
        User testUserSerious = new User (testUserRandomUserName, "p_word=123456", "email=sdc123@gmail.com", "f_name=Steve", "l_name=Carron", "gender=m", testUserSeriousID);


        String testUserAltUserName_1 = "u_name=pbjXYZ";
        String testUserAltUserName_1_ID = UUID.randomUUID ().toString ();

        User testUserAltUserName_1_Serious = new User (testUserAltUserName_1, "p_word=alfalfaROCKS", "email=hi@hi", "f_name=bilbo", "l_name=baggins", "gender=m", testUserAltUserName_1_ID);


        String testUserAlthUserName_2 = "u_name=007";
        String testUserAltUserName_2_ID = UUID.randomUUID ().toString ();

        User testUserAltUserName_2_Serious = new User (testUserAlthUserName_2, "p_word=heeeeeey", "email=wee@wee", "f_name=Jimothy", "l_name=Bondo", "gender=m", testUserAltUserName_2_ID);

        //testUserDAO.setCurrentUser (testUserSerious);

        //System.out.println ("Create New User Result: " + testUserDAO.createUser (testUserSerious) + "\n\n");
        Assert.assertTrue (testUserDAO.createUser (testUserSerious) == true);

        if (testDAO.closeConnection ())
        {
            System.out.println ("Close Database Connection Successful\n\n");
        }
    }

}
