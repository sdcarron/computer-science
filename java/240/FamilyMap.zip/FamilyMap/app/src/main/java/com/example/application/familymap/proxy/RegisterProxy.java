package com.example.application.familymap.proxy;

import request.RegisterRequest;
import result.RegisterResult;

/**
 * This class submits RegisterRequest objects to the server
 */
public class RegisterProxy
{
  public RegisterProxy ()
  {

  }


  /**
   * Submits the RegisterRequest object to the server
   * @param registerRequest_submit The RegisterRequest object
   * @return Message indicating success or failure
     */
  public RegisterResult register(RegisterRequest registerRequest_submit)
  {
    return new RegisterResult ();
  }
}
