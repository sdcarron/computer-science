package com.example.application.familymap.proxy;

import request.LoginRequest;
import result.LoginResult;

/**
 * This class submits LoginRequest objects to the server
 */
public class LoginProxy
{
  public LoginProxy ()
  {

  }


  /**
   * Submits the LoginRequest object to the server
   * @param loginRequest_submit The LoginRequest object
   * @return Message indicuating success or failure
     */
  public LoginResult login (LoginRequest loginRequest_submit)
  {
    return new LoginResult ();
  }
}
