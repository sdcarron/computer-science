package com.example.application.familymap.proxy;

import request.EventRequest;
import result.EventResult;

import java.io.*;
import java.net.*;

/**
 * This class submits EventRequest objects to the server
 */
public class EventProxy
{
    private EventRequest eventRequest = new EventRequest ();


  public EventProxy ()
  {

  }



    public void getEvents (String serverHost, String serverPort)
    {
        try
        {
            URL url = new URL ("http://" + serverHost + ":" + serverPort + "/event/");

            HttpURLConnection http = (HttpURLConnection) url.openConnection ();

            http.setRequestMethod ("GET");
            http.setDoOutput (false); //there is no request body

            http.addRequestProperty ("Authorization", "");
            http.addRequestProperty ("Accept", "application/json");

            http.connect ();

            if (http.getResponseCode () == HttpURLConnection.HTTP_OK)
            {
                InputStream responseBody = http.getInputStream ();

                String responseData = readResponse (responseBody);

                System.out.println (responseData);
            }

            else
            {
                System.out.println (http.getResponseMessage ());
            }
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }
    }




    public void getEvent (String serverHost, String serverPort)
    {}




    public String readResponse (InputStream responseBody) throws IOException
    {
        StringBuilder responseDataBuilder = new StringBuilder ();

        InputStreamReader responseReader = new InputStreamReader (responseBody);

        char[] buff = new char [1024];
        int len;

        while ((len = responseReader.read (buff)) > 0)
        {
            responseDataBuilder.append (buff, 0, len);
        }

        return responseDataBuilder.toString ();
    }



  public EventResult getEvent (EventRequest eventRequest_submit)
  {
    return new EventResult ();
  }
}
