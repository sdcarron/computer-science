package com.example.application.familymap.proxy;

import request.ClearRequest;
import result.ClearResult;

import java.io.*;
import java.net.*;

/**
 * This class submits ClearRequest objects to the server
 */
public class ClearProxy
{
    private ClearRequest clearRequest = new ClearRequest();

  public ClearProxy ()
  {

  }


  /**
   * Submits the ClearRequest object to the server
   * @param //clearRequest_submit request to clear the Database
   * @return Message indicating success or failure
     */
  /*
  public ClearResult clear (ClearRequest clearRequest_submit)
  {
    return new ClearResult ();
  }
  */

  public void clear (String serverHost, String serverPort)
  {

    try
    {
        URL url = new URL ("http://" + serverHost + ":" + serverPort + "/clear/");

        HttpURLConnection http = (HttpURLConnection) url.openConnection ();

        http.setRequestMethod ("POST");
        http.setDoOutput (false); //there is no request body

        http.connect ();


        OutputStream requestBody = http.getOutputStream ();

        String requestData = "";

        writeRequest (requestData, requestBody);

        requestBody.close ();


        if (http.getResponseCode () == HttpURLConnection.HTTP_OK)
        {
            //System.out.println ("Clear successful.");
            InputStream responseBody = http.getInputStream ();

            //String responseData = readResponse (responseBody);

            //System.out.println (responseData);
        }

        else
        {
            System.out.println ("Clear failed.");
        }
    }

    catch (IOException e)
    {
      e.printStackTrace ();
    }

  }




    public void writeRequest (String requestData, OutputStream requestBody) throws IOException
    {
        OutputStreamWriter requestWriter = new OutputStreamWriter (requestBody);

        requestWriter.write (requestData);

        requestWriter.flush ();
    }
}
