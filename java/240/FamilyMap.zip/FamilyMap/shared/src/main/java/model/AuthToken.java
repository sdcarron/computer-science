package model;

import java.util.UUID;

/**
 * This class is for creating AuthToken objects
 */
public class AuthToken
{
  /**
   * This is the Unique String that identifies the current Authentication Token
   */
  private String authID;


  /**
   * Constructor expects a String arguemnt that will be the Unique Identifier for the new AuthToken
   * @param authID_submit The Unique Identifier for creating the new AuthToken
     */
  public AuthToken (String authID_submit)
  {
    this.authID = authID_submit;
  }

  public AuthToken ()
  {

  }




  public String getAuthID ()
  {
    return this.authID;
  }

  public void setAuthID (String authID_submit)
  {
    this.authID = authID_submit;
  }

  public String getStringAuthID ()
  {
    return this.authID + "";
  }
}
