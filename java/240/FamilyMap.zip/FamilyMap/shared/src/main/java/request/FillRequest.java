 package request;

 /**
  * This class represents the Request to fill the database with information for a given Username
  */
 public class FillRequest
 {
   /**
    * userName is the UNIQUE username for the desired User
    * generations is the number of Generations of generated data for the desired User
    */
   private String userName = "";
   private int generations = 4; //Default number of generations is 4

   /**
    * The constructor expects 2 arguments
    * @param userName_submit UNIQUE username for the desired User
    * @param generations_submit Number of generations of data to create for the User
      */
   public FillRequest (String userName_submit, int generations_submit)
   {
     this.userName = userName_submit;
     this.generations = generations_submit;
   }

   /**
    * The constructor expects 1 argument (in thise case, 4 generations of data will be generated)
    * @param userName_submit UNIQUE username for the desired User
      */
   public FillRequest (String userName_submit)
   {
      this.userName = userName_submit;
   }


   public FillRequest ()
   {}




   public String getUserName ()
   {
     return this.userName;
   }




   public int getGenerations ()
   {
     return this.generations;
   }

   public void setGenerations (int generations_submit)
   {
     this.generations = generations_submit;
   }




   public String getAll ()
   {
     return "u_name: " + this.userName + "\ngenerations: " + this.generations + "\n\n";
   }
 }
