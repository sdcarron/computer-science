package model;

import java.util.UUID;

/**
 * This class creates new Event objects
 */
public class Event
{
  /**
   * These are the data members that are needed to represent an Event object
   * the eventID is a unique identifier for the Event object
   * the User is the User who is the DESCENDANT of the Person associated with the Event object
   * The Person is the individual associated with the Event object
   */
  private String eventID;
  private String descendant = null;
  private String personID = null;
  private double latitude;
  private double longitude;
  private String country = "";
  private String city = "";
  private String eventType = "";
  private int year;

  /**
   * Constructor expects 9 arguments
   * @param eventID_submit The Unique Identifier for the Event object
   * @param descendant_submit The Descendant of the Person object associated with the Event object
   * @param owner_submit The Person object who is associated with the Event object
   * @param latitude_submit Latitude coordinate of Event object
   * @param longitude_submit Longitude coordinate of Event object
   * @param country_submit Country of Event object
   * @param city_submit City of Event object
   * @param type_submit Type of Event object
     * @param year_submit Year of Event object
     */
  public Event (String eventID_submit, String descendant_submit, String owner_submit, double latitude_submit, double longitude_submit, String country_submit, String city_submit, String type_submit, int year_submit)
  {
    this.eventID = eventID_submit;
    this.descendant = descendant_submit;
    this.personID = owner_submit;
    this.latitude = latitude_submit;
    this.longitude = longitude_submit;
    this.country = country_submit;
    this.city = city_submit;
    this.eventType = type_submit;
    this.year = year_submit;
  }

  /**
   * Construct expects no arguments
   */
  public Event ()
  {

  }




  public String getEventID ()
  {
    return this.eventID;
  }

  public void setEventID (String eventID_submit)
  {
    this.eventID = eventID_submit;
  }




  public String getDescendant ()
  {
    return this.descendant;
  }

  public void setDescendant (String descendantUserName_submit)
  {
    this.descendant = descendantUserName_submit;
  }




  public String getOwner ()
  {
    return this.personID;
  }

  public void setOwner (String ownerPersonID_submit)
  {
    this.personID = ownerPersonID_submit;
  }




  public double getLatitude ()
  {
    return this.latitude;
  }

  public void setLatitude (double latitude_submit)
  {
    this.latitude = latitude_submit;
  }




  public double getLongitude ()
  {
    return this.longitude;
  }

  public void setLongitude (double longitude_submit)
  {
    this.longitude = longitude_submit;
  }




  public String getCountry ()
  {
    return this.country;
  }

  public void setCountry (String country_submit)
  {
    this.country = country_submit;
  }




  public String getCity ()
  {
    return this.city;
  }

  public void setCity (String city_submit)
  {
    this.city = city_submit;
  }




  public String getType ()
  {
    return this.eventType;
  }

  public void setType (String type_submit)
  {
    this.eventType = type_submit;
  }




  public int getYear ()
  {
    return this.year;
  }

  public void setYear (int year_submit)
  {
    this.year = year_submit;
  }
}
