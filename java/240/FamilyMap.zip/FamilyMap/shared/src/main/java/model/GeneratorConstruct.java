package model;

import java.util.ArrayList;

/**
 * Created by Steve on 2/17/2017.
 */
public class GeneratorConstruct
{
    User generatorUser = null;
    ArrayList<Person> generatorPersons = new ArrayList<> ();
    ArrayList<Event> generatorEvents = new ArrayList<>();

    public GeneratorConstruct (User user_submit)
    {
        this.generatorUser = user_submit;
    }

    public GeneratorConstruct ()
    {

    }





    public void addGeneratorPerson (Person person_submit)
    {
        this.generatorPersons.add (person_submit);
    }




    public void addGeneratorEvent (Event event_submit)
    {
        this.generatorEvents.add (event_submit);
    }
}
