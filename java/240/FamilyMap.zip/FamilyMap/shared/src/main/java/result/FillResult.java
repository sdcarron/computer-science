package result;

/**
 * This class represents the result from making a request to to the Datbase regarding Filling
 */
public class FillResult
{
  /**
   * These provide the numbers of Person objects and Event objects that were generated and inserted
   * into the Database for the Request
   */
  //private int personCount = 0;
  //private int eventCount = 0;
  private String message = "";
  /**
   * Thse Strings represent the potential errors that could be encountered if the Request fails
   */
  //private String nameInvalid = "Error: invalid userName in FillRequest";
  //private String generationsInvalid = "Error: invalid generations in FillRequest";
  //private String internalError = "Error: internal server error";

  /**
   * This holds the potential error messages, and messageIndex is used to display which error message
   * is appropriate (if any)
   */
  //private String[] messages = {nameInvalid, generationsInvalid, internalError};

  //private int messageIndex;

  /**
   * The constructor expects 2 arguments
   * @param personCount_submit The number of Person objects that resulted from the Request
   * @param eventCount_submit The number of Event objects that resulted from the Request
     */
  //public FillResult (int personCount_submit, int eventCount_submit)
  //{
    //this.personCount = personCount_submit;
    //this.eventCount = eventCount_submit;
  //}

  /**
   * This constructor expects 0 arguments
   */
  public FillResult ()
  {

  }



  /*
  public int getPersonCount ()
  {
    return this.personCount;
  }

  public void setPersonCount (int personCount_submit)
  {
    this.personCount = personCount_submit;
  }



  public int getEventCount ()
  {
    return this.eventCount;
  }

  public void setEventCount (int eventCount_submit)
  {
    this.eventCount = eventCount_submit;
  }



  public void setMessageIndex (int messageIndex_submit)
  {
    this.messageIndex = messageIndex_submit;
  }

  public String getMessage ()
  {
    return this.messages [this.messageIndex];
  }
  */

  public void setErrorMessage (String errorMessage_submit)
  {
    this.message = errorMessage_submit;
  }

  public void setSuccessMessage (int personInsert_submit, int eventInsert_submit)
  {
    this.message = "Successfully added " + personInsert_submit + " persons and " + eventInsert_submit + " events to the databse.";
  }
}
