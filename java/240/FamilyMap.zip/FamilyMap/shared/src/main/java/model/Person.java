 package model;

 import java.util.UUID;

 /**
  * This class represents a Person
  */
 public class Person
 {
   /**
    * The personID is a Unique Identifier for a Person object
    * The descendant is the User whose ancestor is represented by the Person object
    */
   private String personID;
   private String descendant = null;
   private String firstName = "";
   private String lastName = "";
   private String gender = "";
   private String father = null;
   private String mother = null;
   private String spouse = null;

   /**
    * The constructor expects 8 arguments for creating a Person object
    * @param personID_submit The Unique Identifier for the Person object
    * @param descendant_submit The Person object's descendant (who is a registered User)
    * @param firstName_submit The Person object's first name
    * @param lastName_submit The Person's last name
    * @param gender_submit The Person's gender
    * @param fatherID_submit The Person's father (possibly null)
    * @param motherID_submit The Person's mother (possibly null)
      * @param spouseID_submit The Person's spouse (possibly null)
      */
   public Person (String personID_submit, String firstName_submit, String lastName_submit, String gender_submit, String descendant_submit, String fatherID_submit, String motherID_submit, String spouseID_submit)
   {
     this.personID = personID_submit;
     this.descendant = descendant_submit;
     this.firstName = firstName_submit;
     this.lastName = lastName_submit;
     this.gender = gender_submit;
     this.father = fatherID_submit;
     this.mother = motherID_submit;
     this.spouse = spouseID_submit;
   }

   /**
      * the constructor expects no arguments
    */
   public Person ()
   {

   }




   public String getPersonID ()
   {
     return this.personID;
   }

   public void setPersonID (String personID_submit)
   {
     this.personID = personID_submit;
   }




   public String getDescendant ()
   {
     return this.descendant;
   }

   public void setDescendant (String descendantUserName_submit)
   {
     this.descendant = descendantUserName_submit;
   }




   public String getFirstName ()
   {
     return this.firstName;
   }

   public void setFirstName (String firstName_submit)
   {
     this.firstName = firstName_submit;
   }




   public String getLastName ()
   {
     return this.lastName;
   }

   public void setLastName (String lastName_submit)
   {
     this.lastName = lastName_submit;
   }




   public String getGender ()
   {
     return this.gender;
   }

   public void setGender (String gender_submit)
   {
     this.gender = gender_submit;
   }




   public String getFather ()
   {
     return this.father;
   }

   public void setFather (String fatherID_submit)
   {
     this.father = fatherID_submit;
   }




   public String getMother ()
   {
     return this.mother;
   }

   public void setMother (String motherID_submit)
   {
     this.mother = motherID_submit;
   }




   public String getSpouse ()
   {
     return this.spouse;
   }

   public void setSpouse (String spouseID_submit)
   {
     this.spouse = spouseID_submit;
   }
 }
