package request;

/**
 * Objects of this class represent a request to access data on a given Event
 */
public class EventRequest
{
  /**
   * authID is the currently active Authentication ID
   * eventID is the Unique Identifier for the desired Event
   */
  private boolean authIDValid = false;
  private String authID = "";
  private String eventID = ""; //If eventID is "" then the call is for ALL EVENTS for user's ancestors

  /**
   * The constructor expects 2 arguments
   * @param authID_submit Currently Active Authentication Token
   * @param eventID_submit Desired Event
     */
  public EventRequest (boolean authIDValid_submit, String authID_submit, String eventID_submit)
  {
    this.authIDValid = authIDValid_submit;
    this.authID = authID_submit;
    this.eventID = eventID_submit;
  }

  /**
   * Constrctor expects 1 arguments
   * @param authID_submit This is the Authentication Token ID for creating the EventRequest
     */
  public EventRequest (boolean authIDValid_submit, String authID_submit)
  {
    this.authIDValid = authIDValid_submit;
    this.authID = authID_submit;
  }


  public EventRequest ()
  {}




  public boolean getAuthIDValid ()
  {
    return this.authIDValid;
  }




  public String getAuthID ()
  {
    return this.authID;
  }

  public void setAuthID (String authID_submit)
  {
    this.authID = authID_submit;
  }


  public String getEventID ()
  {
    return this.eventID;
  }

  public void setEventID (String eventID_submit)
  {
    this.eventID = eventID_submit;
  }




  public String getAll ()
  {
    return "authID: " + this.authID + "\neventID: " + this.eventID + "\n\n";
  }
}
