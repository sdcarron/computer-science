package result;

/**
 * This class represents the message that can result when a user tries to register a new account
 */
public class RegisterResult
{
  /**
   * These are the Authentication Token ID, the user's submitted/selected UNIQUE username, and the user;s
   * Unique Identifier if the registration is successful
   */
  private String authID = "";
  private String userName = "";
  private String personID = "";

  private String message = "";

  /**
   * These are the potential error messages that can be encountered when a user tries to register
   */
  //private String missingProperty = "Error: missing property in RegisterRequest";
  //private String invalidValue = "Error: invalid value in RegisterRequest";
  //private String nameTaken = "Error: userName already in use in RegisterRequest";
  //private String internalError = "Error: internal server error";

  /**
   * This holdst he potential error messages and messageIndex is used to select which (if any) error
   * message is appropriate to display
   */
  //private String[] messages = {missingProperty, invalidValue, nameTaken, internalError};

  //private int messageIndex;

  /**
   * The constructor expects 3 arguments
   * @param authID_submit The user's Authentication Token ID if registration is successful (user is now logged in)
   * @param userName_submit The user's UNIQUE username
   * @param personID_submit The user's Unique Identifier
     */


  public RegisterResult (String authID_submit, String userName_submit, String personID_submit)
  {
    this.authID = authID_submit;
    this.userName = userName_submit;
    this.personID = personID_submit;
  }


  /**
   * The constructor expects 0 arguments (used in the case of an error)
   */
  public RegisterResult ()
  {

  }



  public String getAuthID ()
  {
    return this.authID;
  }




  public String getUserName ()
  {
    return this.userName;
  }




  public String getPersonID ()
  {
    return this.personID;
  }



  /*
  public void setMessageIndex (int messageIndex_submit)
  {
    this.messageIndex = messageIndex_submit;
  }

  public String getMessage ()
  {
    return this.messages [this.messageIndex];
  }
  */

  public void setErrorMessage (String errorMessage_submit)
  {
    this.message = errorMessage_submit;
  }
}
