package request;

/**
 * This class represents a request made when a User wants to register a new account
 */
public class RegisterRequest
{
  /**
   * userName is the Unique Identifying account name the user would like to have
   */
  private String userName = "";
  private String password = "";
  private String email = "";
  private String firstName = "";
  private String lastName = "";
  private String gender = "";


  /**
   * The constructor expects 6 arguments
   * @param userName_submit This is the UNIQUE Identifying account name the user would like to have
   * @param password_submit This is the user's intended password
   * @param email_submit This is the user's email address
   * @param firstName_submit This is the user's first name
   * @param lastName_submit This is the user's last name
     * @param gender_submit This is the user's gender
     */
  public RegisterRequest (String userName_submit, String password_submit, String email_submit, String firstName_submit, String lastName_submit, String gender_submit)
  {
    this.userName = userName_submit;
    this.password = password_submit;
    this.email = email_submit;
    this.firstName = firstName_submit;
    this.lastName = lastName_submit;
    this.gender = gender_submit;
  }

  /**
   * This constructor expects 0 arguments
   */
  public RegisterRequest ()
  {

  }




  public String getUserName ()
  {
    return this.userName;
  }

  public void setUserName (String userName_submit)
  {
    this.userName = userName_submit;
  }




  public String getPassword ()
  {
    return this.password;
  }

  public void setPassword (String password_submit)
  {
    this.password = password_submit;
  }




  public String getEmail ()
  {
    return this.email;
  }

  public void setEmail (String email_submit)
  {
    this.email = email_submit;
  }




  public String getFirstName ()
  {
    return this.firstName;
  }

  public void setFirstName (String firstName_submit)
  {
    this.firstName = firstName_submit;
  }




  public String getLastName ()
  {
    return this.lastName;
  }

  public void setLastName (String lastName_submit)
  {
    this.lastName = lastName_submit;
  }




  public String getGender ()
  {
    return this.gender;
  }

  public void setGender (String gender_submit)
  {
    this.gender = gender_submit;
  }




  public String getAll ()
  {
    return "u_name: " + this.userName + "\npw: " + this.password + "\nemail: " + this.email + "\nf_name: " + this.firstName + "\nl_name: " + this.lastName + "\ngender: " + this.gender + "\n\n";
  }
}
