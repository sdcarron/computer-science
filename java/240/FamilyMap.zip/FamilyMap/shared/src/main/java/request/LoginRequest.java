 package request;

 public class LoginRequest
 {
   private String userName = "";
   private String password = "";


   public LoginRequest (String userName_submit, String password_submit)
   {
     this.userName = userName_submit;
     this.password = password_submit;
   }

   public LoginRequest ()
   {

   }




   public String getUserName ()
   {
     return this.userName;
   }

   public void setUserName (String userName_submit)
   {
     this.userName = userName_submit;
   }




   public String getPassword ()
   {
     return this.password;
   }

   public void setPassword (String password_submit)
   {
     this.password = password_submit;
   }




   public String getAll ()
   {
     return "u_name: " + this.userName + "\npassword: " + this.password + "\n\n";
   }
 }
