package result;

/**
 * This class represents the Message that is returned when a request to CLEAR the Database has been made
 */
public class ClearResult
{
  /**
   * These Strings represent the 2 possible resulting messages from trying to clear the Database
   */
  //private String successMessage = "Clear succeeded";
  //private String internalError = "Error: internal server error";


    private String message = "";
  /**
   * This array holds the above two possible resulting messages, and messageIndex will be used to select
   * which message is returned
   */
  //private String[] messages = {successMessage, internalError};

  //private int messageIndex;


  public ClearResult ()
  {

  }




    /*
  public void setMessageIndex (int messageIndex_submit)
  {
    this.messageIndex = messageIndex_submit;
  }

  public String getMessage ()
  {
    return this.messages [this.messageIndex];
  }
  */


    public void setSuccessMessage (String successMessage_submit)
    {
        this.message = successMessage_submit;
    }


    public void setErrorMessage (String errorMessage_submit)
    {
        this.message = errorMessage_submit;
    }
}
