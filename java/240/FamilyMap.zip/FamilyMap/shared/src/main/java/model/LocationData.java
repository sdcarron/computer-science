package model;

/**
 * Created by Steve on 3/13/2017.
 */
public class LocationData
{
    Location[] data = null;

    public LocationData ()
    {

    }




    public void setData (Location[] data_submit)
    {
        this.data = data_submit;
    }

    public Location[] getData ()
    {
        return this.data;
    }
}
