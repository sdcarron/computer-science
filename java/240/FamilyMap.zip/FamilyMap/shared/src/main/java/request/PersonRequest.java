package request;


/**
 * This class represents a request to the Datbase regarding a specific Person
 */
public class PersonRequest
 {
   /**
    * authID is the currently active Authentication Token Unique Identifier
    * personID is the desired Person objects Unique Identifier
    */
   private boolean authIDValid = false;
   private String authID = "";
   private String personID = ""; //If personID is "" then the call is for ALL PEOPLE who are user's ancestors

   /**
    * The constructor expects 2 arguments
    * @param authIDValid_submit This is the currently active Authentication Token
    * @param personID_submit This is the Unique Identifier for the desired Person object
      */
   public PersonRequest (boolean authIDValid_submit, String authID_submit, String personID_submit)
   {
     this.authIDValid = authIDValid_submit;
     this.authID = authID_submit;
     this.personID = personID_submit;
   }

   /**
    * This constructor expects 1 argument
    * @param authIDValid_submit This is the currently Active Authentication Token
      */
   public PersonRequest (boolean authIDValid_submit, String authID_submit)
   {
     this.authIDValid = authIDValid_submit;
     this.authID = authID_submit;
   }



   public PersonRequest ()
   {}

   public boolean getAuthIDValid ()
   {
     return this.authIDValid;
   }



   public void setAuthID (String authID_submit)
   {
     this.authID = authID_submit;
   }

   public String getAuthID ()
   {
     return this.authID;
   }




   public String getPersonID ()
   {
     return this.personID;
   }

   public void setPersonID (String personID_submit)
   {
     this.personID = personID_submit;
   }




   public String getAll ()
   {
     return "authID: " + this.authIDValid + "\npersonID: " + this.personID + "\n\n";
   }

 }
