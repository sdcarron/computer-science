package com.example.application.familymap.proxy;

import request.LoadRequest;
import result.LoadResult;

import java.io.*;
import java.net.*;

public class LoadProxy
{
    private LoadRequest loadRequest = new LoadRequest ();

  public LoadProxy ()
  {

  }




    public void load (String serverHost, String serverPort)
    {
        try
        {
            URL url = new URL ("http://" + serverHost + ":" + serverPort + "/load/");

            HttpURLConnection http = (HttpURLConnection) url.openConnection ();

            http.setRequestMethod ("POST");
            http.setDoOutput (true);

            http.addRequestProperty ("Accept", "application/json");

            http.connect ();


            if (http.getResponseCode () == HttpURLConnection.HTTP_OK)
            {
                InputStream responseBody = http.getInputStream ();

                String responseData = readResponse (responseBody);

                System.out.println (responseData);
            }

            else
            {
                System.out.println (http.getResponseMessage ());
            }
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }
    }




    public String readResponse (InputStream responseBody) throws IOException
    {
        StringBuilder responseDataBuilder = new StringBuilder ();

        InputStreamReader responseReader = new InputStreamReader (responseBody);

        char[] buff = new char [1024];
        int len;

        while ((len = responseReader.read (buff)) > 0)
        {
            responseDataBuilder.append (buff, 0, len);
        }

        return responseDataBuilder.toString ();
    }




  public LoadResult load (LoadRequest loadRequest_submit)
  {
    return new LoadResult ();
  }
}
