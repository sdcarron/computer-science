/**
 * Created by Steve on 3/16/2017.
 */
public class testDriver {

    public static void main(String[] args) {

        org.junit.runner.JUnitCore.main(
                "dao.testDatabase",
                "proxy.ProxyTest");
    }

}
