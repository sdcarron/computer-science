package proxy;


import proxy.MainProxy;
import com.google.gson.Gson;
import com.google.gson.JsonObject;

import org.junit.Test;
import org.junit.Assert;

import java.util.ArrayList;

import model.Event;
import result.EventResult;

/**
 * Created by Steve on 3/14/2017.
 */
public class ProxyTest
{
    public JsonObject clearRegister ()
    {
        MainProxy testProxy = new MainProxy ();

        String[] args = {"localhost", "8080", "clear"};

        testProxy.run (args);

        String jsonData =
                "{" +
                        "\"userName\": \"Sally\"," +
                        "\"password\": \"parker\"," +
                        "\"email\": \"sheila@parker.com\"," +
                        "\"firstName\": \"Sheila\"," +
                        "\"lastName\": \"Parker\"," +
                        "\"gender\": \"f\"," +
                        "\"personID\": \"Sheila_Parker\"" +
                        "}";

        String[] argsR = {"localhost", "8080", "register", jsonData};

        return testProxy.run (argsR);
    }

    @Test
    public void testLoad ()
    {
        MainProxy testProxy = new MainProxy ();

        String jsonData =
        "{" +
            "\"users\": [" +
            "{"+
                "\"userName\": \"Sally\"," +
                    "\"password\": \"parker\"," +
                    "\"email\": \"sheila@parker.com\"," +
                    "\"firstName\": \"Sheila\"," +
                    "\"lastName\": \"Parker\"," +
                    "\"gender\": \"f\"," +
                    "\"personID\": \"Sheila_Parker\"" +
            "}" +
            "]," +
            "\"persons\": [" +
            "{" +
                "\"firstName\": \"Sheila\"," +
                    "\"lastName\": \"Parker\"," +
                    "\"gender\": \"f\"," +
                    "\"personID\": \"Sheila_Parker\"," +
                    "\"descendant\": \"sheila\"" +
            "}" +
            "]," +
            "\"events\": [" +
            "{" +
                "\"eventType\": \"started family map\"," +
                    "\"personID\": \"Sheila_Parker\"," +
                    "\"city\": \"Salt Lake City\"," +
                    "\"country\": \"United States\"," +
                    "\"latitude\": 40.7500," +
                    "\"longitude\": -110.1167," +
                    "\"year\": 2016," +
                    "\"descendant\":\"sheila\"," +
                    "\"eventID\": \"e5244e18-8fc6-4996-a457-aaa60c7ef066\"" +
            "}" +
            "]" +
        "}";

        String[] args = {"localhost", "8080", "load", jsonData};

        Assert.assertTrue (testProxy.run (args) != null);
    }




    @Test
    public void testRegister ()
    {
        MainProxy testProxy = new MainProxy ();

        String[] args = {"localhost", "8080", "clear"};

        testProxy.run (args);

        String jsonData =
            "{" +
                "\"userName\": \"Sally\"," +
                "\"password\": \"parker\"," +
                "\"email\": \"sheila@parker.com\"," +
                "\"firstName\": \"Sheila\"," +
                "\"lastName\": \"Parker\"," +
                "\"gender\": \"f\"," +
                "\"personID\": \"Sheila_Parker\"" +
            "}";

        String[] argsR = {"localhost", "8080", "register", jsonData};

        testProxy.run (argsR);

        Assert.assertTrue (testProxy.run (argsR) != null);
    }




    @Test
    public void testLogin ()
    {

        MainProxy testProxy = new MainProxy ();

        /*
        String[] args = {"localhost", "8080", "clear"};

        testProxy.run (args);

        String jsonData =
                "{" +
                        "\"userName\": \"Sally\"," +
                        "\"password\": \"parker\"," +
                        "\"email\": \"sheila@parker.com\"," +
                        "\"firstName\": \"Sheila\"," +
                        "\"lastName\": \"Parker\"," +
                        "\"gender\": \"f\"," +
                        "\"personID\": \"Sheila_Parker\"" +
                        "}";

        String[] argsR = {"localhost", "8080", "register", jsonData};*/

        JsonObject loginRegister = clearRegister ();


        if (loginRegister != null)
        {
            String jsonDataLogin =


                    "{" +
                            "\"userName\":\"Sally\"," +
                            "\"password\":\"parker\"" +
                            "}";

            String[] argsL = {"localhost", "8080", "login", jsonDataLogin};

            Assert.assertTrue (testProxy.run (argsL) != null);
        }

    }




    @Test
    public void testFill ()
    {
        MainProxy testProxy = new MainProxy ();

        /*
        String jsonData =
                "{" +
                        "\"userName\": \"Sally\"," +
                        "\"password\": \"parker\"," +
                        "\"email\": \"sheila@parker.com\"," +
                        "\"firstName\": \"Sheila\"," +
                        "\"lastName\": \"Parker\"," +
                        "\"gender\": \"f\"," +
                        "\"personID\": \"Sheila_Parker\"" +
                        "}";

        String[] argsR = {"localhost", "8080", "register", jsonData};*/

        JsonObject fillRegister = clearRegister ();

        if (fillRegister != null)
        {
            String numGenerations = "2";

            String usernameInitial = fillRegister.get ("userName").toString ();

            String username = usernameInitial.substring (1, usernameInitial.length () - 1);



            String[] args1 = {"localhost", "8080", "fill", username, numGenerations};

            Assert.assertTrue (testProxy.run (args1) != null);



            String[] args2 = {"localhost", "8080", "fill", username};

            Assert.assertTrue (testProxy.run (args2) != null);
        }


    }




    @Test
    public void testEvent ()
    {
        MainProxy testProxy = new MainProxy ();

        /*
        String jsonData =
                        "{" +
                            "\"userName\": \"Sally\"," +
                            "\"password\": \"parker\"," +
                            "\"email\": \"sheila@parker.com\"," +
                            "\"firstName\": \"Sheila\"," +
                            "\"lastName\": \"Parker\"," +
                            "\"gender\": \"f\"," +
                            "\"personID\": \"Sheila_Parker\"" +
                        "}";

        String[] argsR = {"localhost", "8080", "register", jsonData};*/

        JsonObject eventRegister = clearRegister ();






        String numGenerations = "1";

        String usernameInitial = eventRegister.get ("userName").toString ();

        String username = usernameInitial.substring (1, usernameInitial.length () - 1);

        String[] argsF = {"localhost", "8080", "fill", username, numGenerations};

        JsonObject eventFill = testProxy.run (argsF);




        if (eventRegister != null && eventFill != null)
        {
            String authIDinitial = eventRegister.get ("authID").toString ();

            String authID = authIDinitial.substring (1, authIDinitial.length ()-1);





            String[] args2 = {"localhost", "8080", "event", authID};

            Assert.assertTrue (testProxy.run (args2) != null);



            JsonObject eventGeneral = testProxy.run (args2);



            Gson gson = new Gson();

            EventResult eventGeneralResult = gson.fromJson (eventGeneral, EventResult.class);

            ArrayList<Event> eventGeneralList = eventGeneralResult.getEvents ();


            if (eventGeneralList.size () > 0)
            {
               String eventIDinitial = eventGeneralList.get (0).getEventID ();

                //String eventID = eventIDinitial.substring (1, eventIDinitial.length () - 1);

                String[] args1 = {"localhost", "8080", "event", authID, eventIDinitial};

                Assert.assertTrue (testProxy.run (args1) != null);
            }

        }

    }




    @Test
    public void testPerson ()
    {
        MainProxy testProxy = new MainProxy ();

        /*
        String jsonData =
                "{" +
                        "\"userName\": \"Sally\"," +
                        "\"password\": \"parker\"," +
                        "\"email\": \"sheila@parker.com\"," +
                        "\"firstName\": \"Sheila\"," +
                        "\"lastName\": \"Parker\"," +
                        "\"gender\": \"f\"," +
                        "\"personID\": \"Sheila_Parker\"" +
                        "}";

        String[] argsR = {"localhost", "8080", "register", jsonData};*/

        JsonObject personRegister = clearRegister ();






        String jsonDataLogin =


                "{" +
                        "\"userName\":\"Sally\"," +
                        "\"password\":\"parker\"" +
                        "}";

        String[] argsL = {"localhost", "8080", "login", jsonDataLogin};

        JsonObject personLogin = testProxy.run (argsL);


        if (personRegister != null && personLogin != null)
        {
            String authIDinitial = personRegister.get ("authID").toString ();

            String authID = authIDinitial.substring (1, authIDinitial.length () - 1);

            String personIDinitial = personLogin.get ("personID").toString ();

            String personID = personIDinitial.substring (1, personIDinitial.length () - 1);



            String[] args1 = {"localhost", "8080", "person", authID, personID};

            Assert.assertTrue (testProxy.run (args1) != null);



            String[] args2 = {"localhost", "8080", "person", authID};

            Assert.assertTrue (testProxy.run (args2) != null);
        }
    }




    @Test
    public void testClear ()
    {
        MainProxy testProxy = new MainProxy ();

        String[] args = {"localhost", "8080", "clear"};

        Assert.assertTrue (testProxy.run (args) != null);
    }

}
