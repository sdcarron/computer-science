package service;

import dao.DatabaseDAO;
import model.AuthToken;
import dao.DatabaseDAO.AuthTokenDAO;
import dao.DatabaseDAO.UserDAO;

/**
 * Created by Steve on 3/2/2017.
 */
public class ValidationService
{
    //AuthToken currentAuthToken;
    DatabaseDAO validationDatabaseDAO = new DatabaseDAO ();
    AuthTokenDAO a_validationDAO = validationDatabaseDAO.dbGetAuthDAO ();
    UserDAO u_validationDAO = validationDatabaseDAO.dbGetUserDAO ();


    public ValidationService()
    {
        //this.currentAuthToken = currentAuthToken_submit;
    }



    public boolean validateAuthToken (String authToken_submit)
    {
        if (authToken_submit == null || authToken_submit.equals (""))
        {
            return false;
        }

        boolean authVal = false;

        validationDatabaseDAO.openConnection ();

        authVal = a_validationDAO.verifyAuthToken (authToken_submit);

        validationDatabaseDAO.closeConnection ();


        //a_validationDAO.setCurrentAuthToken (authToken_submit);
        return authVal;
    }




    public boolean validateUser (String username_submit)
    {
        boolean userVal = false;

        validationDatabaseDAO.openConnection ();

        userVal = u_validationDAO.verifyUser (username_submit);

        validationDatabaseDAO.closeConnection ();

        return userVal;
    }





    public boolean validatePassword (String username_submit, String password_submit)
    {
        boolean userPassVal = false;

        validationDatabaseDAO.openConnection ();

        userPassVal = u_validationDAO.verifyUserPassword (username_submit, password_submit);

        validationDatabaseDAO.closeConnection ();

        return userPassVal;
    }
}
