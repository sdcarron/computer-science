package service;

import java.util.ArrayList;
import java.util.UUID;

import dao.DatabaseDAO;
import dao.DatabaseDAO.UserDAO;
import dao.DatabaseDAO.AuthTokenDAO;

import model.AuthToken;
import model.DataGenerator;
import model.Event;
import model.Person;
import model.User;
import request.RegisterRequest;
import result.RegisterResult;

/**
 * This class processes the RegisterRequest from the Server and submits it to the DAO
 */
public class RegisterService
{

  DatabaseDAO registerDatabaseDAO = new DatabaseDAO();
  UserDAO u_registerDatabaseDAO = registerDatabaseDAO.dbGetUserDAO ();
  AuthTokenDAO a_registerDatabaseDAO = registerDatabaseDAO.dbGetAuthDAO ();

  /**
   * This will take care of generating new ancestral data when a RegisterRequest is received
   */
  DataGenerator generator = new DataGenerator();


    /**
     * These will contain the data that is returned from the DataGenerator once the ancestral data has been generated
     * The data will THEN be passed to the appropriate DAOs
     */
  User generatedUser = new User();
  String userPersonID = null;
  ArrayList<Person> generatedPersons = new ArrayList<>();
  ArrayList<Event> generatedEvents = new ArrayList<> ();

  public RegisterService ()
  {

  }


  /**
   * Submit the RegisterREquest object to DataGenerator which will pass it onto DAOs
   * @param registerRequest_submit The RegisterREquest object
   * @return Message indicating success or failure
     */
  public RegisterResult register (RegisterRequest registerRequest_submit)
  {
    registerDatabaseDAO.openConnection ();

    System.out.println ("Entered RegisterService REGISTER function");

    RegisterResult requestResult = null;
    AuthToken registerAuthToken = null;

    boolean registerUserInsertStatus = false;
    boolean registerAuthTokenInsertStatus = false;

    //insert the User and AuthToken for the user
    if (generatedUser != null)
    {
      System.out.println ("Creating the RegisterUser in the User Table");

      registerUserInsertStatus = u_registerDatabaseDAO.createUser (generatedUser);

      registerAuthToken = new AuthToken (UUID.randomUUID().toString ());
      registerAuthTokenInsertStatus = a_registerDatabaseDAO.createAuthToken (generatedUser.getUserName (), registerAuthToken);
    }

    registerDatabaseDAO.closeConnection ();

    if (registerUserInsertStatus == true && registerAuthTokenInsertStatus == true)
    {
      System.out.println ("Looks like the Registering User was invalid for some reason... inside the Register Service");

      requestResult = new RegisterResult (registerAuthToken.getAuthID (), generatedUser.getUserName (), generatedUser.getPersonID ());
    }

    else
    {
      requestResult = new RegisterResult ();
      //requestResult.setMessageIndex (1);

      String errorMessage = "Username already in user or invalid value or missing value.";

      requestResult.setErrorMessage (errorMessage);
    }

    return requestResult;
  }





  public void setGeneratedUser (User generatedUser_submit)
  {
    this.generatedUser = generatedUser_submit;
  }




  public void setUserPersonID (String userPersonID_submit)
  {
    this.userPersonID = userPersonID_submit;
  }
}
