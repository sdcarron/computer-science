package handle;

import java.util.UUID;
import java.io.*;
import java.net.*;
import com.sun.net.httpserver.*;

import model.AuthToken;
import request.EventRequest;
import result.EventResult;
import service.ValidationService;
import service.EventService;

/**
 * Created by Steve on 3/1/2017.
 */
public class EventHandler implements HttpHandler
{
    //private EventResult eventResult;

    private EventRequest eventRequest;

    private EventService eventService;

    private Coder eventCoder = new Coder ();

    //private boolean e_authTokenValid = false;

    @Override
    public void handle(HttpExchange exchange)
    {
        //e_authTokenValid = false;

        if (exchange.getRequestMethod ().toLowerCase ().equals ("get"))
        {
            /*
            Headers requestHeaders = exchange.getRequestHeaders ();

            if (requestHeaders.containsKey ("Authorization"))
            {
                String authTokenString = requestHeaders.getFirst ("Authorization");

                //UUID eventRequestAuthID = UUID.fromString (authTokenString);
                //AuthToken eventRequestAuthToken = new AuthToken (eventRequestAuthID);
                AuthToken eventRequestAuthToken = new AuthToken (authTokenString);

                ValidationService authTokenValidator = new ValidationService();
                if (authTokenValidator.validateAuthToken (authTokenString) == true)
                {
                    e_authTokenValid = true;
                }
            */
                boolean e_authTokenValid = authProcess (exchange);

                String authTokenString = exchange.getRequestHeaders ().getFirst ("Authorization");



                EventResult eventResult = eventProcess (exchange, e_authTokenValid, authTokenString);

                String responseData = encodeProcess (eventResult);

                responseProcess (responseData, exchange);
                /*
                String eventURI = exchange.getRequestURI ().toString ();

                if (eventURI.equals ("/event/") && e_authTokenValid == true)
                {
                    //Get ALL Events associated with the User that has the submitted AuthTopkenID
                    eventRequest = new EventRequest (e_authTokenValid, authTokenString);

                    eventService = new EventService ();

                    eventResult = eventService.getEvent (eventRequest, 2);
                }

                //Otherwise get the specific requested event
                else if (e_authTokenValid == true)
                {
                    String[] uriArray = eventURI.split ("/");
                    String eventIDString = uriArray[2];


                    eventRequest = new EventRequest (e_authTokenValid, authTokenString, eventIDString);

                    eventService = new EventService();

                    eventResult = eventService.getEvent (eventRequest, 1);
                }

                else
                {
                    eventResult = new EventResult ();
                    eventResult.setMessageIndex (0);
                }

                */
            //}
        }
    }




    private String encodeProcess (EventResult eventResult)
    {
        String responseData = eventCoder.encodeResult (eventResult);

        return responseData;
    }




    private void responseProcess (String responseData, HttpExchange exchange)
    {
        try
        {
            exchange.sendResponseHeaders (HttpURLConnection.HTTP_OK, 0);



            OutputStream responseBody = exchange.getResponseBody ();

            writeResponse (responseData, responseBody);

            responseBody.close ();
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }
    }




    private void writeResponse (String responseData, OutputStream responseBody) throws IOException
    {
        OutputStreamWriter responseWriter = new OutputStreamWriter (responseBody);

        responseWriter.write (responseData);

        responseWriter.flush ();
    }




    private boolean authProcess (HttpExchange exchange)
    {
        boolean authResult = false;

        Headers requestHeaders = exchange.getRequestHeaders ();

        if (requestHeaders.containsKey ("Authorization"))
        {
            String authTokenString = requestHeaders.getFirst("Authorization");

            //UUID eventRequestAuthID = UUID.fromString (authTokenString);
            //AuthToken eventRequestAuthToken = new AuthToken (eventRequestAuthID);
            AuthToken eventRequestAuthToken = new AuthToken(authTokenString);

            ValidationService authTokenValidator = new ValidationService();
            if (authTokenValidator.validateAuthToken(authTokenString) == true) {
                authResult = true;
            }
        }

        return authResult;
    }





    private EventResult eventProcess (HttpExchange exchange, boolean e_authTokenValid, String authTokenString)
    {
        EventResult eventResult = new EventResult ();

        String eventURI = exchange.getRequestURI ().toString ();

        if (eventURI.equals ("/event/") && e_authTokenValid == true)
        {
            //Get ALL Events associated with the User that has the submitted AuthTopkenID
            EventRequest eventRequest = new EventRequest (e_authTokenValid, authTokenString);

            EventService eventService = new EventService ();

            eventResult = eventService.getEvent (eventRequest, 2);
        }

        //Otherwise get the specific requested event
        else if (e_authTokenValid == true)
        {
            String[] uriArray = eventURI.split ("/");
            String eventIDString = uriArray[2];


            EventRequest eventRequest = new EventRequest (e_authTokenValid, authTokenString, eventIDString);

            EventService eventService = new EventService();

            eventResult = eventService.getEvent (eventRequest, 1);
        }

        else
        {
            String errorMessage = "Invalid auth token.";

            eventResult.setErrorMessage (errorMessage);
        }


        return eventResult;
    }
}
