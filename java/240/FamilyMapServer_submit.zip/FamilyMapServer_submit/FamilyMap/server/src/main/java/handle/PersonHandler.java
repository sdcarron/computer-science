package handle;


import java.util.UUID;

import java.io.*;
import java.net.*;
import com.sun.net.httpserver.*;

import model.AuthToken;
import request.PersonRequest;
import result.PersonResult;
import service.ValidationService;
import service.PersonService;

/**
 * Created by Steve on 3/1/2017.
 */
public class PersonHandler implements HttpHandler
{

    private Coder personCoder = new Coder ();


    @Override
    public void handle (HttpExchange exchange)
    {
        //boolean p_authTokenValid = false;

        //try
        //{
            if (exchange.getRequestMethod ().toLowerCase ().equals ("get"))
            {
                /*
                Headers requestHeaders = exchange.getRequestHeaders ();

                if (requestHeaders.containsKey ("Authorization"))
                {
                    //verify authToken
                    String authTokenString = requestHeaders.getFirst ("Authorization");

                   // UUID personRequestAuthID = UUID.fromString (authTokenString);
                    //AuthToken personRequestAuthToken = new AuthToken(personRequestAuthID);

                    ValidationService authTokenValidator = new ValidationService();
                    if (authTokenValidator.validateAuthToken (authTokenString) == true)
                    {
                        p_authTokenValid = true;
                    }
                */
                    boolean p_authTokenValid = authProcess (exchange);

                    String authTokenString = exchange.getRequestHeaders ().getFirst ("Authorization");


                    PersonResult personResult = personProcess (exchange, p_authTokenValid, authTokenString);


                    String responseData = encodeProcess (personResult);

                    responseProcess (responseData, exchange);
                    /*
                    String personURI = exchange.getRequestURI ().toString ();

                    if (personURI.equals ("/person/") && p_authTokenValid == true)
                    {
                        //handle getting ALL PERSONS
                        PersonRequest generalPersonRequest = new PersonRequest (p_authTokenValid, authTokenString);

                        PersonService generalPersonService = new PersonService ();

                        PersonResult generalPersonResult = generalPersonService.getPerson (generalPersonRequest, 2);
                    }

                    //If the request was NOT for ALL PERSONS, then obtain the specific desired personID
                    else if (p_authTokenValid == true)
                    {
                        String[] uriArray = personURI.split ("/");
                        String personIDString = uriArray [2];

                        UUID personID = UUID.fromString (personIDString );



                        PersonRequest specificPersonRequest = new PersonRequest (p_authTokenValid, authTokenString, personIDString);

                        PersonService specificPersonService = new PersonService();

                        PersonResult specificPersonResult = specificPersonService.getPerson (specificPersonRequest, 1);



                    }

                    else
                    {
                        PersonResult invalidResult = new PersonResult ();
                        invalidResult.setMessageIndex (0);
                    }
                    */

                //}
            }
        //}

        /*
        catch (IOException e)
        {
            //personResult.setMessageIndex (2);

            e.printStackTrace ();

            System.out.println ("Handle PersonHandler: Processing request failed");
        }
        */
    }




    private String encodeProcess (PersonResult personResult)
    {
        String responseData = personCoder.encodeResult (personResult);

        return responseData;
    }




    private void responseProcess (String responseData, HttpExchange exchange)
    {
        try
        {
            exchange.sendResponseHeaders (HttpURLConnection.HTTP_OK, 0);



            OutputStream responseBody = exchange.getResponseBody ();

            writeResponse (responseData, responseBody);

            responseBody.close ();
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }
    }




    private void writeResponse (String responseData, OutputStream responseBody) throws IOException
    {
        OutputStreamWriter responseWriter = new OutputStreamWriter (responseBody);

        responseWriter.write (responseData);

        responseWriter.flush ();
    }




    private boolean authProcess (HttpExchange exchange)
    {
        boolean authResult = false;

        Headers requestHeaders = exchange.getRequestHeaders ();

        if (requestHeaders.containsKey ("Authorization"))
        {
            //verify authToken
            String authTokenString = requestHeaders.getFirst("Authorization");

            // UUID personRequestAuthID = UUID.fromString (authTokenString);
            //AuthToken personRequestAuthToken = new AuthToken(personRequestAuthID);

            ValidationService authTokenValidator = new ValidationService();
            if (authTokenValidator.validateAuthToken(authTokenString) == true) {
                authResult = true;
            }
        }

        return authResult;
    }




    private PersonResult personProcess (HttpExchange exchange, boolean p_authTokenValid, String authTokenString)
    {
        PersonResult personResult;


        String personURI = exchange.getRequestURI ().toString ();

        if (personURI.equals ("/person/") && p_authTokenValid == true)
        {
            //handle getting ALL PERSONS
            PersonRequest personRequest = new PersonRequest (p_authTokenValid, authTokenString);

            PersonService personService = new PersonService ();

            personResult = personService.getPerson (personRequest, 2);
        }

        //If the request was NOT for ALL PERSONS, then obtain the specific desired personID
        else if (p_authTokenValid == true)
        {
            String[] uriArray = personURI.split ("/");
            String personIDString = uriArray [2];

            //UUID personID = UUID.fromString (personIDString );



            PersonRequest personRequest = new PersonRequest (p_authTokenValid, authTokenString, personIDString);

            PersonService personService = new PersonService();

            personResult = personService.getPerson (personRequest, 1);



        }

        else
        {
            personResult = new PersonResult ();

            String errorMessage = "Invalid auth token.";

            personResult.setErrorMessage (errorMessage);
            //personResult.setMessageIndex (0);
        }


        return personResult;
    }
}
