package handle;


import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.Scanner;
import java.util.UUID;

import com.sun.net.httpserver.*;

import model.Event;
import model.Person;
import model.User;
import request.FillRequest;
import request.RegisterRequest;
import result.FillResult;
import result.RegisterResult;
import service.FillService;
import service.RegisterService;
import service.ValidationService;


/**
 * Created by Steve on 3/1/2017.
 */
public class RegisterHandler implements HttpHandler
{
    private RegisterResult registerResult = new RegisterResult ();

    private Person registerPerson = null;
    private Event registerBirth = null;

    private Coder registerCoder = new Coder ();

    //private DataGenerator registerGenerator = new DataGenerator ();

    public RegisterHandler ()
    {}

    @Override
    public void handle (HttpExchange exchange)
    {

        System.out.println ("Entered Register Handler");

        if (exchange.getRequestMethod ().toLowerCase ().equals ("post"))
        {

            /*
            InputStream requestBodyStream = exchange.getRequestBody ();

            Scanner requestBodyReader = new Scanner(requestBodyStream);

            StringBuilder requestBodyBuilder = new StringBuilder ();

            while (requestBodyReader.hasNextLine ())
            {
                requestBodyBuilder.append (requestBodyReader.nextLine ().toString ());
            }


            RegisterRequest registerRequest = registerCoder.decodeRegister (requestBodyBuilder.toString ());
            */
            RegisterRequest registerRequest = decodeProcess (exchange);

            boolean validRequestStatus = validateRequest (registerRequest);


            ValidationService validationService = new ValidationService ();
            //If the submitted username is NOT already in the database, proceed with processing the RegisterRequest
            if (validationService.validateUser (registerRequest.getUserName ()) == false && validRequestStatus == true)
            {
                /*
                RegisterService registerService = new RegisterService ();

                //Now create a User object for the REGISTERING user and pass it to the RegisterService,
                //so that it can be inserted into the User Database Table
                User registerUser = registerGenerator.generateRegisterUser (registerRequest);
                Person registerPerson = registerGenerator.generateRegisterPerson (registerRequest);
                registerPerson.setDescendant (registerUser.getUserName ());
                registerPerson.setPersonID (registerUser.getPersonID ());

                Event registerBirth = new Event ();
                registerBirth.setEventID (UUID.randomUUID ().toString ());
                registerBirth.setDescendant (registerUser.getUserName ());
                registerBirth.setOwner (registerPerson.getPersonID ());
                registerBirth.setYear (1985);
                registerBirth.setType ("Birth");

                //NOTE Remember to add registerPerson into the ArrayList of Person objects (BELOW) that iwll be passed to
                //the FillService in order to be inserted into the Person Database
                registerService.setGeneratedUser (registerUser);
                //reg_RegisterService.setUserPersonID (registerPerson.getPersonID ());
                */
                registerResult = registerProcess (registerRequest);//registerService.register (registerRequest);



                fillProcess (registerRequest);




                /*
                FillService fillService = new FillService();
                FillRequest fillRequest = new FillRequest(registerRequest.getUserName ());

                //Generate Randome 4 generations of ancestral data for the registering User, and then
                //send the generated Persons and Events to the Fill Service so that the information can
                //be inserted into the Person and Event Database Tables
                registerGenerator.setDescendantUserName (registerRequest.getUserName ());
                registerGenerator.setNumGenerations (4);
                try
                {
                    //registerGenerator.generatePersons(4);
                    registerGenerator.generatePersons2 (registerPerson, registerBirth, 0);
                }

                catch (Exception e)
                {
                    e.printStackTrace ();
                }

                //NOTE Remember to add the Person object that was created for the registering User (ABOVE) before
                //passing the ArrayList of Person objects to the FillService to be inserted into the Person Database
                /*
                ArrayList<Person> reg_GeneratedPersons = registerGenerator.getPersons ();
                registerPerson.setFather (reg_GeneratedPersons.get (0).getPersonID ());
                registerPerson.setMother (reg_GeneratedPersons.get (1).getPersonID ());
                reg_GeneratedPersons.add (0, registerPerson);
                ArrayList<Event> reg_GeneratedEvents = registerGenerator.getEvents ();
                * /
                ArrayList<Person> generatedPersons2 = registerGenerator.getPersons2 ();
                ArrayList<Event> generatedEvents2 = registerGenerator.getEvents2 ();

                generatedPersons2.add (registerPerson);
                generatedEvents2.add (registerBirth);

                //Now pass the Generated Event and Person objects to the FillService to be inserted into their
                //respective Database Tables
                /*
                reg_FillService.setPersons (reg_GeneratedPersons);
                reg_FillService.setEvents (reg_GeneratedEvents);
                * /
                fillService.setPersons (generatedPersons2);
                fillService.setEvents (generatedEvents2);
                FillResult reg_FillResult = fillService.fill (fillRequest);
                */

            }

            else
            {
                registerResult = new RegisterResult ();

                String errorMessage = "Username already in user or invalid value or missing value.";

                registerResult.setErrorMessage (errorMessage);
            }




            String responseData = encodeProcess (registerResult);

            responseProcess (responseData, exchange);
            //Now pass the StringBuilder's string to the decoder

        }
    }




    private RegisterRequest decodeProcess (HttpExchange exchange)
    {
        InputStream requestBodyStream = exchange.getRequestBody ();

        Scanner requestBodyReader = new Scanner(requestBodyStream);

        StringBuilder requestBodyBuilder = new StringBuilder ();

        while (requestBodyReader.hasNextLine ())
        {
            requestBodyBuilder.append (requestBodyReader.nextLine ().toString ());
        }


        RegisterRequest registerRequest = registerCoder.decodeRegister (requestBodyBuilder.toString ());

        return registerRequest;
    }




    private String encodeProcess (RegisterResult registerResult)
    {
        String responseData = registerCoder.encodeResult (registerResult);

        return responseData;
    }




    private void responseProcess (String responseData, HttpExchange exchange)
    {
        try
        {
            exchange.sendResponseHeaders (HttpURLConnection.HTTP_OK, 0);



            OutputStream responseBody = exchange.getResponseBody ();

            writeResponse (responseData, responseBody);

            responseBody.close ();
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }
    }




    private void writeResponse (String responseData, OutputStream responseBody) throws IOException
    {
        OutputStreamWriter responseWriter = new OutputStreamWriter (responseBody);

        responseWriter.write (responseData);

        responseWriter.flush ();
    }




    private boolean validateRequest (RegisterRequest registerRequest)
    {
        boolean validRequestResult = true;

        if (registerRequest.getUserName () == null && registerRequest.getFirstName() == null && registerRequest.getLastName() == null && registerRequest.getEmail() == null && registerRequest.getGender() == null && registerRequest.getPassword() == null)
        {
            validRequestResult = false;
        }

        else if (registerRequest.getUserName ().equals ("") || registerRequest.getFirstName ().equals ("") || registerRequest.getLastName ().equals ("") || registerRequest.getEmail ().equals ("") || (!registerRequest.getGender ().toLowerCase ().equals ("m") && !registerRequest.getGender ().toLowerCase ().equals ("f")) || registerRequest.getPassword ().equals (""))
        {
            validRequestResult = false;
        }

        return validRequestResult;
    }




    private RegisterResult registerProcess (RegisterRequest registerRequest)
    {
        DataGenerator registerGenerator = new DataGenerator ();

        System.out.println ("Enetered the registerProcess");

        RegisterService registerService = new RegisterService ();

        //Now create a User object for the REGISTERING user and pass it to the RegisterService,
        //so that it can be inserted into the User Database Table
        User registerUser = registerGenerator.generateRegisterUser (registerRequest);
        registerPerson = registerGenerator.generateRegisterPerson (registerRequest);
        registerPerson.setDescendant (registerUser.getUserName ());
        registerPerson.setPersonID (registerUser.getPersonID ());

        registerBirth = new Event ();
        registerBirth.setEventID (UUID.randomUUID ().toString ());
        registerBirth.setDescendant (registerUser.getUserName ());
        registerBirth.setOwner (registerPerson.getPersonID ());
        registerBirth.setYear (1985);
        registerBirth.setType ("Birth");

        //NOTE Remember to add registerPerson into the ArrayList of Person objects (BELOW) that iwll be passed to
        //the FillService in order to be inserted into the Person Database
        registerService.setGeneratedUser (registerUser);




        RegisterResult registerResult = registerService.register (registerRequest);

        return registerResult;
    }




    private void fillProcess (RegisterRequest registerRequest)
    {
        DataGenerator registerGenerator = new DataGenerator ();

        FillService fillService = new FillService();
        FillRequest fillRequest = new FillRequest(registerRequest.getUserName ());

        //Generate Randome 4 generations of ancestral data for the registering User, and then
        //send the generated Persons and Events to the Fill Service so that the information can
        //be inserted into the Person and Event Database Tables
        registerGenerator.setDescendantUserName (registerRequest.getUserName ());
        registerGenerator.setNumGenerations (4);
        try
        {
            //registerGenerator.generatePersons(4);
            registerGenerator.generatePersons2 (registerPerson, registerBirth, 0);
        }

        catch (Exception e)
        {
            e.printStackTrace ();
        }

        //NOTE Remember to add the Person object that was created for the registering User (ABOVE) before
        //passing the ArrayList of Person objects to the FillService to be inserted into the Person Database
                /*
                ArrayList<Person> reg_GeneratedPersons = registerGenerator.getPersons ();
                registerPerson.setFather (reg_GeneratedPersons.get (0).getPersonID ());
                registerPerson.setMother (reg_GeneratedPersons.get (1).getPersonID ());
                reg_GeneratedPersons.add (0, registerPerson);
                ArrayList<Event> reg_GeneratedEvents = registerGenerator.getEvents ();
                */
        ArrayList<Person> generatedPersons2 = registerGenerator.getPersons2 ();
        ArrayList<Event> generatedEvents2 = registerGenerator.getEvents2 ();

        generatedPersons2.add (registerPerson);
        generatedEvents2.add (registerBirth);

        //Now pass the Generated Event and Person objects to the FillService to be inserted into their
        //respective Database Tables
                /*
                reg_FillService.setPersons (reg_GeneratedPersons);
                reg_FillService.setEvents (reg_GeneratedEvents);
                */
        fillService.setPersons (generatedPersons2);
        fillService.setEvents (generatedEvents2);
        FillResult reg_FillResult = fillService.fill (fillRequest);

    }
}
