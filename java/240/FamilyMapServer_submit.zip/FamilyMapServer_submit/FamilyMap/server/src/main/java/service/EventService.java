package service;

import java.util.ArrayList;

import dao.DatabaseDAO;
import model.Event;
import request.EventRequest;
import result.EventResult;

import dao.DatabaseDAO.EventDAO;
import dao.DatabaseDAO.AuthTokenDAO;

/**
 * This class processes the EventRequest from the Server and submits it to the DAO
 */
public class EventService
{
  DatabaseDAO eventDatabaseDAO = new DatabaseDAO ();
  EventDAO e_eventServiceDAO = eventDatabaseDAO.dbGetEventDAO ();
  AuthTokenDAO a_eventServiceDAO = eventDatabaseDAO.dbGetAuthDAO ();




  public EventService ()
  {

  }


  /**
   * Submit the EventRequest to the DAO
   * @param eventRequest_submit The EventRequest object
   * @return Message indicating success or failure
     */
  public EventResult getEvent (EventRequest eventRequest_submit, int requestType)
  {

    eventDatabaseDAO.openConnection ();

    EventResult requestResult = new EventResult ();

    //If the authToken was invalid, then set the result message to indicate that
    if (eventRequest_submit.getAuthIDValid () == false)
    {
        String errorMessage = "Invalid auth token.";

      requestResult.setErrorMessage (errorMessage);
    }


    if (requestType == 1)
    {
      Event resultEvent = e_eventServiceDAO.getEvent (eventRequest_submit.getEventID ());

        String requestingUser = a_eventServiceDAO.getUserName (eventRequest_submit.getAuthID ());


      //If eventID was invalid, then set the result message to indicate that
      if (requestingUser.equals (resultEvent.getDescendant ()) == false)
      {
        //requestResult.setMessageIndex (1);
          String errorMessage = "Invalid auth token.";

          requestResult.setErrorMessage (errorMessage);
      }

        else
      {
          requestResult.addResultEvent (resultEvent);
      }
    }




    else
    {
      String e_username = a_eventServiceDAO.getUserName (eventRequest_submit.getAuthID ());

      ArrayList<Event> resultEventList = e_eventServiceDAO.getEvents (e_username);

      requestResult.setEvents (resultEventList);
    }

    eventDatabaseDAO.closeConnection ();

    return requestResult;
  }





    public Event getUserBirthEvent (String personID_submit)
    {
        eventDatabaseDAO.openConnection ();

        Event userBirthEvent = e_eventServiceDAO.getBirthEvent (personID_submit);

        eventDatabaseDAO.closeConnection ();

        return userBirthEvent;
    }


    public ArrayList<Event> getUserEvents (String personID_submit)
    {
        eventDatabaseDAO.openConnection ();

        ArrayList<Event> userEvents = e_eventServiceDAO.getEvents (personID_submit);

        eventDatabaseDAO.closeConnection ();

        return userEvents;
    }
}
