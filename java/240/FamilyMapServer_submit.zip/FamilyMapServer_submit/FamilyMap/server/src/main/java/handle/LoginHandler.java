package handle;

import java.io.*;
import java.net.*;
import java.util.Scanner;

import com.sun.net.httpserver.*;

import com.google.gson.*;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;

import request.LoginRequest;
import result.LoginResult;
import service.LoginService;
import service.ValidationService;

/**
 * Created by Steve on 3/1/2017.
 */
public class LoginHandler implements HttpHandler
{
    private Coder loginCoder = new Coder ();

    private LoginResult loginResult;

    public LoginHandler ()
    {}

    @Override
    public void handle (HttpExchange exchange)
    {
        if (exchange.getRequestMethod ().toLowerCase().equals ("post"))
        {
            ValidationService log_ValidationService = new ValidationService();

            /*
            InputStream log_RequestBodyStream = exchange.getRequestBody ();

            Scanner log_RequestBodyReader = new Scanner (log_RequestBodyStream);

            StringBuilder log_RequestBodyBuilder = new StringBuilder ();

            while (log_RequestBodyReader.hasNextLine ())
            {
                log_RequestBodyBuilder.append (log_RequestBodyReader.nextLine ().toString ());
            }


            LoginRequest loginRequest = loginCoder.decodeLogin (log_RequestBodyBuilder.toString ());
            */
            LoginRequest loginRequest = decodeProcess (exchange);


            //If the submitted username and password are correct, proceed with processing the LoginRequest
            if (log_ValidationService.validateUser (loginRequest.getUserName ()) && log_ValidationService.validatePassword (loginRequest.getUserName (), loginRequest.getPassword ()))
            {
                LoginService loginService = new LoginService ();

                loginResult = loginService.login (loginRequest);
            }

            else if (log_ValidationService.validateUser (loginRequest.getUserName ()) == false || log_ValidationService.validatePassword (loginRequest.getUserName (), loginRequest.getPassword ()) == false)
            {
                loginResult = new LoginResult();

                //loginResult.setMessageIndex (1);
                String errorMessage = "Missing or invalid value.";
                loginResult.setErrorMessage (errorMessage);
            }




            String responseData = encodeProcess (loginResult);

            responseProcess (responseData, exchange);
        }
    }







    private LoginRequest decodeProcess (HttpExchange exchange)
    {
        InputStream log_RequestBodyStream = exchange.getRequestBody ();

        Scanner log_RequestBodyReader = new Scanner (log_RequestBodyStream);

        StringBuilder log_RequestBodyBuilder = new StringBuilder ();

        while (log_RequestBodyReader.hasNextLine ())
        {
            log_RequestBodyBuilder.append (log_RequestBodyReader.nextLine ().toString ());
        }


        LoginRequest loginRequest = loginCoder.decodeLogin (log_RequestBodyBuilder.toString ());


        return loginRequest;
    }




    private String encodeProcess (LoginResult loginResult)
    {
        String loginResultString = loginCoder.encodeResult (loginResult);

        return loginResultString;
    }




    private void responseProcess (String responseData, HttpExchange exchange)
    {
        try
        {
            exchange.sendResponseHeaders (HttpURLConnection.HTTP_OK, 0);


            OutputStream responseBody = exchange.getResponseBody ();

            writeResponse (responseData, responseBody);

            responseBody.close ();
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }
    }




    private void writeResponse (String responseData, OutputStream responseBody) throws IOException
    {
        OutputStreamWriter responseWriter = new OutputStreamWriter (responseBody);

        responseWriter.write (responseData);

        responseWriter.flush ();
    }
}
