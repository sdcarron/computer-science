package service;

import java.util.ArrayList;

import dao.DatabaseDAO;
import model.Person;
import request.PersonRequest;
import result.PersonResult;

import dao.DatabaseDAO.PersonDAO;
import dao.DatabaseDAO.AuthTokenDAO;
import dao.DatabaseDAO.UserDAO;
import dao.DatabaseDAO;
/**
 * This class processes the PersonRequest from the Server and submits it to the DAO
 */
public class PersonService
{
  DatabaseDAO personDatabaseDAO = new DatabaseDAO ();
  PersonDAO p_personServiceDAO = personDatabaseDAO.dbGetPersonDAO ();
  AuthTokenDAO a_personServiceDAO = personDatabaseDAO.dbGetAuthDAO ();
    UserDAO u_personServiceDAO = personDatabaseDAO.dbGetUserDAO ();


  public PersonService ()
  {

  }


  /**
   * Submit the PersonRequest object to the DAO
   * @param personRequest_submit The PersonRequest object
   * @return Message indiciating success or failure
     */
  public PersonResult getPerson (PersonRequest personRequest_submit, int requestType)
  {
    personDatabaseDAO.openConnection ();

    PersonResult requestResult = new PersonResult ();

      /*
    if (personRequest_submit.getAuthIDValid () == false)
    {
      requestResult.setMessageIndex (0);
    }
    */

    if (requestType == 1)
    {
      Person resultPerson = p_personServiceDAO.getPerson(personRequest_submit.getPersonID());

        String requestingUser = a_personServiceDAO.getUserName (personRequest_submit.getAuthID ());


      if (requestingUser.equals (resultPerson.getDescendant ()) == false)
      {
          String errorMessage = "Invalid auth token";
          //requestResult.setMessageIndex (1);

          requestResult.setErrorMessage (errorMessage);
      }

        else
      {
          requestResult.addResultPerson(resultPerson);
      }
    }

    else
    {
        String p_username = a_personServiceDAO.getUserName (personRequest_submit.getAuthID ());

        ArrayList<Person> resultPersonList = p_personServiceDAO.getPersons (p_username);

        requestResult.setPersons (resultPersonList);
    }

    personDatabaseDAO.closeConnection ();

    return requestResult;
  }






    public Person getUserPerson (String username)
    {
        personDatabaseDAO.openConnection ();

        String userPersonID = u_personServiceDAO.selectUserPersonID (username);

        Person userPerson = p_personServiceDAO.getPerson (userPersonID);

        personDatabaseDAO.closeConnection ();

        return userPerson;
    }
}
