package handle;


import java.io.*;
import java.net.*;
import java.util.ArrayList;
import java.util.UUID;

import com.sun.net.httpserver.*;

import model.Event;
import model.Person;
import request.FillRequest;
import result.FillResult;
import service.EventService;
import service.FillService;
import service.PersonService;
import service.ValidationService;

/**
 * Created by Steve on 3/3/2017.
 */
public class FillHandler implements HttpHandler
{
    private FillResult fillResult = new FillResult ();

    private Coder fillCoder = new Coder ();


    public FillHandler ()
    {}


    @Override
    public void handle (HttpExchange exchange)
    {

        if (exchange.getRequestMethod ().toLowerCase ().equals ("post"))
        {
            /*
            String fillURI = exchange.getRequestURI ().toString ();
            String[] uriArray = fillURI.split ("/");

            String username = uriArray[2];

            int numGenerations = 4;
            if (uriArray.length > 3)
            {
                numGenerations = Integer.parseInt(uriArray[3]);
            }

            ValidationService fillValidationService = new ValidationService ();
            boolean validUsernameStatus = fillValidationService.validateUser (username);
            */

            //FillResult fillResult = new FillResult ();
            FillRequest fillRequest = decodeProcess (exchange);

            //If the username AND number for data gnereation are valid,
            //then proceed with generating and inserting the generated ancestral data
            if (fillRequest != null)//(validUsernameStatus == true && numGenerations >= 0)
            {

                //Now generate the specified numGenerations of ancestral data for the username
                //THEN pass the data to the FillService which will pass the generated data to the
                //appropriate DAO for inserting into the Database Tables
                DataGenerator fillGenerator = new DataGenerator ();
                fillGenerator.setDescendantUserName (fillRequest.getUserName ());
                fillGenerator.setNumGenerations (fillRequest.getGenerations ());
                //fillGenerator.generatePersons (numGenerations);
                PersonService personService = new PersonService ();
                Person userPerson = personService.getUserPerson (fillRequest.getUserName ());

                EventService eventService = new EventService();
                Event userBirth = eventService.getUserBirthEvent (userPerson.getPersonID ());

                if (userBirth == null)
                {
                    userBirth = new Event ();

                    userBirth.setDescendant (fillRequest.getUserName ());
                    userBirth.setOwner (userPerson.getPersonID ());
                    userBirth.setEventID (UUID.randomUUID ().toString ());
                    userBirth.setCity ("Salt Lake City");
                    userBirth.setCountry ("United States");
                    userBirth.setLatitude (40.7500);
                    userBirth.setLongitude (-110.1167);
                    userBirth.setYear (1985);
                }
                fillGenerator.generatePersons2 (userPerson, userBirth, 1);


                ArrayList<Person> generatedPersons = fillGenerator.getPersons2 ();
                generatedPersons.add (userPerson);

                ArrayList<Event> generatedEvents = fillGenerator.getEvents2 ();
                generatedEvents.add (userBirth);


                FillService fillService = new FillService();

                fillService.setPersons (generatedPersons);
                fillService.setEvents (generatedEvents);

                fillResult = fillService.fill(fillRequest);
            }

            //If the username is invalid, construct the FillResult message to indicate this
            else if (fillRequest == null)//(validUsernameStatus == false)
            {
                //fillResult.setEventCount (0);
                //fillResult.setPersonCount (0);

                //Set the message to indicate the username was invalid
                String errorMessage = "Invalid username or generations parameter.";

                fillResult.setErrorMessage (errorMessage);
            }

            //If the number of generations for generating ancestral data is invalid (<0),
            //then construct the FillResult message to indicate this
            /*
            else
            {
                fillResult.setEventCount (0);
                fillResult.setPersonCount (0);

                //Set the message to indicate the username was invalid
                fillResult.setMessageIndex (1);
            }
            */



            String responseData = encodeProcess (fillResult);

            responseProcess (responseData, exchange);
        }
    }





    private FillRequest decodeProcess (HttpExchange exchange)
    {
        FillRequest fillRequest = null;

        String fillURI = exchange.getRequestURI ().toString ();
        String[] uriArray = fillURI.split ("/");

        String username = uriArray[2];

        int numGenerations = 4;
        if (uriArray.length > 3)
        {
            numGenerations = Integer.parseInt(uriArray[3]);
        }

        ValidationService fillValidationService = new ValidationService ();
        boolean validUsernameStatus = fillValidationService.validateUser (username);

        if (validUsernameStatus == true && numGenerations > 0)
        {
            fillRequest = new FillRequest (username, numGenerations);
        }

        return fillRequest;
    }




    private String encodeProcess (FillResult fillResult)
    {
        String responseData = fillCoder.encodeResult (fillResult);

        return responseData;
    }




    private void responseProcess (String responseData, HttpExchange exchange)
    {
        try
        {
            exchange.sendResponseHeaders (HttpURLConnection.HTTP_OK, 0);



            OutputStream responseBody = exchange.getResponseBody ();

            writeResponse (responseData, responseBody);

            responseBody.close ();
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }
    }




    private void writeResponse (String responseData, OutputStream responseBody) throws IOException
    {
        OutputStreamWriter responseWriter = new OutputStreamWriter (responseBody);

        responseWriter.write (responseData);

        responseWriter.flush ();
    }
}
