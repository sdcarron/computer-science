package service;

import dao.DatabaseDAO;
import dao.DatabaseDAO.UserDAO;
import dao.DatabaseDAO.PersonDAO;
import dao.DatabaseDAO.EventDAO;

import request.LoadRequest;
import result.LoadResult;

/**
 * This class processes the LoadRequest from the Server and sbumits it to the DAO
 */
public class LoadService
{
  DatabaseDAO loadDatabaseDAO = new DatabaseDAO ();
  UserDAO u_loadDatabaseDAO = loadDatabaseDAO.dbGetUserDAO ();
  PersonDAO p_loadDatabaseDAO = loadDatabaseDAO.dbGetPersonDAO ();
  EventDAO e_loadDatabaseDAO = loadDatabaseDAO.dbGetEventDAO ();



  public LoadService ()
  {

  }


  /**
   * Clear out old ancestral data associated with each User
   * Submit the NEW information FROM the LoadRequest to the Database by calling each appropriate DAO
   * @param loadRequest_submit The LoadRequest object
   * @return Message indicating success or failure
     */
  public LoadResult load (LoadRequest loadRequest_submit)
  {
      loadDatabaseDAO.openConnection ();

      LoadResult requestResult = new LoadResult ();

      int[] loadUserPersonEventCounts = null;


      if (loadRequest_submit.getUsers () != null && loadRequest_submit.getPersons () != null && loadRequest_submit.getEvents () != null)
      {
         loadUserPersonEventCounts = loadDatabaseDAO.loadDatabase (loadRequest_submit.getUsers (), loadRequest_submit.getPersons (), loadRequest_submit.getEvents ());
      }



      loadDatabaseDAO.closeConnection ();
    //Clear the data out of the Database

    //Load the data from the LoadRequest into the Database by calling the DAOs

    //requestResult.setUserCount (loadUserPersonEventCounts [0]);
    //requestResult.setPersonCount (loadUserPersonEventCounts [1]);
    //requestResult.setEventCount (loadUserPersonEventCounts [2]);

      if (loadUserPersonEventCounts != null)
      {
          requestResult.setSuccessMessage (loadUserPersonEventCounts [0], loadUserPersonEventCounts [1], loadUserPersonEventCounts [2]);
      }

      else
      {
          String errorMessage = "Invalid request data.";

          requestResult.setErrorMessage (errorMessage);
      }


    return requestResult;
  }
}
