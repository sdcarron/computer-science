package handle;



import java.io.*;
import java.net.*;
import com.sun.net.httpserver.*;


import com.google.gson.*;
import com.google.gson.JsonIOException;
import com.google.gson.JsonSyntaxException;


/**
 * Created by Steve on 3/4/2017.
 */
public class Encoder
{
    private Gson e_Gson = new Gson ();
}
