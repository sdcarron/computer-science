package model;

/**
 * Created by Steve on 3/12/2017.
 */
public class Location
{
    private String city = "";
    private String country = "";
    private double latitude;
    private double longitude;

    public Location ()
    {}

    public void setCity (String city_submit)
    {
        this.city = city_submit;
    }

    public String getCity ()
    {
        return this.city;
    }




    public void setCountry (String country_submit)
    {
        this.country = country_submit;
    }

    public String getCountry ()
    {
        return this.country;
    }




    public void setLatitude (String latitude_submit)
    {
        this.latitude = Double.parseDouble (latitude_submit);
    }

    public double getLatitude ()
    {
        return this.latitude;
    }




    public void setLongitude (String longitude_submit)
    {
        this.longitude = Double.parseDouble (longitude_submit);
    }

    public double getLongitude ()
    {
        return this.longitude;
    }
}
