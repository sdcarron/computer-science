package proxy;

import com.google.gson.*;

import com.google.gson.stream.JsonReader;

import java.io.*;
import java.net.*;

/**
 * Created by Steve on 3/14/2017.
 */
public class MainProxy
{


    public MainProxy ()
    {

    }




    public JsonObject run (String[] args)
    {
        JsonObject runBool = null;

        String serverHost = args [0];
        String serverPort = args [1];

        try
        {
            String baseURL = "http://" + serverHost + ":" + serverPort;

            URL url;


            if (args[2].toLowerCase ().equals ("clear"))
            {
                url = new URL (baseURL + "/clear/");

                HttpURLConnection http = (HttpURLConnection) url.openConnection ();

                runBool = clear (http);
            }



            else if (args[2].toLowerCase ().equals ("fill"))
            {
                if (args.length == 4)
                {
                    url = new URL (baseURL + "/fill/" + args[3]);

                    HttpURLConnection http = (HttpURLConnection) url.openConnection ();

                    runBool = fill (http);
                }

                else
                {
                    url = new URL (baseURL + "/fill/" + args[3] + "/" + args[4]);

                    HttpURLConnection http = (HttpURLConnection) url.openConnection ();

                    runBool = fill (http);
                }
            }



            else if (args[2].toLowerCase ().equals ("event"))
            {
                if (args.length == 4)
                {
                    url = new URL (baseURL + "/event/");

                    HttpURLConnection http = (HttpURLConnection) url.openConnection ();

                    runBool = getEvents (http, args[3]);
                }

                else
                {
                    url = new URL (baseURL + "/event/" + args[4]);

                    HttpURLConnection http = (HttpURLConnection) url.openConnection ();

                    runBool = getEvents (http, args[3]);
                }
            }


            else if (args[2].toLowerCase ().equals ("person"))
            {
                if (args.length == 4)
                {
                    url = new URL (baseURL + "/person/");

                    HttpURLConnection http = (HttpURLConnection) url.openConnection ();

                    runBool = getPersons (http, args[3]);
                }

                else
                {
                    url = new URL (baseURL + "/person/" + args[4]);

                    HttpURLConnection http = (HttpURLConnection) url.openConnection ();

                    runBool = getPersons (http, args[3]);
                }
            }



            else if (args[2].toLowerCase ().equals ("load"))
            {
                url = new URL (baseURL + "/load/");

                HttpURLConnection http = (HttpURLConnection) url.openConnection ();

                runBool = load (http, args[3]);
            }


            else if (args[2].toLowerCase ().equals ("login"))
            {
                url = new URL (baseURL + "/user/login/");

                HttpURLConnection http = (HttpURLConnection) url.openConnection ();

                runBool = login (http, args[3]);
            }


            else
            {
                url = new URL (baseURL + "/user/register/");

                HttpURLConnection http = (HttpURLConnection) url.openConnection ();

                runBool = register (http, args[3]);
            }
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }


        return runBool;
    }




    public JsonObject clear (HttpURLConnection http)
    {
        JsonObject clearBool = null;


        try
        {

            http.setRequestMethod ("POST");
            http.setDoOutput (true); //there is no request body

            http.connect ();


            /*
            OutputStream requestBody = http.getOutputStream ();

            String requestData = "";

            writeRequest (requestData, requestBody);

            requestBody.close ();
            */

            String requestData = "";

            sendRequest (http, requestData);

            if (http.getResponseCode () == HttpURLConnection.HTTP_OK)
            {
                //System.out.println ("Clear successful.");

                /*
                InputStream responseBody = http.getInputStream ();

                String responseData = readResponse (responseBody);

                System.out.println (responseData);
                */
                //displayResponse (http);

                //clearBool = new JsonObject (displayResponse (http));
                clearBool = displayResponse (http);
            }

            else
            {
                System.out.println ("Clear failed.");
            }

        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }


        return clearBool;
    }




    public JsonObject fill (HttpURLConnection http)
    {
        JsonObject fillBool = null;

        try
        {
            http.setRequestMethod ("POST");
            http.setDoOutput (true); //there is no request body

            //http.addRequestProperty ("Authorization", authID);
            //http.addRequestProperty ("Accept", "application/json");

            http.connect ();

            /*
            OutputStream requestBody = http.getOutputStream ();

            String requestData = "";

            writeRequest (requestData, requestBody);

            requestBody.close ();
            */

            String requestData = "";

            sendRequest (http, requestData);


            if (http.getResponseCode () == HttpURLConnection.HTTP_OK)
            {
                /*
                InputStream responseBody = http.getInputStream ();

                String responseData = readResponse (responseBody);

                System.out.println (responseData);
                */
                //displayResponse (http);

                fillBool = displayResponse (http);
            }

            else
            {
                System.out.println (http.getResponseMessage ());
            }

        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }


        return fillBool;
    }




    public JsonObject getEvents (HttpURLConnection http, String authID)
    {
        JsonObject eventsBool = null;


        try
        {


            http.setRequestMethod ("GET");
            http.setDoOutput (true); //there is no request body

            http.addRequestProperty ("Authorization", authID);
            //http.addRequestProperty ("Accept", "application/json");

            http.connect ();

            /*
            OutputStream requestBody = http.getOutputStream ();

            String requestData = "";

            writeRequest (requestData, requestBody);

            requestBody.close ();
            */

            //String requestData = "";

            //sendRequest (http, requestData);


            if (http.getResponseCode () == HttpURLConnection.HTTP_OK)
            {
                /*
                InputStream responseBody = http.getInputStream ();

                String responseData = readResponse (responseBody);

                System.out.println (responseData);
                */


                eventsBool = displayResponse (http);
            }

            else
            {
                System.out.println (http.getResponseMessage ());
            }

        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }


        return eventsBool;
    }




    public JsonObject getPersons (HttpURLConnection http, String authID)
    {
        JsonObject personsBool = null;


        try
        {
            http.setRequestMethod ("GET");
            http.setDoOutput (true);

            http.addRequestProperty ("Authorization", authID);
            //http.addRequestProperty ("Accept", "application/json");

            http.connect ();


            /*
            OutputStream requestBody = http.getOutputStream ();

            String requestData = "";

            writeRequest (requestData, requestBody);

            requestBody.close ();
            */
            //String requestData = "";

            //sendRequest (http, requestData);


            if (http.getResponseCode () == HttpURLConnection.HTTP_OK)
            {
                /*
                InputStream responseBody = http.getInputStream ();

                String responseData = readResponse (responseBody);

                System.out.println (responseData);
                */



                personsBool = displayResponse (http);
            }

            else
            {
                System.out.println (http.getResponseMessage ());
            }


        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }

        return personsBool;
    }




    public JsonObject load (HttpURLConnection http, String jsonData)
    {
        JsonObject loadBool = null;


        try
        {


            http.setRequestMethod ("POST");
            http.setDoOutput (true); //there is no request body

            //http.addRequestProperty ("Authorization", "");
            //http.addRequestProperty ("Accept", "application/json");

            http.connect ();

            /*
            OutputStream requestBody = http.getOutputStream ();

            String requestData = "";

            writeRequest (requestData, requestBody);

            requestBody.close ();
            */

            String requestData = jsonData;

            sendRequest (http, requestData);


            if (http.getResponseCode () == HttpURLConnection.HTTP_OK)
            {
                /*
                InputStream responseBody = http.getInputStream ();

                String responseData = readResponse (responseBody);

                System.out.println (responseData);
                */


                loadBool = displayResponse (http);
            }

            else
            {
                System.out.println (http.getResponseMessage ());
            }
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }


        return loadBool;
    }




    public JsonObject login (HttpURLConnection http, String jsonData)
    {
        JsonObject loginBool = null;


        try
        {


            http.setRequestMethod ("POST");
            http.setDoOutput (true); //there is no request body

            //http.addRequestProperty ("Authorization", "");
            //http.addRequestProperty ("Accept", "application/json");

            http.connect ();

            /*
            OutputStream requestBody = http.getOutputStream ();

            String requestData = "";

            writeRequest (requestData, requestBody);

            requestBody.close ();
            */

            String requestData = jsonData;

            sendRequest (http, requestData);


            if (http.getResponseCode () == HttpURLConnection.HTTP_OK)
            {
                /*
                InputStream responseBody = http.getInputStream ();

                String responseData = readResponse (responseBody);

                System.out.println (responseData);
                */


                loginBool =  displayResponse (http);
            }

            else
            {
                System.out.println (http.getResponseMessage ());
            }
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }


        return loginBool;
    }




    public JsonObject register (HttpURLConnection http, String jsonData)
    {
        JsonObject registerBool = null;


        try
        {


            http.setRequestMethod ("POST");
            http.setDoOutput (true); //there is no request body

            //http.addRequestProperty ("Authorization", "");
            //http.addRequestProperty ("Accept", "application/json");

            http.connect ();

            /*
            OutputStream requestBody = http.getOutputStream ();

            String requestData = "";

            writeRequest (requestData, requestBody);

            requestBody.close ();
            */

            String requestData = jsonData;

            sendRequest (http, requestData);


            if (http.getResponseCode () == HttpURLConnection.HTTP_OK)
            {
                /*
                InputStream responseBody = http.getInputStream ();

                String responseData = readResponse (responseBody);

                System.out.println (responseData);
                */


                registerBool = displayResponse (http);
            }

            else
            {
                System.out.println (http.getResponseMessage ());
            }
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }


        return registerBool;
    }










    public void sendRequest (HttpURLConnection http, String requestData)
    {
        try
        {
            OutputStream requestBody = http.getOutputStream ();

            //String requestData = "";

            writeRequest (requestData, requestBody);

            requestBody.close ();
        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }

    }




    public JsonObject displayResponse (HttpURLConnection http)
    {
        JsonObject responseData = new JsonObject ();

        try
        {
            InputStream responseBody = http.getInputStream ();

            String responseString = readResponse (responseBody);

            System.out.println (responseString);

            Gson gson = new Gson ();

            responseData = gson.fromJson (responseString, JsonObject.class);

        }

        catch (IOException e)
        {
            e.printStackTrace ();
        }

        return responseData;
    }




    public void writeRequest (String requestData, OutputStream requestBody) throws IOException
    {
        OutputStreamWriter requestWriter = new OutputStreamWriter (requestBody);

        requestWriter.write (requestData);

        requestWriter.flush ();
    }




    public String readResponse (InputStream responseBody) throws IOException
    {
        StringBuilder responseDataBuilder = new StringBuilder ();

        InputStreamReader responseReader = new InputStreamReader (responseBody);

        char[] buff = new char [1024];
        int len;

        while ((len = responseReader.read (buff)) > 0)
        {
            responseDataBuilder.append (buff, 0, len);
        }

        return responseDataBuilder.toString ();
    }
}
