package result;

/**
 * This class represents the message that results from making a Load Request to the Database
 */
public class LoadResult
{

    private String message = "";
  /**
   * These represent the numbers of User, Person, and Event objects associated with the Request
   */
  //private int userCount = 0;
  //private int personCount = 0;
  //private int eventCount = 0;

  /**
   * Thes represent the potential error messages that can result from a Load Request
   */
  //private String invalidValue = "Error: invalid value in LoadRequest";
  //private String internalError = "Error: internal server error";

  /**
   * this holds the potential error messages and messageIndex is used to select which error message
   * (if any) should be dislpayed
   */
  //private String[] messages = {invalidValue, internalError};

  //private int messageIndex;


  /**
   * The constructor expects 3 arguments
   * @param userCount_submit This is the number of User objects resulting from the Request
   * @param personCount_submit This is the number of Person objects resulting from the Request
   * @param eventCount_submit This is the number of Event objects resulting ffom the Request
   */
  /*
  public LoadResult (int userCount_submit, int personCount_submit, int eventCount_submit)
  {
    this.userCount = userCount_submit;
    this.personCount = personCount_submit;
    this.eventCount = eventCount_submit;
  }
  */

  /**
   * This constructor expects 0 arguments (in the case of 0 Users, 0 Person, and 0 Event objects resulted,
   * or if an error resulted
   */
  public LoadResult ()
  {

  }


  /*
  public void setUserCount (int userCount_submit)
  {
    this.userCount = userCount_submit;
  }

  public int getUserCount ()
  {
    return this.userCount;
  }




  public void setPersonCount (int personCount_submit)
  {
    this.personCount = personCount_submit;
  }

  public int getPersonCount ()
  {
    return this.personCount;
  }





  public void setEventCount (int eventCount_submit)
  {
    this.eventCount = eventCount_submit;
  }

  public int getEventCount ()
  {
    return this.eventCount;
  }




  public void setMessageIndex (int messageIndex_submit)
  {
    this.messageIndex = messageIndex_submit;
  }

  public String getMessage ()
  {
    return this.messages [this.messageIndex];
  }
  */

    public void setErrorMessage (String errorMessage_submit)
    {
        this.message = errorMessage_submit;
    }




    public void setSuccessMessage (int userInsert_submit, int personInsert_submit, int eventInsert_submit)
    {
        this.message = "Successfully inserted " + userInsert_submit + " users, " + personInsert_submit + " persons, and " + eventInsert_submit + " events to the database.";
    }
}
