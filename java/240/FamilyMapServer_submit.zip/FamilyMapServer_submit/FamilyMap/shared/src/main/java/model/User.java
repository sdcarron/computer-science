 package model;

 import java.util.TreeSet;
 import java.util.UUID;

 /**
  * This class represents Users
  */
 public class User
 {
   /**
    * The userName is a UNIQUE username
    * authTokens is a set of Authentication Tokens associated with this User object
    * personID is a second Unique Identifier for the User
    */
   private String userName = null;
   private String password = "";
   private String email = "";
   private String firstName = "";
   private String lastName = "";
   private String gender = "";
   TreeSet <String> authTokens = new TreeSet();

   private String personID;

   /**
    * The constructor expects 8 arguments
    * @param userName_submit The User's UNIQUE username
    * @param password_submit The User's password for the account
    * @param email_submit The User's email address for the account
    * @param firstName_submit The User's first name
    * @param lastName_submit The User's last name
    * @param gender_submit The User's gender
      * @param personID_submit The User's UNIQUE Identifier
      */
   public User (String userName_submit, String password_submit, String email_submit, String firstName_submit, String lastName_submit, String gender_submit, String personID_submit)
   {
      this.userName = userName_submit;
      this.password = password_submit;
      this.email = email_submit;
      this.firstName = firstName_submit;
      this.lastName = lastName_submit;
      this.gender = gender_submit;
      this.personID = personID_submit;
   }

   /**
      * The constrcutor expects 0 arguments
    */
   public User ()
   {

   }






   public String getUserName ()
   {
     return this.userName;
   }

   public void setUserName (String userName_submit)
   {
     this.userName = userName_submit;
   }






   public String getPassword ()
   {
     return this.password;
   }

   public void setPassword (String password_submit)
   {
     this.password = password_submit;
   }






   public String getEmail ()
   {
     return this.email;
   }

   public void setEmail (String email_submit)
   {
     this.email = email_submit;
   }





   public String getFirstName ()
   {
     return this.firstName;
   }

   public void setFirstName (String firstName_submit)
   {
     this.firstName = firstName_submit;
   }





   public String getLastName ()
   {
     return this.lastName;
   }

   public void setLastName (String lastName_submit)
   {
     this.lastName = lastName_submit;
   }





   public String getGender ()
   {
     return this.gender;
   }

   public void setGender (String gender_submit)
   {
     this.gender = gender_submit;
   }





   public String getPersonID ()
   {
     return this.personID;
   }

   public void setPersonID (String personID_submit)
   {
     this.personID = personID_submit;
   }


   /**
    * Checks if the submitted Athentication Token is ALREADY associated with this User object
    * @param authToken The Athentication Token to be looked for in the set of tokens
      * @return Indication of whether hte submitted Authentication Token is already in the set
      */
   public boolean hasAuthToken (String authToken)
   {
     return authTokens.contains (authToken);
   }

   /**
    * Adds a new Authentication Token to set of tokens associated with this User object
    * @param authToken_submit The new Authentication Token to be added to the set of tokens
      */
   public void addAuthToken (String authToken_submit)
   {
     authTokens.add (authToken_submit);
   }
 }
