package request;

import java.util.ArrayList;

import model.Event;
import model.Person;
import model.User;

/**
 * This class represents a request to load data into the database en masse
 */
public class LoadRequest
{
  /**
   * users is a group of Users to be put into the Database
   * persons is a group of Person objects to be put into the Database
   * events is a group of Event objects to be put into the Database
   */
  ArrayList<User> users = new ArrayList<> ();
  ArrayList<Person> persons = new ArrayList<> ();
  ArrayList<Event> events = new ArrayList<> ();

  /**
   * The constructor expects 3 arguments
   * @param users_submit Gropu of User objects to be put into the Database
   * @param persons_submit Group of Person objects to be put into the Database
   * @param events_submit Group of Event objects to be put into the Database
     */
  public LoadRequest (ArrayList<User> users_submit, ArrayList<Person> persons_submit, ArrayList<Event> events_submit)
  {
    this.users = users_submit;
    this.persons = persons_submit;
    this.events = events_submit;
  }

  /**
   * The constructor expects 0 arguments
   */
  public LoadRequest ()
  {

  }




  public void setUsers (ArrayList<User> users_submit)
  {
    this.users = users_submit;
  }

  public ArrayList<User> getUsers ()
  {
    return this.users;
  }




  public void setPersons (ArrayList<Person> persons_submit)
  {
    this.persons = persons_submit;
  }

  public ArrayList<Person> getPersons ()
  {
    return this.persons;
  }



  public void setEvents (ArrayList<Event> events_submit)
  {
    this.events = events_submit;
  }

  public ArrayList<Event> getEvents ()
  {
    return this.events;
  }
}

