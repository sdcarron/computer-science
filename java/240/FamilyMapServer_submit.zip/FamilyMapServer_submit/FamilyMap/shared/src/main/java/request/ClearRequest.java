 package request;

 /**
  * Objects of this class represent the request to clear the Database
  */
 public class ClearRequest
 {
   public ClearRequest ()
   {

   }
 }
