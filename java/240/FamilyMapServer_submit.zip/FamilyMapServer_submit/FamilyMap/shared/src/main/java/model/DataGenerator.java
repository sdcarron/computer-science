package model;

import request.FillRequest;
import request.LoadRequest;
import request.RegisterRequest;
import result.FillResult;
import result.RegisterResult;

/**
 * This class GENERATES data to be associated with a User that will then be put into the Database
 */
public class DataGenerator
{
    /**
     * These objects will be constructed with the information needed to generate the ancestral information for the intended User
     */
    User userGen = new User ();
    Person personGen = new Person ();
    Event eventGen = new Event ();




    public DataGenerator ()
    {

    }


    /**
     * Accepts a RegisterRequest from the RegisterService and GENERATES 4 GENERATIONS of ancestral data for hte User
     * @param registerRequest_submitFromRegisterService The RegisterRequest passed in from RegisterService
     * @return Data object that can be used to call appropriate DAOs (back inside RegisterService)
     */
    public GeneratorConstruct registerGenerate (RegisterRequest registerRequest_submitFromRegisterService)
    {
        //Generate 4 GENERATIONS of new Person and Event data for the submitted RegisterRequest and Return an object that
        //can then be used by the RegisterService to pass Event, Person, and User objects to the appropriate DAO



        return new GeneratorConstruct();
    }


    /**
     * Accepts a FillRequest from the FillService and GENERATES the INCLUDED (FillRequest data member) number of GENERATIONS of ancestral data for the User
     * @param fillRequest_submitFromFillService The FillRequest passed in from FillService
     * @return Data object that can be used to call appropriate DAOs (back inside FillService)
     */
    public GeneratorConstruct fillGenerate (FillRequest fillRequest_submitFromFillService)
    {
        //Generate the FillRequest GENERATIONS NUMBER of new Person and Event data for the User in the FillRequest and return
        //an object that can then be used by the FillService to pass Event, Person, and User objects to the appropriate DAO

        return new GeneratorConstruct ();
    }

}
