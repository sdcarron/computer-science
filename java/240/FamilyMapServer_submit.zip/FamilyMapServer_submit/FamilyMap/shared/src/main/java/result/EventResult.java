package result;

import java.util.ArrayList;

import model.Event;

/**
 * This class represents the Message that is returned when a request has been made to access Event data in the Database
 */
public class EventResult
{
  /**
   * This ArrayLIst holds 0+ Event objects returned as a result of the request
   */
  private ArrayList<Event> events = new ArrayList<> ();

  private String message="";
  /**
   * These Strings represent the possible error messages encountered if the request failed
   */
  //private String invalidAuthID = "Error: invalid AuthToken in EventRequest";
  //private String invalidEventID = "Error: invalid eventID in EventRequest";
  //private String internalError = "Error: internal server error";

  /**
   * This holds the possible error messages, and messageIndex will be used to select which (if any) of the
   * error messages is displayed
   */
  //private String[] messages = {invalidAuthID, invalidEventID, internalError};

  //private int messageIndex;


  /**
   * The constructor expects an ArrayLIst of 0+ Event objects
   * @param resultEvents_submit The potential Event objects returned from the Request
     */
  public EventResult (ArrayList<Event> resultEvents_submit)
  {
    this.events = resultEvents_submit;
  }

  /**
   * The constructor expects a single Event object
   * @param resultEvent_submit The single Event object returned from the Request
     */
  public EventResult (Event resultEvent_submit)
  {
    this.events.add (resultEvent_submit);
  }

  /**
   * The constructor expects 0 arguments
   */
  public EventResult ()
  {

  }


  /**
   * This adds the submitted Event object to the group of Event objects for the Request
   * @param resultEvent_submit Event object to be added for the result from the Request
     */
  public void addResultEvent (Event resultEvent_submit)
  {
    this.events.add (resultEvent_submit);
  }




  public ArrayList<Event> getEvents ()
  {
    return this.events;
  }

  public void setEvents (ArrayList<Event> resultEventList_submit)
  {
    for (int i = 0; i<resultEventList_submit.size (); i++)
    {
      this.events.add (resultEventList_submit.get (i));
    }
  }



    /*
  public void setMessageIndex (int messageIndex_submit)
  {
    this.messageIndex = messageIndex_submit;
  }

  public String getMessage ()
  {
    return this.messages [this.messageIndex];
  }
  */

    public void setErrorMessage (String errorMessage_submit)
    {
        this.message = errorMessage_submit;
    }
}
