package result;

/**
 * This class represents the message that results from when a User tries to Login
 */
public class LoginResult
{
  /**
   * These represent the Authentication Token, UNIQUE username, and Unique Identifier associated with
   * the User who made the Login Request
   */
  private String authID = "";
  private String userName = "";
  private String personID = "";

  private String message = "";

  /**
   * These are the potential errors that could be encountered when a user tries to log in
   */
  //private String missingProperty = "Error: missing property in RegisterRequest";
  //private String invalidValue = "Error: invalid value in RegisterRequest";
  //private String internalError = "Error: internal server error";

  /**
   * This holds the potential error messages, and messageIndex is used to select which error message,
   * (if any) should be displayed
   */
  //private String[] messages = {missingProperty, invalidValue, internalError};

  //private int messageIndex;


  /**
   * The constructor expects 3 arguments
   * @param authID_submit This is the Authentication Token ID for hte auth token generated if the user logged in successfully
   * @param userName_submit This is the Logged In user's UNIQUE username
   * @param personID_submit This is the Logged In user's Unique Identifier
     */
  public LoginResult (String authID_submit, String userName_submit, String personID_submit)
  {
    this.authID = authID_submit;
    this.userName = userName_submit;
    this.personID = personID_submit;
  }

  /**
   * The constrcutor expects 0 arguments (used in the case of an error)
   */
  public LoginResult ()
  {

  }



  public String getAuthID ()
  {
    return this.authID;
  }




  public String getUserName ()
  {
    return this.userName;
  }




  public String getPersonID ()
  {
    return this.personID;
  }



  /*
  public void setMessageIndex (int messageIndex_submit)
  {
    this.messageIndex = messageIndex_submit;
  }

  public String getMessage ()
  {
    return this.messages [this.messageIndex];
  }
  */

  public void setErrorMessage (String errorMessage_submit)
  {
    this.message = errorMessage_submit;
  }
}
