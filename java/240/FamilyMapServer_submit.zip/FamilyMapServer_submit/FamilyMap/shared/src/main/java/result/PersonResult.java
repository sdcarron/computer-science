package result;

import java.util.ArrayList;

import model.Person;

/**
 * This class represents the message that results from making a request to the Database regarding Person data
 */
public class PersonResult
{
  /**
   * This holds 0+ Person objects that result from the Request
   */
  private ArrayList<Person> persons = new ArrayList<>();

    private String message = "";

  /**
   * These Strings are the ptoential error messages that result from making the Request
   */
  //private String invalidAuthID = "Error: invalid AuthToken in PersonRequest";
  //private String invalidPersonID = "Error: invalid personID in PersonRequest";
  //private String internalError = "Error: internal server error";

  /**
   * This holds the potential error messages and messageIndex is ued to select the appropriate error message,
   * (if any) that hsould be displayed
   */
  //private String[] messages = {invalidAuthID, invalidPersonID, internalError};

  //private int messageIndex;

  /**
   * The constructor expects 1 argument (an ArrayList of 0+ Person objects resulting from the Request)
   * @param resultPersons_submit Group of Person objects potentially returned from the Request
     */
  public PersonResult (ArrayList<Person> resultPersons_submit)
  {
    this.persons = resultPersons_submit;
  }

  /**
   * The constructor expects 1 argument
   * @param resultPerson_submit Potential Person object returned from the Request
     */
  public PersonResult (Person resultPerson_submit)
  {
    this.persons.add (resultPerson_submit);
  }

  /**
   * The constructor expects 0 arguments (this will be used in the event of an error)
   */
  public PersonResult ()
  {

  }


  /**
   * This adds the submitted Person to the group of Person objects returned from the request
   * @param resultPerson_submit Person object to be added to the group of Person objects resulting from the Request
     */
  public void addResultPerson (Person resultPerson_submit)
  {
    this.persons.add (resultPerson_submit);
  }




  public ArrayList<Person> getPersons ()
  {
    return this.persons;
  }

  public void setPersons (ArrayList<Person> resultPersonList_submit)
  {
    for (int i=0; i<resultPersonList_submit.size (); i++)
    {
      this.persons.add (resultPersonList_submit.get (i));
    }
  }




  /*
  public void setMessageIndex (int messageIndex_submit)
  {
    this.messageIndex = messageIndex_submit;
  }

  public String getMessage ()
  {
    return this.messages [this.messageIndex];
  }
  */

  public void setErrorMessage (String errorMessage_submit)
  {
      this.message = errorMessage_submit;
  }
}
